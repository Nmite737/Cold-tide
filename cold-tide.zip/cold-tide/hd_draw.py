"""Native 32 px pixel-art drawing for the HD pack: toolkit, terrain, nature, props.
Build-time only (needs Pillow).  Everything is drawn pixel by pixel with hue-shifted colour
ramps and seeded randomness, so the art is identical on every machine."""
import math
import random

from PIL import Image, ImageDraw

T = 32
OL = (44, 34, 44)            # soft dark outline (slightly purple, never pure black)


def rgba(c, a=255):
    return (c[0], c[1], c[2], a)


def mix(a, b, k):
    return tuple(int(a[i] + (b[i] - a[i]) * k) for i in range(3))


def ramp(base, n=5):
    """dark ... light colours around `base`: shadows drift blue/purple, lights drift warm."""
    out = []
    for i in range(n):
        k = (i - (n - 1) / 2.0) / ((n - 1) / 2.0)           # -1 .. 1
        if k < 0:
            c = mix(base, (38, 36, 78), -k * 0.46)
        else:
            c = mix(base, (255, 240, 190), k * 0.38)
        out.append(c)
    return out


class Cv:
    """A tiny pixel canvas with clipping and optional wrap-around (for seamless tiles)."""

    def __init__(self, w, h, wrap=False, fill=None):
        self.w, self.h, self.wrap = w, h, wrap
        self.im = Image.new("RGBA", (w, h), fill if fill else (0, 0, 0, 0))
        self.px = self.im.load()

    def put(self, x, y, c, a=255):
        x, y = int(x), int(y)
        if self.wrap:
            x %= self.w
            y %= self.h
        elif not (0 <= x < self.w and 0 <= y < self.h):
            return
        if len(c) == 4:
            a = c[3]
        if a >= 255:
            self.px[x, y] = rgba(c)
        elif a > 0:
            o = self.px[x, y]
            k = a / 255.0
            na = o[3] + (255 - o[3]) * k
            if na <= 0:
                return
            self.px[x, y] = tuple(int((c[i] * k * 255 + o[i] * o[3] * (1 - k)) / na) for i in range(3)) + (int(na),)

    def get(self, x, y):
        if self.wrap:
            x %= self.w
            y %= self.h
        elif not (0 <= x < self.w and 0 <= y < self.h):
            return (0, 0, 0, 0)
        return self.px[int(x), int(y)]

    def rect(self, x0, y0, x1, y1, c, a=255):
        for y in range(int(y0), int(y1) + 1):
            for x in range(int(x0), int(x1) + 1):
                self.put(x, y, c, a)

    def hline(self, x0, x1, y, c, a=255):
        for x in range(int(x0), int(x1) + 1):
            self.put(x, y, c, a)

    def vline(self, x, y0, y1, c, a=255):
        for y in range(int(y0), int(y1) + 1):
            self.put(x, y, c, a)

    def frame(self, x0, y0, x1, y1, c):
        self.hline(x0, x1, y0, c)
        self.hline(x0, x1, y1, c)
        self.vline(x0, y0, y1, c)
        self.vline(x1, y0, y1, c)

    def paste(self, other, x, y):
        self.im.alpha_composite(other.im if isinstance(other, Cv) else other, (int(x), int(y)))
        self.px = self.im.load()

    def outline(self, col=OL, inner=False):
        """1 px outline around everything that is opaque."""
        src = self.im.copy()
        sp = src.load()
        for y in range(self.h):
            for x in range(self.w):
                if sp[x, y][3] < 128:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < self.w and 0 <= ny < self.h and sp[nx, ny][3] >= 128:
                            self.px[x, y] = rgba(col)
                            break

    def img(self):
        return self.im


def blob(cv, cx, cy, rx, ry, cols, light=(-0.55, -0.7), dither=True, seed=0, noise=0.12):
    """Shaded ellipse. cols = dark..light ramp. Light comes from the top-left."""
    r = random.Random(seed)
    n = len(cols)
    for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
        for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
            dx, dy = (x + .5 - cx) / rx, (y + .5 - cy) / ry
            d = dx * dx + dy * dy
            if d > 1.0:
                continue
            nz = math.sqrt(max(0.0, 1 - d))
            lam = (dx * light[0] + dy * light[1]) * -1 * 0.65 + nz * 0.55
            v = lam + (r.random() - .5) * noise
            if dither and (x + y) % 2 == 0:
                v += 0.05
            i = int(max(0, min(n - 1, (v + 0.15) * n * 0.95)))
            cv.put(x, y, cols[i])


def noise_fill(cv, x0, y0, x1, y1, cols, weights, seed):
    r = random.Random(seed)
    tot = float(sum(weights))
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            v, acc = r.random() * tot, 0
            for c, w in zip(cols, weights):
                acc += w
                if v <= acc:
                    cv.put(x, y, c)
                    break


# ============================================================ terrain
GRASS = ramp((92, 150, 78), 5)
GRASS_DARK = ramp((80, 138, 72), 5)


def grass(seed, flowers=0, dark=False, litter=False):
    cols = GRASS_DARK if dark else GRASS
    cv = Cv(T, T, wrap=True)
    noise_fill(cv, 0, 0, T - 1, T - 1, [cols[1], cols[2], cols[3], cols[0]], [3, 9, 2.6, 0.8], seed)
    r = random.Random(seed * 31 + 7)
    for _ in range(26):                                   # blades
        x, y = r.randrange(T), r.randrange(T)
        h = r.choice((2, 3, 3, 4))
        col = cols[4] if r.random() < .55 else cols[0]
        for i in range(h):
            cv.put(x + (i // 2) * (1 if r.random() < .4 else 0), y - i, col)
        if r.random() < .5:
            cv.put(x + 1, y - 1, cols[3])
    for _ in range(4):                                    # clover patches
        x, y = r.randrange(T), r.randrange(T)
        for dx, dy in ((0, 0), (1, 0), (0, 1), (-1, 0)):
            cv.put(x + dx, y + dy, cols[3])
        cv.put(x, y, cols[4])
    if litter:
        for _ in range(7):
            x, y = r.randrange(T), r.randrange(T)
            c = r.choice(((190, 120, 56), (160, 90, 50), (214, 160, 70)))
            cv.put(x, y, c)
            cv.put(x + 1, y, mix(c, (60, 30, 20), .35))
    pal = [(250, 244, 230), (244, 150, 170), (150, 170, 240), (250, 206, 80), (214, 120, 220)]
    for i in range(flowers):
        x, y = r.randrange(3, T - 3), r.randrange(5, T - 3)
        c = r.choice(pal)
        cv.put(x, y + 1, cols[0])
        cv.put(x, y + 2, cols[0])
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            cv.put(x + dx, y + dy, c)
        cv.put(x, y, (250, 210, 80) if c != pal[3] else (200, 110, 40))
    return cv.img()


ASPH = ramp((92, 94, 112), 5)


def asphalt(seed, edge=None, line=False, cross=False):
    cv = Cv(T, T, wrap=True)
    noise_fill(cv, 0, 0, T - 1, T - 1, [ASPH[1], ASPH[2], ASPH[3], ASPH[0]], [8, 6, 1.4, 1.6], seed)
    r = random.Random(seed + 5)
    for _ in range(5):                                    # aggregate speckles
        cv.put(r.randrange(T), r.randrange(T), ASPH[4])
    if seed % 2 == 0:                                     # crack
        x, y = r.randrange(4, 12), r.randrange(6, 26)
        for i in range(r.randrange(8, 14)):
            cv.put(x + i, y, ASPH[0])
            if r.random() < .5:
                y += r.choice((-1, 1))
    if cross:
        for bar in range(4):
            x0 = 2 + bar * 8
            for y in range(0, T):
                for x in range(x0, x0 + 5):
                    wear = (x * 3 + y * 5) % 11 == 0
                    cv.put(x, y, (226, 224, 214) if not wear else (196, 196, 196))
            cv.vline(x0, 0, T - 1, (244, 242, 232))
            cv.vline(x0 + 4, 0, T - 1, (176, 176, 178))
    if line:
        for x0 in (3, 19):
            for x in range(x0, x0 + 11):
                for y in (15, 16):
                    cv.put(x, y, (238, 196, 70) if y == 15 else (206, 160, 52))
            cv.put(x0, 15, (252, 226, 120))
    if edge == "n":                                       # gutter shadow under the north curb
        for i, a in enumerate((120, 78, 42, 20)):
            cv.hline(0, T - 1, i, (28, 26, 54), a)
    elif edge == "s":                                     # lighter lip next to the south curb
        for i, a in enumerate((50, 26)):
            cv.hline(0, T - 1, T - 1 - i, (200, 200, 220), a)
    return cv.img()


PAVE = ramp((208, 200, 182), 5)


def sidewalk(seed, curb=None):
    cv = Cv(T, T, wrap=True)
    r = random.Random(seed)
    for sy in range(2):
        for sx in range(2):
            ox, oy = sx * 16 + (8 if sy else 0), sy * 16
            base = r.choice((PAVE[2], PAVE[2], PAVE[3], PAVE[1]))
            for y in range(16):
                for x in range(16):
                    c = base
                    if x == 0 or y == 0:
                        c = PAVE[4] if base != PAVE[4] else PAVE[3]
                    elif x == 15 or y == 15:
                        c = PAVE[0]
                    elif r.random() < .07:
                        c = PAVE[1]
                    elif r.random() < .05:
                        c = PAVE[3]
                    cv.put(ox + x, oy + y, c)
    for _ in range(3):
        cv.put(r.randrange(T), r.randrange(T), (150, 142, 128))
    if curb == "s":                                       # north sidewalk: curb at the bottom
        cv.rect(0, T - 7, T - 1, T - 1, PAVE[3])
        cv.hline(0, T - 1, T - 7, PAVE[4])
        cv.hline(0, T - 1, T - 3, PAVE[1])
        cv.hline(0, T - 1, T - 2, (130, 124, 124))
        cv.hline(0, T - 1, T - 1, (86, 82, 96))
        for x in range(0, T, 16):
            cv.vline(x + 15 - 0, T - 6, T - 3, PAVE[0])
    elif curb == "n":                                     # south sidewalk: curb at the top
        cv.rect(0, 0, T - 1, 6, PAVE[3])
        cv.hline(0, T - 1, 0, (86, 82, 96))
        cv.hline(0, T - 1, 1, PAVE[4])
        cv.hline(0, T - 1, 5, PAVE[1])
        cv.hline(0, T - 1, 6, PAVE[0])
        for x in range(0, T, 16):
            cv.vline(x + 15, 2, 5, PAVE[0])
    return cv.img()


SAND = ramp((232, 212, 158), 5)


def sand(seed):
    cv = Cv(T, T, wrap=True)
    noise_fill(cv, 0, 0, T - 1, T - 1, [SAND[1], SAND[2], SAND[3], SAND[0]], [5, 9, 3, 1.2], seed)
    r = random.Random(seed + 11)
    for k in range(2):                                    # wind ripples
        y = r.randrange(4, 28)
        x0 = r.randrange(0, 20)
        for i in range(10):
            cv.put(x0 + i, y + (1 if i % 5 == 4 else 0), SAND[4])
            cv.put(x0 + i, y + 1 + (1 if i % 5 == 4 else 0), SAND[0])
    for _ in range(3):                                    # pebbles
        x, y = r.randrange(T), r.randrange(T)
        cv.put(x, y, (176, 160, 140))
        cv.put(x + 1, y, (146, 130, 120))
        cv.put(x, y - 1, (214, 200, 180))
    if seed % 2:                                          # a shell
        x, y = r.randrange(6, 24), r.randrange(6, 24)
        for dx, dy, c in ((0, 0, (250, 240, 226)), (1, 0, (240, 196, 190)), (-1, 0, (240, 196, 190)),
                          (0, 1, (214, 160, 160)), (0, -1, (255, 252, 244))):
            cv.put(x + dx, y + dy, c)
    return cv.img()


def wet_sand():
    """Overlay for sand tiles that touch the sea: darker, wet, with a glossy edge."""
    cv = Cv(T, T)
    for y in range(T):
        a = int(max(0, (y - 12) / 19.0) ** 1.4 * 120)
        cv.hline(0, T - 1, y, (96, 78, 70), a)
    r = random.Random(3)
    for _ in range(6):
        cv.put(r.randrange(T), r.randrange(20, 31), (255, 250, 240), 150)
    return cv.img()


def foam(frame):
    """Overlay for the top row of water tiles: breaking wave line, 4 animation frames."""
    cv = Cv(T, T)
    for x in range(T):
        wob = int(round(2 * math.sin((x + frame * 8) / 5.0) + 1.2 * math.sin((x * 2 + frame * 5) / 3.0)))
        for y in range(0, 4 + wob):
            if y < 0:
                continue
            a = 255 if y >= 3 + wob - 1 else 200
            cv.put(x, y, (250, 252, 250) if y >= 2 + wob else (210, 238, 236), a if y < 3 else 150)
        if (x + frame * 3) % 7 == 0:
            cv.put(x, 5 + wob, (230, 248, 244), 120)
    return cv.img()


WATER = {"shallow": (98, 182, 174), "mid": (74, 152, 166), "deep": (54, 118, 150)}


def water(depth, frame):
    base = WATER[depth]
    rp = ramp(base, 5)
    cv = Cv(T, T, wrap=True)
    r = random.Random(41 + {"shallow": 0, "mid": 1, "deep": 2}[depth])
    noise_fill(cv, 0, 0, T - 1, T - 1, [rp[1], rp[2], rp[3]], [3, 10, 2], 77)
    rows = [(3, 0), (10, 9), (17, 3), (24, 14), (29, 20)]
    for i, (y, x0) in enumerate(rows):
        x0 = (x0 + frame * 8 * (1 if i % 2 else -1)) % T
        ln = 8 + (i * 3) % 6
        for k in range(ln):
            cv.put(x0 + k, y, rp[4])
            cv.put(x0 + k, y + 1, rp[0])
        cv.put(x0 + ln // 2, y - 1, rp[4])
    for i in range(3):                                    # sparkles
        sx = (6 + i * 11 + frame * 7) % T
        sy = (5 + i * 9 + frame * 3) % T
        if (frame + i) % 2 == 0:
            cv.put(sx, sy, (240, 252, 250))
            cv.put(sx + 1, sy, (190, 232, 232))
    return cv.img()


# ============================================================ nature
def shadow_ellipse(cv, cx, cy, rx, ry, a=80, col=(24, 30, 54)):
    for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
        for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
            d = ((x + .5 - cx) / rx) ** 2 + ((y + .5 - cy) / ry) ** 2
            if d <= 1:
                cv.put(x, y, col, int(a * (1.0 if d < .55 else .6)))


def tree(kind=0, seed=1):
    """48 x 64 sprite, trunk base at bottom centre.  kind: 0 oak, 1 round-dark, 2 pine, 3 apple."""
    cv = Cv(48, 64)
    shadow_ellipse(cv, 25, 59, 17, 4.2, 90)
    trunk = ramp((120, 82, 58), 5)
    # trunk (drawn first, crown overlaps)
    ty0 = 40 if kind != 2 else 46
    for y in range(ty0, 61):
        flare = max(0, y - 54) // 2
        for x in range(21 - flare, 28 + flare):
            k = 3 if x < 23 else 2 if x < 26 else 1
            if (x * 3 + y) % 9 == 0:
                k -= 1
            cv.put(x, y, trunk[max(0, k)])
    if kind == 2:
        cols = ramp((54, 116, 84), 5)
        tiers = [(24, 46, 10, 0), (24, 36, 13, 1), (24, 26, 16, 2), (24, 16, 18, 3)]
        for cx, by, hw, i in tiers[::-1]:
            pass
        for cx, by, hw, i in [(24, 22, 9, 0), (24, 31, 13, 1), (24, 41, 17, 2), (24, 51, 20, 3)][::-1][::-1]:
            for y in range(by - 15, by + 1):
                w = (y - (by - 15)) / 15.0 * hw
                for x in range(int(cx - w), int(cx + w) + 1):
                    d = (x - cx) / max(1, w)
                    k = 3 if d < -.35 else 2 if d < .25 else 1
                    if y > by - 4:
                        k -= 1
                    if (x + y) % 3 == 0 and k < 4:
                        k += 0 if r_(x, y) else 1
                    cv.put(x, y, cols[max(0, min(4, k))])
        cv.im = cv.im
        cv.outline(mix((24, 52, 44), (0, 0, 20), .3))
        return cv.img()
    base = {0: (88, 156, 80), 1: (62, 128, 76), 3: (92, 154, 76)}[kind]
    cols = ramp(base, 5)
    clumps = [(24, 22, 17, 15), (13, 28, 11, 10), (35, 28, 11, 10), (24, 10, 11, 9), (17, 16, 10, 9), (32, 17, 10, 9)]
    # dark underside first, then lighter clumps on top of it
    for cx, cy, rx, ry in sorted(clumps, key=lambda c: -c[1]):
        blob(cv, cx, cy, rx, ry, cols, seed=seed * 7 + cx)
    r = random.Random(seed)
    for _ in range(46):                                   # leaf clusters (tiny shapes)
        x, y = r.randrange(8, 41), r.randrange(4, 38)
        if cv.get(x, y)[3] < 128:
            continue
        lit = (x < 24 and y < 24) or r.random() < .2
        c = cols[4] if lit else cols[0]
        for dx, dy in ((0, 0), (1, 0), (0, 1)) if lit else ((0, 0), (-1, 0), (0, -1)):
            if cv.get(x + dx, y + dy)[3] >= 128:
                cv.put(x + dx, y + dy, c)
    if kind == 3:
        for _ in range(9):
            x, y = r.randrange(11, 38), r.randrange(10, 36)
            if cv.get(x, y)[3] >= 128:
                cv.put(x, y, (214, 52, 52))
                cv.put(x + 1, y, (170, 34, 44))
                cv.put(x, y - 1, (250, 120, 110))
    cv.outline(mix(base, (14, 30, 28), .78))
    return cv.img()


def r_(x, y):
    return (x * 5 + y * 3) % 4 == 0


def rock(seed=1, moss=True):
    cv = Cv(32, 32)
    shadow_ellipse(cv, 17, 27, 13, 3.4, 80)
    cols = ramp((126, 124, 140), 5)
    blob(cv, 16, 19, 12, 9, cols, seed=seed)
    blob(cv, 24, 22, 6, 5, cols, seed=seed + 1)
    blob(cv, 8, 23, 5, 4, cols, seed=seed + 2)
    r = random.Random(seed)
    if moss:
        mc = ramp((98, 150, 74), 5)
        for x in range(7, 24):
            for y in range(9, 16):
                if cv.get(x, y)[3] >= 128 and r.random() < (0.55 - (y - 9) * .08) and x < 21:
                    cv.put(x, y, mc[3 if r.random() < .6 else 2])
    for _ in range(5):                                    # crack
        x, y = r.randrange(10, 22), r.randrange(14, 24)
        if cv.get(x, y)[3] >= 128:
            cv.put(x, y, cols[0])
    cv.outline(mix((70, 66, 90), OL, .4))
    return cv.img()


SOIL = ramp((138, 94, 62), 5)


def mound(dug=False, seed=4):
    cv = Cv(32, 32)
    r = random.Random(seed)
    if dug:
        shadow_ellipse(cv, 16, 21, 13, 7, 140, (24, 14, 14))
        for y in range(10, 30):
            for x in range(2, 30):
                d = ((x - 16) / 13.0) ** 2 + ((y - 20) / 7.5) ** 2
                if d <= 1:
                    k = 0 if d < .5 else 1 if d < .8 else 2
                    cv.put(x, y, SOIL[k] if k else mix(SOIL[0], (10, 6, 12), .5))
        for _ in range(26):
            x, y = r.randrange(2, 30), r.randrange(12, 30)
            d = ((x - 16) / 13.0) ** 2 + ((y - 20) / 7.5) ** 2
            if .8 < d < 1.35:
                cv.put(x, y, SOIL[r.choice((2, 3, 3, 4))])
        for x in range(4, 14):                            # a root and a stone
            cv.put(x, 17 + (x // 4), SOIL[4])
        cv.outline(mix(SOIL[0], OL, .5))
        return cv.img()
    shadow_ellipse(cv, 17, 26, 13, 3.4, 80)
    blob(cv, 16, 19, 13, 9.5, SOIL, seed=seed, noise=.3)
    for _ in range(14):                                   # clods
        x, y = r.randrange(5, 28), r.randrange(10, 26)
        if cv.get(x, y)[3] >= 128:
            cv.put(x, y, SOIL[4] if x < 16 else SOIL[0])
            cv.put(x + 1, y, SOIL[3] if x < 16 else SOIL[1])
    gc = GRASS
    for x in (3, 5, 26, 28, 12, 20):                      # grass tufts at the foot
        cv.put(x, 26 + (x % 2), gc[4])
        cv.put(x, 25 + (x % 2), gc[3])
    cv.outline(mix(SOIL[0], OL, .5))
    return cv.img()


def marker():
    cv = Cv(32, 32)
    shadow_ellipse(cv, 16, 27, 9, 2.6, 80)
    y0, y1 = 8, 27
    for y in range(y0, y1):
        w = (y - y0) / float(y1 - y0) * 9 + 2
        for x in range(int(16 - w), int(16 + w) + 1):
            k = (x - 16) / max(1, w)
            c = (254, 222, 90) if k < -.1 else (236, 188, 52) if k < .5 else (196, 146, 40)
            cv.put(x, y, c)
    for (x, y) in ((14, 14), (15, 14), (16, 14), (16, 15), (15, 16), (14, 17), (14, 18), (15, 18), (16, 18)):
        cv.put(x, y + 3, (62, 42, 40))                    # a stencilled "2" feel without text
    cv.hline(11, 21, 26, (120, 86, 34))
    cv.outline((90, 60, 30))
    return cv.img()


def tape():
    cv = Cv(32, 32)
    for x in range(0, 32):
        sag = int(1.5 * math.sin(x / 32.0 * math.pi))
        for y in range(11 + sag, 18 + sag):
            stripe = ((x + (y - 11 - sag)) // 4) % 2 == 0
            cv.put(x, y, (246, 206, 62) if stripe else (52, 44, 52))
        cv.put(x, 18 + sag, (36, 30, 44), 90)
        cv.put(x, 19 + sag, (36, 30, 44), 40)
        cv.put(x, 10 + sag, (255, 240, 170), 90)
    cv.vline(0, 6, 28, (130, 100, 70))
    cv.vline(1, 6, 28, (170, 130, 90))
    cv.vline(31, 6, 28, (120, 90, 64))
    return cv.img()


def cctv():
    cv = Cv(32, 48)
    shadow_ellipse(cv, 17, 44, 8, 2.4, 80)
    steel = ramp((140, 148, 168), 5)
    for y in range(12, 45):
        for x in range(14, 19):
            cv.put(x, y, steel[3] if x == 14 else steel[2] if x < 17 else steel[0])
    cv.rect(11, 42, 21, 45, steel[1])
    cv.hline(11, 21, 42, steel[3])
    cv.rect(5, 3, 26, 13, (70, 74, 96))
    cv.rect(5, 3, 26, 4, (110, 116, 140))
    cv.rect(6, 5, 20, 12, (38, 40, 62))
    cv.rect(21, 5, 25, 12, (58, 60, 84))
    for x, y in ((9, 8), (10, 8), (9, 9), (10, 9)):
        cv.put(x, y, (140, 190, 230))
    cv.put(8, 7, (230, 250, 255))
    cv.put(23, 7, (240, 64, 64))
    cv.put(23, 8, (255, 140, 120))
    cv.outline(OL)
    return cv.img()


def icon(kind):
    cv = Cv(32, 32)
    for y in range(32):
        for x in range(32):
            if (x in (0, 31) and y in (0, 31)) or (x in (0, 1, 30, 31) and y in (0, 31)) or (y in (0, 1, 30, 31) and x in (0, 31)):
                continue
            cv.put(x, y, mix((70, 52, 56), (44, 32, 40), y / 31.0))
    cv.frame(1, 1, 30, 30, (118, 92, 80))
    cv.hline(3, 28, 2, (150, 124, 108), 120)
    cream, teal = (240, 232, 210), (150, 214, 190)
    if kind == "prints":
        for i, rr in enumerate((4, 7, 10, 13)):
            for a in range(200, 345, 3):
                x = 16 + rr * math.cos(math.radians(a))
                y = 17 + rr * math.sin(math.radians(a))
                if (int(a) // 3 + i) % 11 != 0:
                    cv.put(x, y, cream)
        cv.vline(16, 17, 26, cream)
        cv.vline(11, 19, 24, cream)
        cv.vline(21, 19, 24, cream)
    elif kind == "scan":
        cv.frame(7, 7, 24, 24, teal)
        for k in (7, 24):
            cv.hline(k - 2 if k == 7 else k, k + 3 if k == 7 else k + 2, 6, cream)
        cv.vline(16, 3, 28, teal, 160)
        cv.hline(3, 28, 16, teal, 160)
        cv.rect(15, 15, 17, 17, (230, 70, 64))
    else:
        for i in range(14):
            cv.put(8 + i, 24 - i, (190, 134, 90))
            cv.put(9 + i, 24 - i, (150, 100, 66))
            cv.put(8 + i, 23 - i, (220, 170, 120))
        for (dx, dy) in ((0, 0), (1, 0), (2, 0), (3, 0), (0, 1), (1, 1), (2, 1), (3, 1), (1, 2), (2, 2), (2, 3), (3, 3)):
            cv.put(18 + dx + 1, 6 + dy + 1, (196, 204, 216) if dx + dy < 3 else (140, 148, 170))
        cv.put(19, 7, (255, 255, 255))
    return cv.img()


# ============================================================ props (decor.py places them)
def lamp():
    cv = Cv(32, 80)
    shadow_ellipse(cv, 17, 77, 8, 2.2, 80)
    iron = ramp((62, 72, 92), 5)
    for y in range(18, 76):
        cv.put(15, y, iron[3])
        cv.put(16, y, iron[2])
        cv.put(17, y, iron[1])
        cv.put(18, y, iron[0])
    cv.rect(12, 70, 21, 76, iron[1])
    cv.hline(12, 21, 70, iron[3])
    cv.rect(13, 64, 20, 69, iron[2])
    for x in range(10, 24):
        cv.put(x, 17 + (0 if 12 < x < 21 else 1), iron[1])
    cv.rect(10, 6, 22, 16, (60, 66, 84))
    cv.rect(11, 7, 21, 15, (255, 224, 140))
    cv.rect(13, 9, 19, 13, (255, 246, 200))
    cv.vline(16, 7, 15, (150, 120, 70))
    cv.rect(9, 3, 23, 5, iron[1])
    cv.hline(11, 21, 2, iron[2])
    cv.put(16, 1, iron[3])
    cv.outline(OL)
    return cv.img()


def bench():
    cv = Cv(48, 36)
    shadow_ellipse(cv, 25, 31, 20, 3.5, 80)
    wood = ramp((176, 120, 80), 5)
    iron = ramp((60, 66, 84), 5)
    for y in range(8, 15):                                # backrest
        for x in range(4, 44):
            cv.put(x, y, wood[3] if y == 8 else wood[1] if y == 14 else wood[2] if (y + x // 9) % 2 else wood[2])
    for x in range(4, 44, 9):
        cv.vline(x, 9, 13, wood[0])
    for y in range(18, 23):
        for x in range(2, 46):
            cv.put(x, y, wood[4] if y == 18 else wood[0] if y == 22 else wood[2])
    for x in (6, 40):
        cv.rect(x, 22, x + 2, 31, iron[2])
        cv.rect(x, 8, x + 2, 17, iron[1])
    cv.outline(OL)
    return cv.img()


def bush(seed=3, flowers=False):
    cv = Cv(32, 32)
    shadow_ellipse(cv, 16, 27, 13, 3.4, 80)
    cols = ramp((78, 140, 76), 5)
    for cx, cy, rx, ry in ((10, 20, 8, 7), (22, 20, 8, 7), (16, 15, 9, 8)):
        blob(cv, cx, cy, rx, ry, cols, seed=seed + cx)
    if flowers:
        r = random.Random(seed)
        for _ in range(9):
            x, y = r.randrange(6, 26), r.randrange(8, 24)
            if cv.get(x, y)[3] >= 128:
                c = r.choice(((244, 150, 170), (250, 244, 230), (250, 206, 80)))
                cv.put(x, y, c)
                cv.put(x + 1, y, mix(c, (200, 120, 130), .3))
    cv.outline(mix((78, 140, 76), (14, 30, 28), .78))
    return cv.img()


def flowerpot(seed=2):
    cv = Cv(32, 40)
    shadow_ellipse(cv, 16, 36, 10, 2.6, 80)
    clay = ramp((190, 100, 70), 5)
    for y in range(22, 36):
        w = 9 - (y - 22) // 5
        for x in range(16 - w, 16 + w):
            cv.put(x, y, clay[3] if x < 12 else clay[2] if x < 18 else clay[1])
    cv.rect(6, 20, 25, 23, clay[3])
    cv.hline(6, 25, 23, clay[1])
    g = ramp((80, 150, 80), 5)
    for cx, cy in ((10, 14), (22, 14), (16, 10)):
        blob(cv, cx, cy, 6, 5, g, seed=seed + cx)
    r = random.Random(seed)
    for cx, cy in ((9, 11), (21, 12), (15, 7), (18, 13), (12, 14)):
        c = r.choice(((244, 110, 140), (250, 220, 90), (170, 150, 240), (255, 250, 240)))
        for dx, dy in ((0, 0), (1, 0), (0, 1), (-1, 0), (0, -1)):
            cv.put(cx + dx, cy + dy, c)
        cv.put(cx, cy, (250, 200, 60))
    cv.outline(OL)
    return cv.img()


def barrel():
    cv = Cv(32, 40)
    shadow_ellipse(cv, 16, 36, 11, 2.8, 80)
    wood = ramp((150, 100, 66), 5)
    for y in range(8, 36):
        bulge = int(2 * math.sin((y - 8) / 28.0 * math.pi))
        for x in range(7 - bulge, 25 + bulge):
            k = 3 if x < 11 else 2 if x < 19 else 1
            if (x - 7) % 5 == 0:
                k -= 1
            cv.put(x, y, wood[max(0, k)])
    for y in (12, 30):
        cv.hline(6, 25, y, (96, 100, 120))
        cv.hline(6, 25, y + 1, (60, 64, 84))
    cv.rect(8, 6, 23, 9, wood[4])
    cv.hline(9, 22, 7, wood[2])
    cv.outline(OL)
    return cv.img()


def bin_():
    cv = Cv(32, 40)
    shadow_ellipse(cv, 16, 36, 9, 2.4, 80)
    m = ramp((100, 118, 120), 5)
    for y in range(12, 36):
        for x in range(9, 24):
            cv.put(x, y, m[3] if x < 12 else m[2] if x < 19 else m[1])
        if (y - 12) % 5 == 0:
            cv.hline(9, 23, y, m[0])
    cv.rect(8, 9, 24, 12, m[4])
    cv.hline(8, 24, 12, m[1])
    cv.rect(14, 6, 18, 8, m[2])
    cv.outline(OL)
    return cv.img()


def mailbox():
    cv = Cv(32, 48)
    shadow_ellipse(cv, 16, 44, 7, 2, 80)
    for y in range(24, 44):
        cv.put(15, y, (150, 104, 70))
        cv.put(16, y, (120, 80, 56))
    red = ramp((190, 60, 60), 5)
    for y in range(12, 25):
        for x in range(8, 25):
            cv.put(x, y, red[3] if y < 15 else red[2] if x < 18 else red[1])
    cv.rect(11, 16, 21, 17, (30, 24, 34))
    cv.rect(22, 6, 23, 14, (250, 210, 80))
    cv.outline(OL)
    return cv.img()


def fence():
    cv = Cv(32, 40)
    shadow_ellipse(cv, 16, 36, 15, 2.4, 60)
    wood = ramp((236, 230, 214), 5)
    for x0 in (2, 12, 22):
        for y in range(10, 35):
            for x in range(x0, x0 + 6):
                cv.put(x, y, wood[3] if x == x0 else wood[2] if x < x0 + 4 else wood[1])
        cv.put(x0 + 2, 9, wood[3])
        cv.put(x0 + 3, 9, wood[3])
        cv.put(x0 + 1, 10, wood[3])
        cv.put(x0 + 4, 10, wood[2])
    for y in (16, 28):
        cv.hline(0, 31, y, (200, 190, 170))
        cv.hline(0, 31, y + 1, (160, 150, 140))
    cv.outline((86, 76, 84))
    return cv.img()


def signpost(left="", right=""):
    cv = Cv(48, 64)
    shadow_ellipse(cv, 24, 60, 8, 2.2, 80)
    wood = ramp((166, 112, 74), 5)
    for y in range(8, 60):
        for x in range(22, 27):
            cv.put(x, y, wood[3] if x == 22 else wood[2] if x < 25 else wood[1])
    for y0, d in ((10, 1), (26, -1)):
        x0, x1 = (8, 40) if d == 1 else (6, 38)
        for y in range(y0, y0 + 12):
            for x in range(x0, x1):
                cv.put(x, y, wood[4] if y == y0 else wood[1] if y == y0 + 11 else wood[3] if (x + y) % 11 else wood[2])
        tip = x1 if d == 1 else x0
        for i in range(6):
            for y in range(y0 + i, y0 + 12 - i):
                cv.put(tip + d * i, y, wood[2])
        for x in range(x0 + 4, x1 - 4, 3):               # painted letters read as small marks
            cv.put(x, y0 + 5, (60, 40, 30))
            cv.put(x + 1, y0 + 6, (60, 40, 30))
    cv.outline(OL)
    return cv.img()


def boat():
    cv = Cv(112, 48)
    shadow_ellipse(cv, 57, 42, 46, 4.4, 80)
    wood = ramp((150, 98, 68), 5)
    blue = ramp((70, 110, 170), 5)
    for x in range(8, 106):
        t = (x - 8) / 97.0
        top = int(20 - 10 * math.sin(t * math.pi) ** 0.6)
        bot = int(32 + 6 * math.sin(t * math.pi))
        for y in range(top, bot):
            k = 3 if y < top + 3 else 1 if y > bot - 5 else 2
            if (x // 6 + y) % 6 == 0:
                k -= 1
            cv.put(x, y, wood[max(0, k)])
        cv.put(x, top, wood[4])
        cv.put(x, top + 4, blue[2])
        cv.put(x, top + 5, blue[3])
    for x in range(18, 98, 14):
        cv.vline(x, 22, 34, wood[0])
    cv.rect(44, 10, 66, 15, wood[3])                      # seat
    cv.hline(44, 66, 10, wood[4])
    cv.outline(OL)
    return cv.img()


def parasol(col=(214, 70, 70)):
    cv = Cv(64, 64)
    shadow_ellipse(cv, 34, 59, 18, 3.6, 70)
    for y in range(14, 60):
        cv.put(32, y, (220, 214, 200))
        cv.put(33, y, (170, 160, 150))
    rp = ramp(col, 5)
    for y in range(6, 24):
        w = (y - 6) / 17.0
        half = int(8 + 22 * w)
        for x in range(32 - half, 32 + half):
            seg = ((x + 40) // 9) % 2
            c = rp[3 if x < 32 else 2] if seg else (250, 244, 230) if x < 32 else (214, 206, 194)
            if y > 20:
                c = mix(c, (30, 30, 60), .25)
            cv.put(x, y, c)
    cv.put(32, 4, (230, 200, 90))
    cv.outline(OL)
    return cv.img()


def crates():
    cv = Cv(32, 40)
    shadow_ellipse(cv, 17, 36, 12, 2.8, 80)
    wood = ramp((180, 130, 84), 5)
    for (x0, y0, s) in ((4, 18, 16), (16, 22, 14)):
        for y in range(y0, y0 + s):
            for x in range(x0, x0 + s):
                k = 3 if (x == x0 or y == y0) else 1 if (x == x0 + s - 1 or y == y0 + s - 1) else 2
                if (y - y0) % 5 == 4:
                    k = 1
                cv.put(x, y, wood[k])
        for i in range(s):
            cv.put(x0 + i, y0 + i, wood[0])
            cv.put(x0 + s - 1 - i, y0 + i, wood[1])
    cv.outline(OL)
    return cv.img()


def driftwood():
    cv = Cv(48, 20)
    shadow_ellipse(cv, 25, 15, 18, 2.2, 60)
    w = ramp((196, 176, 146), 5)
    for x in range(4, 44):
        y = 9 + int(2 * math.sin(x / 9.0))
        for dy in range(4):
            cv.put(x, y + dy, w[3] if dy == 0 else w[0] if dy == 3 else w[2])
    for x in range(10, 40, 7):
        cv.put(x, 8 + int(2 * math.sin(x / 9.0)), w[4])
    cv.outline((110, 90, 80))
    return cv.img()


def lifebuoy():
    cv = Cv(32, 56)
    shadow_ellipse(cv, 17, 52, 7, 2, 80)
    for y in range(20, 52):
        cv.put(15, y, (150, 104, 70))
        cv.put(16, y, (120, 80, 56))
    for y in range(4, 30):
        for x in range(4, 28):
            d = math.hypot(x - 15.5, y - 16.5)
            if 5.5 <= d <= 11.5:
                ang = math.atan2(y - 16.5, x - 15.5)
                seg = int((ang + math.pi) / (math.pi / 2)) % 2
                cv.put(x, y, (244, 244, 240) if seg else (216, 58, 58))
    cv.outline(OL)
    return cv.img()


def net_pile():
    cv = Cv(32, 32)
    shadow_ellipse(cv, 16, 26, 12, 3, 70)
    g = ramp((110, 140, 120), 5)
    blob(cv, 16, 19, 11, 7, g, seed=9)
    for x in range(6, 27, 3):
        cv.vline(x, 14, 24, g[4], 140)
    for y in range(15, 25, 3):
        cv.hline(6, 26, y, g[0], 140)
    cv.outline(OL)
    return cv.img()


def ground_decor():
    """Small flat decals baked into the ground: name -> 32x32 RGBA."""
    out = {}
    cv = Cv(32, 32)
    for y in range(32):
        for x in range(32):
            d = ((x - 15) / 11.0) ** 2 + ((y - 16) / 6.0) ** 2 + 0.25 * math.sin(x / 3.0)
            if d <= 1:
                cv.put(x, y, (96, 138, 170), 150 if d < .7 else 90)
                if y < 14 and x < 16 and d < .8:
                    cv.put(x, y, (220, 236, 250), 110)
    cv.put(12, 14, (255, 255, 255), 200)
    cv.put(13, 14, (255, 255, 255), 160)
    out["puddle"] = cv.img()
    cv = Cv(32, 32)
    for dx, dy in ((16, 16),):
        for y in range(32):
            for x in range(32):
                d = math.hypot(x - 15.5, y - 15.5)
                if d <= 12:
                    c = (72, 74, 90) if d > 10 else (60, 62, 78) if int(d) % 3 else (78, 80, 98)
                    cv.put(x, y, c)
    for x in range(8, 24):
        cv.put(x, 16, (46, 46, 62))
    for y in range(8, 24):
        cv.put(16, y, (46, 46, 62))
    out["manhole"] = cv.img()
    cv = Cv(32, 32)
    r = random.Random(12)
    for _ in range(11):
        x, y = r.randrange(3, 29), r.randrange(3, 29)
        c = r.choice(((200, 120, 56), (170, 96, 50), (224, 168, 72), (150, 80, 46)))
        cv.put(x, y, c)
        cv.put(x + 1, y, mix(c, (60, 30, 20), .3))
        cv.put(x, y + 1, mix(c, (60, 30, 20), .3))
    out["leaves"] = cv.img()
    cv = Cv(32, 32)
    r = random.Random(21)
    for _ in range(6):
        x, y = r.randrange(3, 29), r.randrange(3, 29)
        cv.put(x, y, (150, 142, 130))
        cv.put(x + 1, y, (118, 110, 104))
        cv.put(x, y - 1, (206, 198, 184))
    out["pebbles"] = cv.img()
    cv = Cv(32, 32)
    for i in range(12):                                   # stepping stones to a door
        pass
    for (x, y, rr) in ((9, 8, 6), (22, 22, 6), (10, 24, 4)):
        for yy in range(y - rr, y + rr + 1):
            for xx in range(x - rr, x + rr + 1):
                d = math.hypot(xx - x, (yy - y) * 1.3)
                if d <= rr:
                    cv.put(xx, yy, (186, 178, 164) if xx + yy < x + y else (156, 148, 138))
    out["stones"] = cv.img()
    return out


def grass_fringe():
    """Overlay for the top of a sand tile that touches grass: ragged edge with blades."""
    cv = Cv(T, 12)
    r = random.Random(14)
    for x in range(T):
        h = 3 + int(2.2 * math.sin(x / 3.1) + 1.4 * math.sin(x / 1.7 + 1)) + r.randrange(2)
        for y in range(0, max(1, h)):
            cv.put(x, y, GRASS[1] if y < h - 1 else GRASS[0])
        if r.random() < .35:
            cv.put(x, h, GRASS[3])
            cv.put(x, h + 1, (206, 192, 140), 140)
        cv.put(x, max(0, h - 3), GRASS[3]) if r.random() < .4 else None
    return cv.img()
