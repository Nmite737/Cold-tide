"""Pixel art for the inside of the police station and the cafe (and the two police sprites).
Imported by make_assets.py, which adds these images to every texture pack.
Everything is drawn on a 16 px grid; the 2x pack simply scales it up.
Run  python make_interior_art.py  to write a preview sheet (interior_preview.png).
"""
from PIL import Image, ImageDraw

O = (62, 42, 40, 255)          # outline, same as the rest of the game


def c(*rgb):
    return tuple(rgb) + (255,)


def new(w, h):
    """Blank image w x h TILES big."""
    return Image.new("RGBA", (w * 16, h * 16), (0, 0, 0, 0))


def box(d, x0, y0, x1, y1, fill, line=O):
    d.rectangle([x0, y0, x1, y1], fill=fill, outline=line)


# ------------------------------------------------------------------ palettes
WOOD, WOOD_D, WOOD_L = c(176, 120, 80), c(146, 96, 60), c(206, 154, 108)
CREAM, CREAM_D = c(238, 228, 206), c(214, 200, 174)
NAVY, NAVY_L = c(60, 80, 130), c(92, 114, 168)
GREY, GREY_D, GREY_L = c(150, 156, 170), c(110, 116, 132), c(196, 202, 214)
GOLD, RED, GREEN = c(232, 190, 60), c(170, 60, 56), c(86, 148, 80)

# ------------------------------------------------------------------ floors and walls


def floor_police(dark):
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    a, b = (c(226, 224, 214), c(204, 204, 200)) if not dark else (c(204, 204, 200), c(226, 224, 214))
    d.rectangle([0, 0, 15, 15], fill=a)
    d.rectangle([0, 0, 7, 7], fill=b)
    d.rectangle([8, 8, 15, 15], fill=b)
    d.line([0, 15, 15, 15], fill=c(190, 190, 188))
    d.line([15, 0, 15, 15], fill=c(190, 190, 188))
    return im


def floor_wood(alt):
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    base = c(196, 146, 100) if not alt else c(188, 138, 94)
    d.rectangle([0, 0, 15, 15], fill=base)
    for y in (0, 5, 10):
        d.line([0, y + 4, 15, y + 4], fill=c(150, 100, 64))
    off = 3 if alt else 9
    for y in (0, 5, 10):
        d.point([(off + y) % 16, y + 2], fill=c(150, 100, 64))
        d.point([(off + y + 1) % 16, y + 1], fill=c(214, 168, 120))
    return im


def floor_store():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 15], fill=c(150, 112, 84))
    for x in (3, 8, 13):
        d.line([x, 0, x, 15], fill=c(120, 88, 66))
    d.point([(5, 4), (10, 11), (2, 13)], fill=c(172, 132, 100))
    return im


def wall_top(theme):
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    col = c(176, 190, 214) if theme == "p" else c(232, 208, 168)
    dark = c(160, 174, 200) if theme == "p" else c(214, 188, 148)
    d.rectangle([0, 0, 15, 15], fill=col)
    for x in range(0, 16, 4):
        d.line([x, 0, x, 15], fill=dark)
    d.line([0, 0, 15, 0], fill=O)
    return im


def wall_base(theme):
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    col = c(176, 190, 214) if theme == "p" else c(232, 208, 168)
    panel = NAVY if theme == "p" else WOOD_D
    rail = c(214, 220, 232) if theme == "p" else WOOD_L
    d.rectangle([0, 0, 15, 15], fill=col)
    d.rectangle([0, 6, 15, 15], fill=panel)
    d.line([0, 6, 15, 6], fill=rail)
    d.line([0, 15, 15, 15], fill=O)
    d.line([0, 11, 15, 11], fill=NAVY_L if theme == "p" else WOOD)
    return im


def wall_fill(theme):
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 15], fill=c(70, 58, 62) if theme == "p" else c(84, 58, 48))
    d.line([0, 0, 15, 0], fill=c(100, 86, 92) if theme == "p" else c(120, 84, 68))
    return im


def door_front():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 15], fill=c(70, 58, 62))
    box(d, 1, 0, 14, 15, WOOD_D)
    box(d, 3, 2, 12, 9, c(148, 192, 216))
    d.line([8, 2, 8, 9], fill=O)
    d.point([(12, 12)], fill=GOLD)
    return im


def mat():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    box(d, 1, 3, 14, 12, c(120, 60, 56))
    d.rectangle([3, 5, 12, 10], outline=c(190, 140, 110))
    return im


def door_closed():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 15], fill=c(84, 58, 48))
    box(d, 1, 0, 14, 15, WOOD_D)
    box(d, 3, 2, 12, 13, WOOD)
    d.point([(11, 8)], fill=GOLD)
    return im


def tape_v():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    for y in range(0, 16, 4):
        d.rectangle([6, y, 9, y + 1], fill=GOLD)
        d.rectangle([6, y + 2, 9, y + 3], fill=O)
    return im


# ------------------------------------------------------------------ wall decorations


def window():
    im = new(2, 2)
    d = ImageDraw.Draw(im)
    box(d, 3, 3, 28, 26, c(226, 214, 190))
    box(d, 6, 6, 25, 23, c(148, 192, 216))
    d.line([15, 6, 15, 23], fill=O)
    d.line([6, 14, 25, 14], fill=O)
    d.line([8, 8, 11, 8], fill=c(220, 240, 250))
    d.line([8, 9, 9, 9], fill=c(220, 240, 250))
    return im


def clock():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    d.ellipse([1, 1, 14, 14], fill=CREAM, outline=O)
    d.line([8, 8, 8, 4], fill=O)
    d.line([8, 8, 11, 9], fill=O)
    d.point([(8, 8)], fill=RED)
    return im


def clock_broken():
    im = clock()
    d = ImageDraw.Draw(im)
    d.line([3, 3, 7, 7], fill=O)                      # crack
    d.line([7, 7, 5, 11], fill=O)
    return im


def poster():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    box(d, 3, 2, 12, 14, c(236, 224, 190))
    d.rectangle([5, 4, 10, 5], fill=RED)
    d.ellipse([6, 6, 9, 9], fill=GREY_D)
    d.rectangle([5, 10, 10, 11], fill=GREY_D)
    return im


def board():
    """Cork board for the suspect photos (3 x 2 tiles)."""
    im = new(3, 2)
    d = ImageDraw.Draw(im)
    box(d, 1, 1, 46, 30, c(196, 150, 100))
    d.rectangle([4, 4, 43, 27], fill=c(212, 168, 116))
    for i in range(6):
        x = 6 + (i % 3) * 13
        y = 5 + (i // 3) * 12
        box(d, x, y, x + 9, y + 8, CREAM)
        d.rectangle([x + 2, y + 1, x + 7, y + 6], fill=GREY_D)
        d.point([(x + 4, y)], fill=RED)
    d.line([12, 12, 26, 17], fill=RED)
    d.line([26, 17, 38, 10], fill=RED)
    return im


def menu_board():
    im = new(2, 1)
    d = ImageDraw.Draw(im)
    box(d, 1, 1, 30, 14, c(52, 60, 56))
    d.rectangle([2, 2, 29, 13], outline=WOOD_L)
    for i, y in enumerate((4, 7, 10)):
        d.line([5, y, 5 + 10 + (i * 5) % 9, y], fill=c(230, 230, 220))
        d.line([24, y, 27, y], fill=c(230, 230, 220))
    return im


def shelf_wall():
    im = new(2, 1)
    d = ImageDraw.Draw(im)
    box(d, 1, 8, 30, 10, WOOD_D)
    for x, col in ((3, RED), (8, GREEN), (13, NAVY), (18, GOLD), (23, c(150, 90, 150))):
        box(d, x, 2, x + 3, 7, col)
    return im


# ------------------------------------------------------------------ police furniture


def desk(w, boss=False):
    im = new(w, 1)
    d = ImageDraw.Draw(im)
    W = w * 16
    box(d, 0, 2, W - 1, 15, WOOD_D)
    box(d, 0, 0, W - 1, 8, WOOD_L)
    d.line([2, 12, W - 3, 12], fill=WOOD)
    if boss:
        box(d, 4, 2, 14, 7, CREAM)                    # papers
        d.line([6, 4, 12, 4], fill=GREY_D)
        box(d, W // 2 - 6, 3, W // 2 + 6, 6, GOLD)    # name plate
        box(d, W - 14, 1, W - 6, 6, GREY_D)           # monitor
    else:
        box(d, 4, 1, 14, 7, GREY_D)                   # monitor
        d.rectangle([6, 3, 12, 5], fill=c(120, 200, 190))
        box(d, W - 12, 3, W - 4, 7, CREAM)
    return im


def bench():
    im = new(2, 1)
    d = ImageDraw.Draw(im)
    box(d, 0, 3, 31, 9, c(110, 100, 120))
    box(d, 1, 9, 4, 15, GREY_D)
    box(d, 27, 9, 30, 15, GREY_D)
    d.line([2, 5, 29, 5], fill=c(140, 130, 150))
    return im


def cabinet():
    im = new(1, 2)
    d = ImageDraw.Draw(im)
    box(d, 1, 2, 14, 31, GREY)
    for y in (4, 13, 22):
        box(d, 3, y, 12, y + 7, GREY_L)
        d.rectangle([6, y + 3, 9, y + 4], fill=O)
    return im


def coffee_machine():
    im = new(1, 2)
    d = ImageDraw.Draw(im)
    box(d, 2, 4, 13, 31, c(70, 70, 84))
    box(d, 4, 6, 11, 12, GREY_L)
    d.point([(10, 9)], fill=RED)
    box(d, 5, 18, 10, 26, c(30, 24, 28))
    box(d, 6, 22, 9, 26, CREAM)
    return im


def locker():
    im = new(2, 2)
    d = ImageDraw.Draw(im)
    box(d, 1, 2, 30, 31, GREY_D)
    d.rectangle([3, 4, 28, 29], fill=c(60, 62, 74))
    for x in range(5, 28, 4):
        d.line([x, 4, x, 29], fill=GREY_L)
    for y in (10, 17, 24):
        d.line([3, y, 28, y], fill=GREY)
    box(d, 6, 19, 12, 23, WOOD)
    box(d, 17, 12, 24, 16, CREAM)
    return im


def cell_back():
    im = new(4, 3)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 63, 47], fill=c(150, 150, 158))
    for x in range(0, 64, 16):
        d.line([x, 0, x, 47], fill=c(130, 130, 140))
    box(d, 4, 8, 26, 22, c(90, 110, 160))             # cot
    d.rectangle([4, 8, 9, 22], fill=CREAM)
    box(d, 44, 8, 56, 18, c(100, 104, 116))           # toilet corner
    return im


def cell_bars():
    im = new(4, 3)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 63, 3], fill=GREY_D, outline=O)
    d.rectangle([0, 44, 63, 47], fill=GREY_D, outline=O)
    for x in range(2, 64, 6):
        d.rectangle([x, 4, x + 1, 44], fill=GREY_L, outline=None)
        d.line([x + 2, 4, x + 2, 44], fill=O)
    d.rectangle([0, 0, 2, 47], fill=GREY_D)
    d.rectangle([61, 0, 63, 47], fill=GREY_D)
    return im


def plant():
    im = new(1, 2)
    d = ImageDraw.Draw(im)
    box(d, 3, 22, 12, 31, c(180, 90, 70))
    d.rectangle([4, 23, 11, 24], fill=c(210, 120, 96))
    for pts in ([(8, 22), (3, 10), (6, 8)], [(8, 22), (13, 9), (10, 7)], [(8, 22), (8, 3), (10, 12)]):
        d.polygon(pts, fill=GREEN, outline=O)
    return im


def bin_():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    box(d, 4, 5, 11, 14, GREY)
    d.line([4, 5, 11, 5], fill=GREY_L)
    d.line([6, 8, 6, 13], fill=GREY_D)
    d.line([9, 8, 9, 13], fill=GREY_D)
    return im


def rug(col=(150, 70, 66)):
    im = new(4, 2)
    d = ImageDraw.Draw(im)
    d.rectangle([1, 2, 62, 29], fill=c(*col), outline=O)
    d.rectangle([4, 5, 59, 26], outline=c(220, 190, 150))
    d.rectangle([8, 9, 55, 22], outline=c(220, 190, 150))
    return im


# ------------------------------------------------------------------ cafe furniture


def counter(kind):
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    box(d, 0, 2, 15, 15, WOOD_D)
    box(d, 0, 0, 15, 7, WOOD_L)
    d.line([2, 12, 13, 12], fill=WOOD)
    if kind == "l":
        d.line([0, 0, 0, 15], fill=O)
    if kind == "r":
        d.line([15, 0, 15, 15], fill=O)
    return im


def register():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    box(d, 3, 0, 12, 6, c(70, 70, 84))
    d.rectangle([5, 1, 10, 3], fill=c(120, 200, 190))
    d.rectangle([4, 5, 11, 6], fill=GREY_L)
    return im


def mug():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    box(d, 5, 2, 9, 6, CREAM)
    d.point([(10, 3), (10, 4)], fill=O)
    d.line([6, 3, 8, 3], fill=c(92, 58, 40))
    return im


def book():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    box(d, 2, 1, 7, 7, c(236, 224, 190))
    box(d, 8, 1, 13, 7, c(226, 214, 180))
    d.line([8, 1, 8, 7], fill=O)
    for y in (3, 5):
        d.line([3, y, 6, y], fill=GREY_D)
        d.line([9, y, 12, y], fill=GREY_D)
    return im


def table():
    """Table with a chair on each side (2 x 2 tiles)."""
    im = new(2, 2)
    d = ImageDraw.Draw(im)
    box(d, 8, 0, 23, 6, c(150, 90, 70))               # chair top
    box(d, 8, 25, 23, 31, c(150, 90, 70))             # chair bottom
    box(d, 1, 7, 30, 24, WOOD_L)
    d.rectangle([2, 8, 29, 20], fill=c(214, 164, 116))
    d.line([2, 21, 29, 21], fill=WOOD)
    box(d, 12, 11, 19, 16, CREAM)                     # plate / cloth
    d.line([14, 13, 17, 13], fill=GREY)
    return im


def teacup():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    box(d, 3, 8, 8, 12, c(150, 190, 210))
    d.point([(9, 9), (9, 10)], fill=O)
    d.line([4, 9, 7, 9], fill=c(92, 58, 40))
    return im


def nora_desk():
    im = new(2, 1)
    d = ImageDraw.Draw(im)
    box(d, 0, 2, 31, 15, WOOD_D)
    box(d, 0, 0, 31, 8, WOOD_L)
    box(d, 3, 1, 14, 7, CREAM)                        # stack of papers
    d.line([5, 3, 12, 3], fill=RED)
    d.line([5, 5, 10, 5], fill=GREY_D)
    box(d, 22, 2, 27, 7, c(60, 120, 90))              # lamp
    return im


def jukebox():
    im = new(1, 2)
    d = ImageDraw.Draw(im)
    box(d, 1, 3, 14, 31, c(170, 60, 70))
    d.ellipse([2, 3, 13, 14], fill=c(240, 200, 120), outline=O)
    box(d, 4, 18, 11, 26, c(60, 40, 60))
    d.point([(5, 28), (8, 28), (11, 28)], fill=GOLD)
    return im


def kitchen_door():
    im = new(1, 2)
    d = ImageDraw.Draw(im)
    box(d, 1, 1, 14, 31, c(196, 190, 170))
    d.ellipse([4, 6, 11, 13], fill=c(148, 192, 216), outline=O)
    box(d, 12, 18, 13, 22, GREY_D)
    return im


def shelf():
    im = new(2, 2)
    d = ImageDraw.Draw(im)
    box(d, 1, 3, 30, 31, WOOD_D)
    for y in (12, 21):
        d.line([2, y, 29, y], fill=WOOD_L)
    for (x, y, w, h, col) in ((3, 5, 7, 6, c(190, 150, 100)), (12, 6, 6, 5, RED), (20, 4, 8, 7, c(190, 150, 100)),
                              (4, 14, 8, 6, c(190, 150, 100)), (15, 15, 5, 5, GREEN), (22, 14, 6, 6, NAVY),
                              (5, 23, 6, 7, c(190, 150, 100)), (14, 24, 12, 6, c(210, 190, 140))):
        box(d, x, y, x + w, y + h, col)
    return im


def crates():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    box(d, 1, 6, 10, 15, c(190, 150, 100))
    d.line([1, 10, 10, 10], fill=WOOD_D)
    box(d, 6, 1, 14, 9, c(176, 130, 86))
    d.line([6, 5, 14, 5], fill=WOOD_D)
    return im


def ledger_desk():
    im = new(2, 1)
    d = ImageDraw.Draw(im)
    box(d, 0, 2, 31, 15, WOOD_D)
    box(d, 0, 0, 31, 8, WOOD_L)
    box(d, 5, 1, 12, 7, c(236, 224, 190))
    box(d, 13, 1, 20, 7, c(226, 214, 180))
    d.line([13, 1, 13, 7], fill=O)
    for y in (3, 5):
        d.line([6, y, 11, y], fill=GREY_D)
        d.line([14, y, 19, y], fill=RED if y == 5 else GREY_D)
    d.rectangle([24, 2, 27, 6], fill=c(40, 40, 60))   # ink pot
    return im


def chalk():
    """Chalk outline of the victim (2 x 1 tile)."""
    im = new(2, 1)
    d = ImageDraw.Draw(im)
    w = c(236, 236, 230)
    d.ellipse([2, 5, 7, 10], outline=w)
    d.line([8, 6, 20, 6], fill=w)
    d.line([8, 9, 20, 9], fill=w)
    d.line([20, 6, 28, 4], fill=w)
    d.line([20, 9, 28, 12], fill=w)
    d.line([28, 4, 29, 12], fill=w)
    d.line([12, 6, 10, 1], fill=w)
    d.line([12, 9, 10, 14], fill=w)
    return im


def cup_spill():
    im = new(1, 1)
    d = ImageDraw.Draw(im)
    d.ellipse([2, 8, 13, 14], fill=c(92, 58, 40))     # puddle
    box(d, 5, 4, 10, 9, CREAM)
    d.point([(11, 5), (11, 6)], fill=O)
    return im


def stove():
    im = new(2, 1)
    d = ImageDraw.Draw(im)
    box(d, 0, 2, 31, 15, GREY_D)
    box(d, 0, 0, 31, 8, GREY)
    for x in (6, 20):
        d.ellipse([x, 2, x + 6, 6], fill=c(40, 40, 50), outline=O)
    return im


# ------------------------------------------------------------------ everything


def interior_tiles():
    """name -> 1x PIL image."""
    g = {
        "i_floor_p1": floor_police(False), "i_floor_p2": floor_police(True),
        "i_floor_c1": floor_wood(False), "i_floor_c2": floor_wood(True), "i_floor_s": floor_store(),
        "i_wall_p": wall_top("p"), "i_wallb_p": wall_base("p"), "i_fill_p": wall_fill("p"),
        "i_wall_c": wall_top("c"), "i_wallb_c": wall_base("c"), "i_fill_c": wall_fill("c"),
        "i_door": door_front(), "i_mat": mat(), "i_door_closed": door_closed(), "i_tape_v": tape_v(),
        "i_window": window(), "i_clock": clock(), "i_clock_broken": clock_broken(), "i_poster": poster(),
        "i_board": board(), "i_menu": menu_board(), "i_shelf_wall": shelf_wall(),
        "i_desk3": desk(3, True), "i_desk2": desk(2), "i_bench": bench(), "i_cabinet": cabinet(),
        "i_coffeem": coffee_machine(), "i_locker": locker(), "i_cell_back": cell_back(),
        "i_cell_bars": cell_bars(), "i_plant": plant(), "i_bin": bin_(), "i_rug": rug(),
        "i_rug_c": rug((70, 110, 96)),
        "i_counter_l": counter("l"), "i_counter_m": counter("m"), "i_counter_r": counter("r"),
        "i_register": register(), "i_mug": mug(), "i_book": book(), "i_table": table(),
        "i_teacup": teacup(), "i_nora_desk": nora_desk(), "i_jukebox": jukebox(),
        "i_kitchen_door": kitchen_door(), "i_shelf": shelf(), "i_crates": crates(),
        "i_ledger_desk": ledger_desk(), "i_chalk": chalk(), "i_cup": cup_spill(), "i_stove": stove(),
    }
    return g


# ------------------------------------------------------------------ police sprites (recolored)
# The two police officers reuse the chef and dog-walker sheets with new clothes.
RECOLORS = {
    "police-chief": ("work-chef", {
        (231, 220, 192): (52, 66, 112),       # toque -> peaked cap
        (180, 171, 149): (38, 48, 84),        # cap shade
        (130, 52, 52): (60, 80, 130),         # apron -> uniform
        (201, 201, 201): (232, 190, 60),      # badge / collar
        (92, 74, 60): (40, 48, 76),           # trousers
    }),
    "police-officer": ("folk-dogwalker", {
        (130, 52, 52): (58, 40, 36),          # hair/cap -> dark hair
        (101, 40, 40): (44, 30, 28),
        (92, 110, 74): (84, 118, 170),        # jacket -> light blue shirt
        (71, 85, 57): (64, 92, 136),
        (107, 86, 121): (232, 190, 60),       # scarf -> badge colour
        (138, 111, 156): (246, 214, 110),
        (74, 58, 48): (40, 48, 76),           # trousers
    }),
}


def recolor(sheet, mapping):
    im = sheet.convert("RGBA")
    px = im.load()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = px[x, y]
            if a and (r, g, b) in mapping:
                px[x, y] = mapping[(r, g, b)] + (a,)
    return im


if __name__ == "__main__":
    tiles = interior_tiles()
    names = sorted(tiles)
    S = 2
    W = 1000
    x = y = rowh = 0
    sheet = Image.new("RGBA", (W, 1000), (120, 150, 170, 255))
    for n in names:
        im = tiles[n].resize((tiles[n].width * S, tiles[n].height * S), Image.NEAREST)
        if x + im.width > W:
            x, y, rowh = 0, y + rowh + 6, 0
        sheet.alpha_composite(im, (x, y))
        x += im.width + 6
        rowh = max(rowh, im.height)
    sheet.crop((0, 0, W, y + rowh + 6)).save("interior_preview.png")
    print(len(names), "interior images")
