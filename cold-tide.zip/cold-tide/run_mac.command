#!/bin/bash
# Cold Tide launcher (macOS / Linux). Needs Python 3.9 or newer.
cd "$(dirname "$0")"
PY=""
for c in python3.14 python3.13 python3.12 python3.11 python3.10 python3.9 python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)'; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
  echo "Cold Tide needs Python 3.9 or newer. Get it from https://www.python.org/downloads/"
  read -n 1 -s -r -p "Press any key to close"; exit 1
fi
if [ -x .venv/bin/python ] && ! .venv/bin/python -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)'; then rm -rf .venv; fi
[ -x .venv/bin/python ] || "$PY" -m venv .venv || exit 1
.venv/bin/python -c "import pygame" >/dev/null 2>&1 || .venv/bin/python -m pip install --disable-pip-version-check -r requirements.txt || exit 1
.venv/bin/python main.py
