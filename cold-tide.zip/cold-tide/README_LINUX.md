# Cold Tide on Linux (Ubuntu, Linux Mint and others)

Cold Tide needs **Python 3.9 or newer** and **pygame-ce** (installed automatically into a private folder).
Tested with Python 3.9, 3.10, 3.11, 3.12, 3.13 and 3.14 - that covers the default Python of
**Ubuntu 22.04 (3.10) and 24.04 (3.12)** and **Linux Mint 21.x (3.10) and 22.x (3.12)**.

## Quick start (any Ubuntu / Mint / Debian)

```bash
cd cold-tide            # the folder you unzipped
./install_linux.sh      # once: checks dependencies, makes .venv, installs pygame-ce, tests it
./run_linux.sh          # play
```

If the scripts are not executable (some unzip tools drop the permission): `chmod +x install_linux.sh run_linux.sh`
or run them as `bash install_linux.sh`.

`run_linux.sh` works from any folder (also through a symlink or a desktop entry). If the game is not installed yet
it runs the installer for you. Add a "Cold Tide" entry to the application menu with `./install_linux.sh --desktop`.

## Ubuntu

1. Open a terminal and install the three system packages (one time; the installer offers to do this for you):
   ```bash
   sudo apt update
   sudo apt install python3 python3-venv python3-pip
   ```
2. `./install_linux.sh` then `./run_linux.sh`.

## Linux Mint

Same as Ubuntu (Mint is Ubuntu-based; Mint 21 = Ubuntu 22.04, Mint 22 = Ubuntu 24.04):

```bash
sudo apt update
sudo apt install python3 python3-venv python3-pip
./install_linux.sh && ./run_linux.sh
```
On Mint, `python3-venv` is the package most often missing; the installer detects that and tells you.

## Other distributions

* Fedora: `sudo dnf install python3 python3-pip` &nbsp; * Arch: `sudo pacman -S python python-pip`
* openSUSE: `sudo zypper install python3 python3-pip`

then `./install_linux.sh`. (On these the installer prints the command instead of running it.)

## Required dependencies

| What | Why | Needed from you? |
|---|---|---|
| Python 3.9+ | the language | yes (usually preinstalled) |
| `python3-venv`, `python3-pip` | private environment + package installer | on Ubuntu/Mint, yes |
| internet (once) | download pygame-ce (about 12 MB) | yes, only for installation |
| pygame-ce | the game library; its wheel **bundles SDL2**, SDL_mixer, SDL_ttf | no, installed automatically |
| PulseAudio or PipeWire or ALSA | sound | already there on a desktop; without it the game runs silently |

No compiler and no `libsdl2-dev` are needed, because pygame-ce ships ready-made Linux wheels (x86-64 and ARM64).
Only if pip had to *compile* it (very old / unusual system) you need:
`sudo apt install build-essential python3-dev libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev libfreetype-dev libportmidi-dev`.

## Where things are stored

* settings: `~/.config/cold-tide/settings.json`
* save game: `~/.local/share/cold-tide/save.json`

(If you already have a `~/.cold_tide` folder from an older version or from another computer, that folder keeps
being used, so no save is lost. `COLD_TIDE_HOME=/folder` puts both in one place. Back up a save by copying `save.json`.)

## Controls and display

WASD / arrow keys (also **ZQSD** on French keyboards) to move, **E** interact, **F11** or **Alt+Enter** fullscreen,
**ESC** menu. The window is resizable; menus also work with the mouse. Settings > *Window size* picks a start size.
On a 1920x1080 screen fullscreen is an exact 2x of the game picture (perfectly sharp); in other sizes the HD art is
smoothly scaled so it does not shimmer. *Pixel-perfect scaling* forces whole-number scaling.

## Troubleshooting

First, always try: `./run_linux.sh --selftest` - it prints the Python / pygame / SDL versions, the video and audio
driver in use, the save paths, and renders every scene with every texture pack.

| Problem | Fix |
|---|---|
| `Permission denied` | `chmod +x install_linux.sh run_linux.sh` |
| `The 'venv' module is missing` | `sudo apt install python3-venv python3-pip`, run the installer again |
| `No matching distribution` / pip errors | check the internet / proxy (`export HTTPS_PROXY=...`); make sure Python is 3.9-3.14 (`python3 --version`); then `./install_linux.sh --recreate` |
| `externally-managed-environment` | you ran plain `pip install`; use the installer instead - it uses a venv, which is exactly the fix for this |
| Game says pygame-ce is not installed / `.venv` damaged | `./install_linux.sh --recreate` |
| No sound | check `pactl info` (PulseAudio/PipeWire). Try `SDL_AUDIODRIVER=pulseaudio ./run_linux.sh`, or `alsa`, or `pipewire`. The game tries these on its own but you can force one. Sound OFF in `--selftest` means no usable device was found; the game still plays. |
| Crackling sound | the game already uses a larger buffer; also try `SDL_AUDIODRIVER=alsa` |
| Black window / flicker / wrong size on **Wayland** | `SDL_VIDEODRIVER=x11 ./run_linux.sh` (runs through XWayland) |
| Over ssh / no desktop | there is nothing to see, but `./run_linux.sh --selftest` still verifies the installation (uses an invisible dummy display) |
| Slow on an old PC | Settings > *Texture pack* > `cozy` (16 px, much lighter), switch *Day / night lighting* off, use a smaller window size |
| Chinese text shows squares | the game ships its own font for Chinese; update to the latest files and use `--selftest` to confirm |
| Fullscreen does not work in a VM or remote desktop | the game falls back to a window by itself; use the window size setting |
| Wrong language after copying settings | delete `~/.config/cold-tide/settings.json` |

## Uninstall / clean up

* Remove only the Python packages (keep the game): `rm -rf .venv` (re-create with `./install_linux.sh`).
* Remove the menu entry (if you added it): `rm ~/.local/share/applications/cold-tide.desktop`
* Remove your settings and saves: `rm -r ~/.config/cold-tide ~/.local/share/cold-tide` (and `~/.cold_tide` if you had one).
* Remove the game: delete the folder. The installer changes nothing outside the game folder
  (except the optional menu entry and the optional `sudo apt install` you confirm).

## Known limitations

* Tested here on Ubuntu 24.04 (the base of Linux Mint 22) with Python 3.9-3.14, a real X11 server (Xvfb: window,
  resize, fullscreen, keyboard events) and PulseAudio (null sink). **Not tested** on physical Mint / Ubuntu desktops,
  with real speakers, on Wayland sessions, on ARM, or on distributions other than Ubuntu.
* Python 3.8 and older are not supported (pygame-ce no longer ships wheels for them).
