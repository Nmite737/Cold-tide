"""Builds the texture packs in assets/packs/ from the Cozy Town / Cozy Characters
Lite zips (extracted into ./source) and draws the tiles the free packs do not
contain (sand, water, trees, houses, police station, hotel, icons...).

Run:  python make_assets.py        (needs Pillow:  pip install pillow)

Packs created:
  cozy     16 px tiles, the original pixel art
  cozy-2x  32 px tiles, official 2x art (generated pieces are upscaled)
  noir     16 px, black-and-white detective look
To add your own pack: copy a folder in assets/packs, keep the file names and
edit pack.json ("tile_size").
"""
import json
import random
import shutil
import sys
from pathlib import Path

from PIL import Image, ImageDraw

import make_interior_art as MIA

BASE = Path(__file__).resolve().parent
SRC = BASE / "source"
OUT = BASE / "assets" / "packs"
TOWN = SRC / "cozy-town-lite"
CHARS = SRC / "cozy-characters-lite"

OUTLINE = (62, 42, 40, 255)
NPC_SHEETS = ["folk-grandma", "folk-dogwalker", "work-chef",
              "school-teacher", "season-pumpkin", "shop-barista"]


def c(rgb):
    return tuple(rgb) + (255,)


def shade(rgb, k):
    return tuple(max(0, min(255, int(v * k))) for v in rgb[:3]) + (255,)


# ---------------------------------------------------------------- tiles
def tile():
    return Image.new("RGBA", (16, 16), (0, 0, 0, 0))


def gen_sand(seed):
    r = random.Random(seed)
    im = Image.new("RGBA", (16, 16), c((232, 214, 160)))
    px = im.load()
    for _ in range(14):
        px[r.randrange(16), r.randrange(16)] = c((214, 194, 140))
    for _ in range(6):
        px[r.randrange(16), r.randrange(16)] = c((244, 230, 185))
    if seed % 2:
        px[5, 9] = c((250, 244, 230))
        px[6, 9] = c((236, 200, 190))
    return im


def gen_water(phase):
    im = Image.new("RGBA", (16, 16), c((90, 158, 146)))
    d = ImageDraw.Draw(im)
    for i, (x, y) in enumerate([(1, 3), (9, 7), (3, 12), (11, 14)]):
        x = (x + phase * 3) % 14
        d.line([x, y, x + 3, y], fill=c((112, 178, 164)))
    d.point([(2 + phase * 5) % 16, 5], fill=c((146, 204, 182)))
    d.point([(10 + phase * 4) % 16, 10], fill=c((146, 204, 182)))
    return im


def gen_tree():
    im = tile()
    d = ImageDraw.Draw(im)
    d.rectangle([6, 10, 9, 15], fill=c((110, 70, 46)), outline=OUTLINE)
    d.ellipse([0, 0, 15, 12], fill=c((86, 148, 80)), outline=OUTLINE)
    d.ellipse([2, 2, 9, 7], fill=c((106, 170, 92)))
    d.point([(4, 3), (5, 3), (4, 4)], fill=c((136, 194, 106)))
    return im


def gen_rock():
    im = tile()
    d = ImageDraw.Draw(im)
    d.ellipse([2, 6, 13, 14], fill=c((110, 108, 120)), outline=OUTLINE)
    d.line([5, 8, 8, 8], fill=c((178, 168, 148)))
    return im


def gen_mound(dug=False):
    im = tile()
    d = ImageDraw.Draw(im)
    if dug:
        d.ellipse([2, 6, 13, 13], fill=OUTLINE)
        d.ellipse([3, 7, 12, 12], fill=c((92, 58, 40)))
    else:
        d.ellipse([1, 5, 14, 14], fill=c((146, 96, 60)), outline=OUTLINE)
        d.ellipse([3, 6, 10, 10], fill=c((176, 120, 80)))
        d.point([(11, 11), (5, 12), (8, 12)], fill=c((110, 70, 46)))
    return im


def gen_marker():
    im = tile()
    d = ImageDraw.Draw(im)
    d.polygon([(8, 4), (13, 14), (3, 14)], fill=c((232, 190, 60)), outline=OUTLINE)
    d.line([8, 8, 8, 12], fill=OUTLINE)
    return im


def gen_tape():
    im = tile()
    d = ImageDraw.Draw(im)
    for x in range(0, 16, 4):
        d.rectangle([x, 6, x + 1, 8], fill=c((232, 190, 60)))
        d.rectangle([x + 2, 6, x + 3, 8], fill=OUTLINE)
    return im


def gen_cctv():
    im = tile()
    d = ImageDraw.Draw(im)
    d.rectangle([7, 4, 8, 15], fill=c((110, 108, 120)), outline=OUTLINE)
    d.rectangle([3, 1, 12, 5], fill=OUTLINE)
    d.rectangle([4, 2, 11, 4], fill=c((70, 70, 84)))
    d.point([(11, 2)], fill=c((220, 60, 60)))
    return im


def gen_icon(kind):
    im = tile()
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, 15, 15], 3, fill=c((62, 42, 40)))
    if kind == "prints":
        for r in (2, 4, 6):
            d.arc([8 - r, 8 - r, 8 + r, 8 + r], 190, 350, fill=c((238, 228, 206)))
        d.line([8, 8, 8, 13], fill=c((238, 228, 206)))
        d.line([5, 9, 5, 12], fill=c((238, 228, 206)))
    elif kind == "scan":
        d.rectangle([3, 3, 12, 12], outline=c((146, 204, 182)))
        d.line([8, 1, 8, 14], fill=c((146, 204, 182)))
        d.line([1, 8, 14, 8], fill=c((146, 204, 182)))
        d.point([(8, 8)], fill=c((220, 60, 60)))
    else:
        d.line([4, 12, 11, 4], fill=c((176, 120, 80)), width=2)
        d.polygon([(10, 9), (14, 13), (12, 15), (8, 11)], fill=c((178, 168, 148)))
    return im


# ------------------------------------------------------------ buildings
LETTERS = {
    "H": "101101111101101", "O": "111101101101111", "T": "111010010010010",
    "E": "111100110100111", "L": "100100100100111", "P": "111101111100100",
    "I": "111010010010111", "C": "111100100100111", "D": "110101101101110",
}


def draw_text(d, x, y, text, col):
    for ch in text:
        bits = LETTERS[ch]
        for i, b in enumerate(bits):
            if b == "1":
                d.point([x + i % 3, y + i // 3], fill=col)
        x += 4


def gen_building(w, h, wall, roof, trim, sign=None, sign_col=(60, 80, 130)):
    W, H = w * 16, h * 16
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    roof_h = int(H * 0.42)
    d.rectangle([W - 22, 0, W - 16, roof_h - 4], fill=c((146, 96, 60)), outline=OUTLINE)
    d.rectangle([1, 5, W - 2, roof_h], fill=c(roof), outline=OUTLINE)
    for y in range(9, roof_h, 5):
        d.line([2, y, W - 3, y], fill=shade(roof, 0.8))
    d.line([2, 6, W - 3, 6], fill=shade(roof, 1.2))
    d.rectangle([3, roof_h + 1, W - 4, H - 1], fill=c(wall), outline=OUTLINE)
    d.rectangle([4, roof_h + 1, W - 5, roof_h + 3], fill=c(trim))
    dc = w // 2
    cols = [dc - 1, dc + 1] + ([0, w - 1] if w >= 6 else [])
    for col in cols:
        if 0 <= col < w:
            x0 = col * 16 + 2
            d.rectangle([x0, roof_h + 7, x0 + 11, roof_h + 18], fill=c((148, 192, 216)),
                        outline=OUTLINE)
            d.line([x0 + 6, roof_h + 7, x0 + 6, roof_h + 18], fill=c(trim))
    dx = dc * 16 + 2
    d.rectangle([dx, H - 17, dx + 11, H - 1], fill=c((110, 70, 46)), outline=OUTLINE)
    d.rectangle([dx + 2, H - 14, dx + 9, H - 8], fill=c((146, 96, 60)))
    d.point([dx + 9, H - 7], fill=c((232, 190, 60)))
    if sign:
        tw = len(sign) * 4 + 3
        sx = (W - tw) // 2
        d.rectangle([sx, roof_h - 12, sx + tw, roof_h - 2], fill=c(sign_col), outline=OUTLINE)
        draw_text(d, sx + 2, roof_h - 10, sign, c((250, 244, 230)))
    return im


HOUSES = [  # wall, roof, trim
    ((236, 226, 198), (176, 120, 80), (214, 200, 174)),
    ((226, 190, 170), (92, 110, 150), (250, 244, 230)),
    ((190, 210, 230), (150, 70, 60), (250, 244, 230)),
    ((214, 200, 174), (80, 110, 80), (236, 230, 214)),
    ((240, 220, 150), (110, 108, 120), (250, 244, 230)),
    ((200, 170, 200), (92, 58, 40), (236, 230, 214)),
]


def generated():
    """name -> 1x PIL image for everything the free packs do not ship."""
    g = {
        "sand1": gen_sand(0), "sand2": gen_sand(1),
        "water1": gen_water(0), "water2": gen_water(1),
        "tree": gen_tree(), "rock": gen_rock(),
        "mound": gen_mound(), "mound_dug": gen_mound(True),
        "marker": gen_marker(), "tape": gen_tape(), "cctv": gen_cctv(),
        "icon_prints": gen_icon("prints"), "icon_scan": gen_icon("scan"),
        "icon_shovel": gen_icon("shovel"),
        "police": gen_building(5, 5, (190, 200, 220), (60, 80, 130), (250, 244, 230),
                               "POLICE", (60, 80, 130)),
        "hotel": gen_building(6, 5, (240, 214, 190), (150, 50, 50), (250, 244, 230),
                              "HOTEL", (150, 50, 50)),
    }
    for i, (wall, roof, trim) in enumerate(HOUSES, 1):
        g["house%d" % i] = gen_building(4, 4, wall, roof, trim)
    g.update(MIA.interior_tiles())          # police station + cafe interiors
    return g


# ----------------------------------------------------------------- packs
TILE_NAMES = {  # index in town-street-lite.png -> our file name
    0: "road", 1: "road2", 4: "road_line", 5: "crosswalk", 6: "sidewalk",
    9: "grass1", 10: "grass2", 11: "grass3",
    12: "flowers1", 13: "flowers2", 14: "flowers3",
}


def save(pack, name, img):
    img.save(pack / (name + ".png"))


def build_pack(name, tile_size, mult):
    pack = OUT / name
    if pack.exists():
        shutil.rmtree(pack)
    pack.mkdir(parents=True)
    (pack / "pack.json").write_text(json.dumps(
        {"name": name, "tile_size": tile_size}, indent=1))
    folder = "%dx" % mult
    sheet = Image.open(TOWN / "tiles" / folder / "town-street-lite.png").convert("RGBA")
    for idx, fname in TILE_NAMES.items():
        x, y = (idx % 8) * tile_size, (idx // 8) * tile_size
        save(pack, fname, sheet.crop((x, y, x + tile_size, y + tile_size)))
    save(pack, "cafe", Image.open(TOWN / "buildings" / folder / "cafe.png").convert("RGBA"))
    save(pack, "player", Image.open(
        TOWN / "characters" / folder / "player-1-walk.png").convert("RGBA"))
    for s in NPC_SHEETS:
        save(pack, s, Image.open(CHARS / "characters" / folder / (s + ".png")).convert("RGBA"))
    for new_name, (base, mapping) in MIA.RECOLORS.items():      # Chief and Officer Dale
        src = Image.open(CHARS / "characters" / folder / (base + ".png"))
        save(pack, new_name, MIA.recolor(src, mapping))
    for k, im in generated().items():
        if mult != 1:
            im = im.resize((im.width * mult, im.height * mult), Image.NEAREST)
        save(pack, k, im)


def build_noir():
    src, dst = OUT / "cozy", OUT / "noir"
    if dst.exists():
        shutil.rmtree(dst)
    dst.mkdir(parents=True)
    shutil.copy(src / "pack.json", dst / "pack.json")
    (dst / "pack.json").write_text(json.dumps({"name": "noir", "tile_size": 16}, indent=1))
    for f in src.glob("*.png"):
        im = Image.open(f).convert("RGBA")
        px = im.load()
        for y in range(im.height):
            for x in range(im.width):
                r, g, b, a = px[x, y]
                if a:
                    L = 0.3 * r + 0.59 * g + 0.11 * b
                    L = max(0, min(255, (L - 110) * 1.15 + 105))
                    px[x, y] = (int(L), int(L * 0.97), int(L * 0.9), a)
        im.save(dst / f.name)


def main():
    if not TOWN.exists() or not CHARS.exists():
        sys.exit("Put the extracted cozy-town-lite and cozy-characters-lite folders in ./source")
    OUT.mkdir(parents=True, exist_ok=True)
    build_pack("cozy", 16, 1)
    build_pack("cozy-2x", 32, 2)
    build_noir()
    print("Packs built in", OUT)


if __name__ == "__main__":
    main()
