"""Builds the small Chinese font shipped in assets/fonts/ from a full font file.

Usage:   python make_font.py  path/to/NotoSansSC-Bold.otf
Needs:   pip install fonttools
The result contains: ASCII, Latin-1, common punctuation, the 3755 most common Chinese characters
(GB2312 level 1) and every character found in lang/*.json, so text you add to a language file
shows up as long as it uses common characters.
Download the full font (SIL Open Font License) from https://github.com/notofonts/noto-cjk
(Sans/SubsetOTF/SC/NotoSansSC-Bold.otf).
"""
import json
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
OUT = BASE / "assets" / "fonts" / "NotoSansSC-Bold-subset.otf"


def wanted_chars():
    chars = set(chr(c) for c in range(0x20, 0x7F)) | set(chr(c) for c in range(0xA0, 0x100))
    chars |= set(chr(c) for c in range(0x2000, 0x2070))      # general punctuation
    chars |= set(chr(c) for c in range(0x3000, 0x3040))      # CJK punctuation
    chars |= set(chr(c) for c in range(0xFF00, 0xFF60))      # full-width forms
    for row in range(0xB0, 0xD8):                            # GB2312 level 1 hanzi
        for col in range(0xA1, 0xFF):
            try:
                chars.add(bytes([row, col]).decode("gb2312"))
            except UnicodeDecodeError:
                pass
    for f in (BASE / "lang").glob("*.json"):
        data = json.loads(f.read_text(encoding="utf-8"))
        for v in data.get("strings", {}).values():
            chars |= set(v)
        chars |= set(data.get("_meta", {}).get("name", ""))
    return chars


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    from fontTools import subset
    from fontTools.ttLib import TTFont
    opts = subset.Options()
    opts.layout_features = ["kern", "locl"]
    opts.name_IDs = ["*"]
    opts.notdef_outline = True
    opts.glyph_names = False
    font = TTFont(sys.argv[1])
    sub = subset.Subsetter(opts)
    sub.populate(unicodes=[ord(c) for c in wanted_chars()])
    sub.subset(font)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    font.save(str(OUT))
    print("wrote %s (%d KB)" % (OUT, OUT.stat().st_size // 1024))


if __name__ == "__main__":
    main()
