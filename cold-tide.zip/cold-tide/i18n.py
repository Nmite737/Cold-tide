"""Languages for Cold Tide. No pygame in here, so it can be unit-tested.

How it works
* The English text in the code IS the translation key:  tr("Back")  ->  "Retour" in French.
* Every language is one file in  lang/<code>.json :
      {"_meta": {"name": "Francais", "order": 1, "lower": true, "font": null},
       "strings": {"Back": "Retour", ...}}
  Drop in a new file and the language appears in Settings > Language by itself.
* A missing string falls back to the English text, so a half-finished file never crashes.
* _meta.font:   null = the normal game font,  "cjk" = a Chinese-capable font (bundled one in
  assets/fonts first, then fonts installed on the PC),  or a file name inside assets/fonts.
* _meta.lower:  false for languages where nouns keep their capital letter (German).
"""
import json
from pathlib import Path

LANG_DIR = Path(__file__).resolve().parent / "lang"
DEFAULT = "en"

_tables = {}                      # code -> {english text: translated text}
_meta = {DEFAULT: {"name": "English", "order": 0, "lower": True, "font": None}}
_reverse = {}                     # translated text -> english text (any language)
_current = DEFAULT
_loaded = False


def _load():
    global _loaded
    if _loaded:
        return
    _loaded = True
    if not LANG_DIR.is_dir():
        return
    for f in sorted(LANG_DIR.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            strings = {str(k): str(v) for k, v in data.get("strings", {}).items()}
        except Exception as e:  # a broken file must not stop the game
            print("Could not load language file", f.name, e)
            continue
        code = f.stem
        if code == DEFAULT:
            continue
        m = {"name": code, "order": 100, "lower": True, "font": None}
        m.update(data.get("_meta", {}))
        _meta[code] = m
        _tables[code] = strings
        for en, tx in strings.items():
            _reverse.setdefault(tx, en)


def codes():
    """Language codes in menu order, English first."""
    _load()
    return sorted(_meta, key=lambda c: (_meta[c].get("order", 100), c))


def name(code):
    """Name of a language written in that language (shown in the menu)."""
    _load()
    return _meta.get(code, {}).get("name", code)


def meta(key, code=None):
    _load()
    return _meta.get(code or _current, {}).get(key)


def set_language(code):
    global _current
    _load()
    _current = code if code in _meta else DEFAULT
    return _current


def current():
    return _current


def tr(text):
    """Translate an English text into the current language."""
    if _current == DEFAULT:
        return text
    _load()
    return _tables.get(_current, {}).get(text, text)


def N_(text):
    """Marks a text for translation without translating it yet (module-level constants)."""
    return text


def lower(text):
    """Lower-case a translated word (job titles in a sentence) unless the language keeps capitals."""
    return text.lower() if meta("lower") is not False else text


def canonical(text):
    """English source of a translated text ('Commissaire' -> 'Chief'); used to find voices."""
    _load()
    return _reverse.get(text, text)


class L:
    """A text translated when it is read, not when it is made. Clues are stored this way so the
    notebook switches language at once when the player changes it in the Settings menu."""
    __slots__ = ("fmt", "args")

    def __init__(self, fmt, *args):
        self.fmt, self.args = fmt, args

    def __str__(self):
        t = tr(self.fmt)
        return t % self.args if self.args else t

    __repr__ = __str__
