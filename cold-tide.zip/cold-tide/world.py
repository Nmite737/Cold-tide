"""Map layout for Cold Tide. Pure Python so it can be tested without pygame.
All coordinates are in tiles (floats for positions, ints for tile cells)."""
import math
import random
from collections import deque

MAP_W, MAP_H = 64, 48
ROAD_ROWS = (20, 21, 22)
SIDEWALK_ROWS = (19, 23)


def shore_y(x):
    return 38 + int(round(2 * math.sin(x / 5.0)))


# id, x, y, w, h, owner  (bottom row of every front-row building is y=18)
BUILDINGS = [
    ("house1", 3, 15, 4, 4, "grandma"),
    ("cafe", 9, 14, 5, 5, "cafe"),
    ("police", 16, 14, 5, 5, "police"),
    ("hotel", 24, 14, 6, 5, "hotel"),
    ("house2", 34, 15, 4, 4, "dogwalker"),
    ("house3", 41, 15, 4, 4, "chef"),
    ("house4", 48, 15, 4, 4, "teacher"),
    ("house5", 55, 15, 4, 4, "barista"),
    ("house6", 40, 6, 4, 4, "pumpkin"),
]

MOUND_SITES = [(5, 6), (11, 10), (18, 4), (23, 9), (28, 5), (8, 3)]
CRIME_SCENE = (30, 34)
CCTV_POS = (22, 32)
HOTEL_SPAWN = (27, 19)


class World:
    def __init__(self):
        self.w, self.h = MAP_W, MAP_H
        self.ground = [["G"] * MAP_W for _ in range(MAP_H)]
        self.solid = set()
        self.buildings = []
        self.trees = []
        self.rocks = []
        self._ground()
        self._buildings()
        self._water_border()
        self.places = self._places()
        self._trees_and_rocks()
        self.props = []                # cosmetic solid props that were accepted (see decor.py)
        self._dress()

    # ---- terrain
    def _ground(self):
        g = self.ground
        for x in range(MAP_W):
            for y in ROAD_ROWS:
                g[y][x] = "L" if y == 21 else "R"
            for y in SIDEWALK_ROWS:
                g[y][x] = "K"
            for y in range(31, MAP_H):
                g[y][x] = "S" if y <= shore_y(x) else "W"
        for x in (33, 34):
            for y in ROAD_ROWS:
                g[y][x] = "X"
        for x in range(38, 47):
            g[10][x] = "K"

    def _buildings(self):
        for bid, x, y, w, h, owner in BUILDINGS:
            door = (x + w // 2, y + h - 1)
            self.buildings.append({
                "id": bid, "x": x, "y": y, "w": w, "h": h, "owner": owner,
                "door": door, "approach": (door[0], y + h),
            })
            for tx in range(x, x + w):
                for ty in range(y, y + h):
                    self.solid.add((tx, ty))

    def _water_border(self):
        for x in range(MAP_W):
            for y in range(MAP_H):
                if self.ground[y][x] == "W" or x in (0, MAP_W - 1) or y in (0, MAP_H - 1):
                    self.solid.add((x, y))

    def _places(self):
        p = {"cafe": (11, 19), "square": (33, 25), "beach": (30, 35), "orchard": (14, 9)}
        for b in self.buildings:
            p["home_" + b["owner"]] = b["approach"]
        return p

    def _trees_and_rocks(self):
        keep = list(MOUND_SITES) + [self.places["orchard"], CRIME_SCENE, CCTV_POS]
        for attempt in range(60):
            rng = random.Random(1000 + attempt)
            trees = []
            for x in range(1, 36):
                for y in range(1, 13):
                    if (x, y) in self.solid or self.ground[y][x] != "G":
                        continue
                    if any(abs(x - kx) <= 1 and abs(y - ky) <= 1 for kx, ky in keep):
                        continue
                    if rng.random() < 0.21 or y <= 1:
                        trees.append((x, y))
            for x in range(44, 63):
                for y in range(1, 5):
                    if (x, y) not in self.solid and rng.random() < 0.3:
                        trees.append((x, y))
            rocks = []
            for _ in range(10):
                x, y = rng.randrange(2, 62), rng.randrange(33, 36)
                if (x, y) not in self.solid and not any(
                        abs(x - kx) <= 1 and abs(y - ky) <= 1 for kx, ky in keep):
                    rocks.append((x, y))
            test = set(self.solid) | set(trees) | set(rocks)
            if self._all_reachable(test):
                self.trees, self.rocks = trees, rocks
                self.solid = test
                return
        raise RuntimeError("could not generate a connected map")

    def _dress(self):
        import decor
        """Add the cosmetic solid props one by one; drop any that would cut a route.
        Done after the trees so the tree layout of older versions stays exactly the same."""
        for item in decor.solid_candidates(self):
            tiles = decor.footprint(item)
            test = set(self.solid) | set(tiles)
            if self._all_reachable(test):
                self.solid = test
                self.props.append(item)

    def _all_reachable(self, solid):
        goals = list(MOUND_SITES) + list(self.places.values()) + [CRIME_SCENE, CCTV_POS]
        seen = self._flood(HOTEL_SPAWN, solid)
        return all(g in seen for g in goals)

    def _flood(self, start, solid):
        seen, q = {start}, deque([start])
        while q:
            x, y = q.popleft()
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                n = (x + dx, y + dy)
                if n not in seen and n not in solid and 0 <= n[0] < MAP_W and 0 <= n[1] < MAP_H:
                    seen.add(n)
                    q.append(n)
        return seen

    # ---- helpers used by the game
    def is_solid(self, tx, ty):
        return (tx, ty) in self.solid

    def building(self, bid):
        return next(b for b in self.buildings if b["id"] == bid)

    def nearest_walkable(self, tile):
        if tile not in self.solid:
            return tile
        for r in range(1, 6):
            for dx in range(-r, r + 1):
                for dy in range(-r, r + 1):
                    t = (tile[0] + dx, tile[1] + dy)
                    if 0 <= t[0] < MAP_W and 0 <= t[1] < MAP_H and t not in self.solid:
                        return t
        return tile

    def path(self, start, goal):
        """Breadth-first path of tiles from start to goal (excludes start)."""
        goal = self.nearest_walkable(goal)
        if start == goal:
            return []
        prev, q = {start: None}, deque([start])
        while q:
            cur = q.popleft()
            if cur == goal:
                break
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                n = (cur[0] + dx, cur[1] + dy)
                if n in prev or n in self.solid or not (0 <= n[0] < MAP_W and 0 <= n[1] < MAP_H):
                    continue
                prev[n] = cur
                q.append(n)
        if goal not in prev:
            return []
        out, cur = [], goal
        while cur != start:
            out.append(cur)
            cur = prev[cur]
        return out[::-1]
