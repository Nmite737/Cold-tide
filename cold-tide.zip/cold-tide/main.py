"""COLD TIDE - a 2D detective game.  Run:  python main.py
Needs Python 3.9 or newer and pygame-ce (see requirements.txt).
Windows 10 / 11, Linux (Ubuntu, Linux Mint, ...) and macOS."""
import sys

if sys.version_info < (3, 9):
    sys.exit("Cold Tide needs Python 3.9 or newer, but this is Python %d.%d.%d.\n"
             "Install a newer Python from https://www.python.org/downloads/ and start the game again."
             % sys.version_info[:3])

import json
import math
import os
import random
import re
from pathlib import Path

try:
    import pygame
except ImportError:
    sys.exit("pygame-ce is not installed.  Run:  python -m pip install -r requirements.txt\n"
             "(or use run_windows.bat / run_linux.sh / run_mac.command, which do it for you)")

import audio
import case2
import i18n
import interiors
import logic
import paths
import world as W
from i18n import tr, N_

BASE = Path(__file__).resolve().parent
PACKS = BASE / "assets" / "packs"
FONT_DIR = BASE / "assets" / "fonts"
PORTRAIT_DIR = BASE / "assets" / "portraits"
CONFIG, DATA = paths.data_dirs()          # see paths.py: legacy ~/.cold_tide, else XDG on Linux
SETTINGS_FILE = CONFIG / "settings.json"
SAVE_FILE = DATA / "save.json"
ART_REVISION = 2                           # bumped when the default art changes (see load_settings)

VIEW_W, VIEW_H = 30, 17          # visible tiles
DIRS = ["down", "left", "right", "up"]
WINDOW_SIZES = [(N_("Small 960x540"), 960, 540), (N_("Medium 1280x720"), 1280, 720),
                (N_("Large 1600x900"), 1600, 900), (N_("Auto (fit screen)"), 0, 0)]
DAY_SPEEDS = [(N_("Short"), 0.30), (N_("Normal"), 0.45), (N_("Long"), 0.70)]
DEFAULTS = {"pack": "hd", "window": 1, "fullscreen": False, "integer": False,
            "lighting": True, "fps": False, "speed": 1,
            "sound": True, "volume": 7, "hints": True, "lang": "en"}
TOOLS = [(N_("Fingerprint kit"), "icon_prints"), (N_("Face scanner"), "icon_scan"), (N_("Shovel"), "icon_shovel")]
OFFSETS = [(-1, 0), (1, 0), (0, 1), (0, -1), (-1, 1), (1, 1)]
PLAYER_SPEED = 3.4
INK = (62, 42, 40)
CREAM = (238, 228, 206)
GOLD = (232, 190, 60)


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def lerp3(a, b, k):
    return tuple(int(a[i] + (b[i] - a[i]) * k) for i in range(3))


WORRIED_LINES = set(logic.NERVOUS) | {case2.WORRIED}      # lines said with the sweat-drop face


def hhmm(m):
    return "%02d:%02d" % (m // 60, m % 60)


# ------------------------------------------------------------ fonts for other languages
# The built-in pygame font only has Latin letters (enough for English, French, German).
# Chinese needs a real font: first the one shipped in assets/fonts, then one installed on the PC.
CJK_SYSTEM_NAMES = ["microsoftyahei", "msyh", "simhei", "simsun", "dengxian",            # Windows
                    "pingfangsc", "pingfang", "hiraginosansgb", "stheiti", "heitisc",    # macOS
                    "notosanscjksc", "notosanssc", "notosanscjk", "sourcehansanssc",     # Linux
                    "wenquanyimicrohei", "wenquanyizenhei", "droidsansfallback"]
CJK_SYSTEM_FILES = ["C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/msyh.ttf", "C:/Windows/Fonts/simhei.ttf",
                    "/System/Library/Fonts/PingFang.ttc", "/System/Library/Fonts/STHeiti Medium.ttc",
                    "/Library/Fonts/Arial Unicode.ttf",
                    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
                    "/usr/share/fonts/opentype/noto/NotoSansCJKsc-Regular.otf",
                    "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
                    "/usr/share/fonts/noto-cjk/NotoSansCJK-Regular.ttc",
                    "/usr/share/fonts/google-noto-cjk/NotoSansCJK-Regular.ttc",
                    "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
                    "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
                    "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf"]
FONT_SCALE = 0.74        # pygame draws its default font at 0.69 x size; other fonts need a similar shrink
CJK = re.compile("[\u2e80-\u9fff\uf900-\ufaff\uff00-\uffef\u3000-\u303f]")
NO_LINE_START = set("，。！？、；：）》」』”’…·,.!?;:)")


def find_font(spec):
    """File path of the font a language asks for (_meta.font in its lang file), or None."""
    if not spec:
        return None
    if spec != "cjk":                                   # a file name inside assets/fonts
        p = FONT_DIR / spec
        return str(p) if p.exists() else None
    if FONT_DIR.is_dir():
        for p in sorted(FONT_DIR.iterdir()):
            if p.suffix.lower() in (".ttf", ".otf", ".ttc"):
                return str(p)
    try:
        for n in CJK_SYSTEM_NAMES:
            p = pygame.font.match_font(n)
            if p:
                return p
    except Exception:
        pass
    for f in CJK_SYSTEM_FILES:
        if Path(f).exists():
            return f
    return None


# ------------------------------------------------------------ texture pack
class Pack:
    def __init__(self, name):
        meta = json.loads((PACKS / name / "pack.json").read_text(encoding="utf-8"))
        base = json.loads((PACKS / "cozy" / "pack.json").read_text(encoding="utf-8"))
        self.name = name
        self.T = int(meta["tile_size"])
        self.Th = self.T * 3 // 2
        self.fT = int(base["tile_size"])
        self.hd = bool(meta.get("hd"))               # packs with the detailed art + lighting data
        self.buildings = meta.get("buildings", {})   # window / chimney / lamp positions (pixels)
        self.cache, self.frames, self.sils, self._has = {}, {}, {}, {}

    def has(self, key):
        """True if THIS pack ships the picture (no fallback to the cozy pack)."""
        if key not in self._has:
            self._has[key] = (PACKS / self.name / (key + ".png")).exists()
        return self._has[key]

    def img(self, key):
        if key not in self.cache:
            p = PACKS / self.name / (key + ".png")
            fallback = not p.exists()
            if fallback:
                p = PACKS / "cozy" / (key + ".png")
            s = pygame.image.load(str(p)).convert_alpha()
            if fallback and self.T != self.fT:
                k = self.T / float(self.fT)
                s = pygame.transform.scale(s, (int(s.get_width() * k), int(s.get_height() * k)))
            self.cache[key] = s
        return self.cache[key]

    def frame(self, sheet, row, col):
        k = (sheet, row, col)
        if k not in self.frames:
            self.frames[k] = self.img(sheet).subsurface(
                pygame.Rect(col * self.T, row * self.Th, self.T, self.Th))
        return self.frames[k]

    def sil(self, sheet, row, col):
        k = (sheet, row, col)
        if k not in self.sils:
            f = self.frame(sheet, row, col).copy()
            f.fill((18, 14, 26, 255), special_flags=pygame.BLEND_RGBA_MIN)
            self.sils[k] = f
        return self.sils[k]


def list_packs():
    return sorted(d.name for d in PACKS.iterdir() if (d / "pack.json").exists())


class Portraits:
    """Dialogue faces: assets/portraits/<key>.png and <key>_worried.png (see make_portraits.py)."""

    def __init__(self):
        self.raw, self.scaled = {}, {}

    def get(self, key, worried=False, size=0):
        k = (key, worried)
        if k not in self.raw:
            surf = None
            for name in ((key + "_worried", key) if worried else (key,)):
                p = PORTRAIT_DIR / (name + ".png")
                if p.exists():
                    try:
                        surf = pygame.image.load(str(p)).convert_alpha()
                        break
                    except Exception:
                        surf = None
            self.raw[k] = surf
        surf = self.raw[k]
        if surf is None or not size:
            return surf
        if (k, size) not in self.scaled:
            raw = surf.get_width()
            fn = pygame.transform.scale if (size % raw == 0 or raw % size == 0 or raw < 100) \
                else pygame.transform.smoothscale
            self.scaled[(k, size)] = fn(surf, (size, size))
        return self.scaled[(k, size)]

    def has(self, key):
        return self.get(key) is not None


def char_sprite(pack, sheet, x, y, d, moving, t, sil=False):
    row = (4 if moving else 0) + DIRS.index(d)
    n, fps = (6, 10) if moving else (4, 4)
    col = int(t * fps) % n
    f = pack.sil(sheet, row, col) if sil else pack.frame(sheet, row, col)
    T = pack.T
    return (y, f, (x * T - T / 2.0, y * T - 21 * T / 16.0))


def follow(ent, dt, speed):
    ent["moving"] = False
    if not ent["path"]:
        return
    gx, gy = ent["path"][0][0] + 0.5, ent["path"][0][1] + 0.5
    dx, dy = gx - ent["x"], gy - ent["y"]
    d = math.hypot(dx, dy)
    step = speed * dt
    if d <= step:
        ent["x"], ent["y"] = gx, gy
        ent["path"].pop(0)
    else:
        ent["x"] += dx / d * step
        ent["y"] += dy / d * step
    if abs(dx) > abs(dy):
        ent["dir"] = "right" if dx > 0 else "left"
    else:
        ent["dir"] = "down" if dy > 0 else "up"
    ent["moving"] = True


class Menu:
    def __init__(self, title, items, back=None):
        self.title, self.items, self.back, self.sel = title, items, back, 0

    def label(self, i):
        l = self.items[i]["label"]
        return l() if callable(l) else tr(l)


# ----------------------------------------------------------------- game
class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Cold Tide")
        self.set_icon()
        self.desktop = self.desktop_size()
        self.settings = self.load_settings()
        i18n.set_language(self.settings["lang"])
        self.screen = None
        self.apply_display()
        self.audio = audio.Audio(self.settings, pygame)
        self.step_t = 0.0
        self.world = W.World()
        import decor
        self.free_props = decor.free_props(self.world)
        self.pack = None
        self.canvas = None
        self.ground = None
        self.load_pack(self.settings["pack"])
        self.clock = pygame.time.Clock()
        self.fonts, self.font_file = {}, None
        self.apply_language()
        self.dim_cache, self.tcache, self.pcache = {}, {}, {}
        self.scale_buf, self.vig_light, self.mouse_rects = {}, {}, []
        self.vig = None
        self.t = 0.0
        self.U = 1.0
        self.toasts = []
        self.running = True
        self.mode = "title"
        self.menu = None
        self.dialog = None
        self.card = None
        self.action = None
        self.page = 0
        self.stalker = None
        self.stalk_cd = 0.0
        self.case = logic.Case(1)
        self.npcs = {}
        self.portraits = Portraits()
        self.ints = interiors.build_all()
        self.int_surf = {}
        self.scene = "town"
        self.reset_state(1)
        self.title_menu()

    # ---- settings / display
    def load_settings(self):
        s = dict(DEFAULTS)
        loaded = paths.read_json(SETTINGS_FILE, {})
        if isinstance(loaded, dict):
            s.update(loaded)
        if loaded and int(s.get("art_rev", 1)) < ART_REVISION and s.get("pack") in ("cozy", "cozy-2x"):
            s["pack"] = DEFAULTS["pack"]            # once: move older settings to the new HD art
        s["art_rev"] = ART_REVISION
        if s["pack"] not in list_packs():
            s["pack"] = DEFAULTS["pack"] if DEFAULTS["pack"] in list_packs() else "cozy"
        try:
            s["window"] = clamp(int(s["window"]), 0, len(WINDOW_SIZES) - 1)
            s["speed"] = clamp(int(s["speed"]), 0, len(DAY_SPEEDS) - 1)
            s["volume"] = clamp(int(s["volume"]), 0, 10)
        except (TypeError, ValueError):
            for k in ("window", "speed", "volume"):
                s[k] = DEFAULTS[k]
        if s["lang"] not in i18n.codes():
            s["lang"] = "en"
        return s

    def apply_language(self):
        """Switch every text in the game to settings['lang'] (also picks the font for it)."""
        i18n.set_language(self.settings["lang"])
        self.font_file = find_font(i18n.meta("font"))
        if i18n.meta("font") and not self.font_file:
            print("No font with %s letters found: add a .ttf/.otf file to assets/fonts" % i18n.name(i18n.current()))
        self.fonts = {}
        self.tcache = {}

    def save_settings(self):
        try:
            paths.write_text_atomic(SETTINGS_FILE, json.dumps(self.settings, indent=1))
        except Exception:
            pass

    def desktop_size(self):
        """Size of the primary monitor (falls back to 1280x720 if the system does not say)."""
        try:
            sizes = pygame.display.get_desktop_sizes()
            if sizes and sizes[0][0] > 0:
                return tuple(sizes[0])
        except Exception:
            pass
        try:
            info = pygame.display.Info()
            if info.current_w > 0 and info.current_h > 0:
                return (info.current_w, info.current_h)
        except Exception:
            pass
        return (1280, 720)

    def set_icon(self):
        try:
            p = PORTRAIT_DIR / "player.png"
            if p.exists():
                pygame.display.set_icon(pygame.image.load(str(p)))
        except Exception:
            pass

    def apply_display(self):
        """Window or fullscreen.  Any failure (odd drivers, remote desktops) falls back to a plain window."""
        s = self.settings
        self.desktop = self.desktop_size()
        self.vig = None
        try:
            if s["fullscreen"]:
                self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
                return
        except pygame.error as e:
            print("Fullscreen failed (%s); using a window." % e)
            s["fullscreen"] = False
        _, w, h = WINDOW_SIZES[s["window"]]
        if w == 0:
            w = int(self.desktop[0] * 0.9)
            h = int(w * 9 / 16)
            if h > self.desktop[1] * 0.85:
                h = int(self.desktop[1] * 0.85)
                w = int(h * 16 / 9)
        w, h = max(640, min(w, max(640, self.desktop[0]))), max(360, min(h, max(360, self.desktop[1])))
        try:
            self.screen = pygame.display.set_mode((w, h), pygame.RESIZABLE)
        except pygame.error:
            self.screen = pygame.display.set_mode((w, h))

    def toggle_fullscreen(self):
        self.settings["fullscreen"] = not self.settings["fullscreen"]
        self.apply_display()
        self.save_settings()

    def load_pack(self, name):
        try:
            self.pack = Pack(name)
            self.pack.img("grass1")
        except Exception as e:
            print("Could not load pack", name, e)
            self.pack = Pack("cozy")
            name = "cozy"
        self.settings["pack"] = name
        T = self.pack.T
        self.canvas = pygame.Surface((VIEW_W * T, VIEW_H * T))
        self.int_surf, self.glows, self.vig_light, self.scale_buf = {}, {}, {}, {}
        self.puffs = None
        self.build_ground()

    def flipped(self, key):
        k = "flip:" + key
        if k not in self.pack.cache:
            self.pack.cache[k] = pygame.transform.flip(self.pack.img(key), True, False)
        return self.pack.cache[k]

    def build_ground(self):
        T, p, wd = self.pack.T, self.pack, self.world
        hd = p.hd
        surf = pygame.Surface((W.MAP_W * T, W.MAP_H * T))
        self.water_cells = []                      # (tx, ty, depth, foam) animated every frame
        for y in range(W.MAP_H):
            for x in range(W.MAP_W):
                code = wd.ground[y][x]
                over = None
                flip = (x * 5 + y * 3) % 2 == 1
                if code == "G":
                    h = (x * 7 + y * 13 + x * y) % 17
                    wood = hd and ((x < 36 and y < 13) or (x >= 44 and y < 5))
                    if wood:
                        key = "grass_dark" if h < 7 else "grass_dark2" if h < 12 else "grass2" if h < 15 \
                            else "flowers%d" % (1 + h % 3)
                    else:
                        key = "grass1" if h < 9 else "grass2" if h < 12 else "grass3" if h < 14 \
                            else "flowers%d" % (1 + h % 3)
                elif code == "S":
                    key = "sand1" if (x + y) % 3 else "sand2"
                    if hd and wd.ground[y - 1][x] == "G":
                        over = "grass_fringe"
                    elif hd and y + 1 < W.MAP_H and wd.ground[y + 1][x] == "W":
                        over = "wet_sand"
                elif code == "W":
                    d = y - W.shore_y(x)
                    depth = "shallow" if d <= 1 else "mid" if d <= 4 else "deep"
                    self.water_cells.append((x, y, depth, wd.ground[y - 1][x] == "S"))
                    key = ("water_%s0" % depth) if hd else "water1"
                    flip = False
                elif code == "R":
                    key = ("road_n" if y == W.ROAD_ROWS[0] else "road_s") if hd and p.has("road_n") \
                        else ("road" if (x + y) % 2 else "road2")
                elif code == "L":
                    key, flip = "road_line", False
                elif code == "X":
                    key, flip = "crosswalk", False
                else:
                    key = ("sidewalk_n" if y == W.SIDEWALK_ROWS[0] else "sidewalk_s") if hd and p.has("sidewalk_n") \
                        and y in W.SIDEWALK_ROWS else "sidewalk"
                    flip = flip and key == "sidewalk"
                surf.blit(self.flipped(key) if flip else p.img(key), (x * T, y * T))
                if over:
                    surf.blit(p.img(over), (x * T, y * T))
        if hd:
            import decor
            for key, tx, ty in decor.decals(wd):
                if p.has(key):
                    surf.blit(p.img(key), (tx * T, ty * T))
            self.bake_shadows(surf)
        self.ground = surf

    def bake_shadows(self, surf):
        """Soft shadows of the buildings on the ground (light comes from the top left)."""
        T = self.pack.T
        for b in self.world.buildings:
            wpx, hpx = int(T * 0.9), b["h"] * T - int(T * 0.5)
            s1 = pygame.Surface((wpx, hpx), pygame.SRCALPHA)
            for i in range(wpx):
                pygame.draw.line(s1, (20, 24, 60, int(72 * (1 - i / float(wpx)) ** 1.3)), (i, 0), (i, hpx))
            surf.blit(s1, ((b["x"] + b["w"]) * T, b["y"] * T + int(T * 0.5)))
            bw, bh = b["w"] * T + wpx, int(T * 0.4)
            s2 = pygame.Surface((bw, bh), pygame.SRCALPHA)
            for j in range(bh):
                pygame.draw.line(s2, (20, 24, 60, int(86 * (1 - j / float(bh)) ** 1.5)), (0, j), (bw, j))
            surf.blit(s2, (b["x"] * T, (b["y"] + b["h"]) * T))

    # ---- game state
    def reset_state(self, seed):
        self.case = logic.Case(seed)
        self.case2 = case2.Case2(seed, exclude=self.case.killer)       # the cafe murder (starts on day 5)
        self.c2_on, self.c2_done = False, False
        self.scene = "town"
        self.apply_flags()
        self.day, self.minute, self.acc = 1, logic.DAY_START, 0.0
        self.collected, self.talk_count, self.coffee = set(), {}, 0
        self.px, self.py = W.HOTEL_SPAWN[0] + 0.5, W.HOTEL_SPAWN[1] + 0.5
        self.facing, self.moving, self.panim = "down", False, 0.0
        self.tool = 0
        self.action = None
        self.stalker, self.stalk_cd, self.stalk_warned = None, 8.0, False
        self.npcs = {}
        self.banner, self.hint_cd, self.idle = None, 4.0, 0.0
        self.near_key, self.near_t, self.hint_seen = None, 0.0, {}
        self.spots = self.make_spots()
        self.make_staff()
        self.refresh_npcs(True)

    def make_spots(self):
        sp = [{"id": "beach_print", "kind": "print", "pos": (W.CRIME_SCENE[0] + .5, W.CRIME_SCENE[1] + .5)},
              {"id": "cctv", "kind": "pickup", "pos": (W.CCTV_POS[0] + .5, W.CCTV_POS[1] + 1.0)}]
        for b in self.world.buildings:
            if b["owner"] in logic.BY_ID:
                sp.append({"id": "door_" + b["owner"], "kind": "print",
                           "pos": (b["door"][0] + .5, b["approach"][1] + .1)})
        return sp

    def place_tile(self, place, sid, i):
        if place == "home":
            base = self.world.places["home_" + sid]
        else:
            base = self.world.places[place]
        ox, oy = OFFSETS[i % len(OFFSETS)]
        return self.world.nearest_walkable((base[0] + ox, base[1] + oy))

    # ---- scenes: the town, the police station and the cafe
    @property
    def interior(self):
        return self.ints.get(self.scene)

    def grid(self):
        return self.interior or self.world

    def flags(self):
        return {"c2" if self.c2_on else "no_c2", "c2_solved" if self.c2_done else "no_c2_solved"}

    def apply_flags(self):
        for it in self.ints.values():
            it.set_flags(self.flags())

    def jailed(self):
        return {self.case2.culprit} if self.c2_done else set()

    def here(self):
        """People standing in the scene the player is in."""
        return [n for n in self.npcs.values() if n["scene"] == self.scene]

    def npc_name(self, n):
        return logic.STAFF[n["id"]]["name"] if n.get("staff") else logic.BY_ID[n["id"]]["name"]

    def make_staff(self):
        for sid, st in logic.STAFF.items():
            x, y = self.ints["police"].seat(sid)
            self.npcs[sid] = {"id": sid, "sheet": st["sheet"], "x": x + .5, "y": y + .5, "dir": "down",
                              "moving": False, "path": [], "place": "police", "scene": "police",
                              "enter": None, "staff": True}

    def enter(self, iid):
        self.audio.play("door_open")
        if iid == "cafe":
            self.audio.play("bell")
        self.scene = iid
        it = self.interior
        it.set_flags(self.flags())
        self.px, self.py = it.spawn
        self.facing, self.moving = "up", False
        self.stalker, self.stalk_cd = None, max(self.stalk_cd, 6.0)      # he loses you while you are inside
        self.banner = None

    def leave(self):
        b = self.world.building(interiors.BUILDING_OF[self.scene])
        self.audio.play("door_close")
        self.scene = "town"
        self.px, self.py = b["door"][0] + .5, b["approach"][1] + .5
        self.facing, self.moving = "down", False

    def place_target(self, place, sid, i):
        """(scene, tile) where somebody with this schedule place stands."""
        if place == "cafe":
            return "cafe", self.ints["cafe"].seat(sid, i)
        if place == "jail":
            return "police", self.ints["police"].seat("prisoner")
        return "town", self.place_tile(place, sid, i)

    def refresh_npcs(self, teleport):
        jailed = self.jailed()
        for i, s in enumerate(logic.SUSPECTS):
            sid = s["id"]
            place = logic.place_for(sid, self.minute, self.case.killer, jailed)
            n = self.npcs.get(sid)
            if n is None:
                n = {"id": sid, "sheet": s["sheet"], "x": 0, "y": 0, "dir": "down", "moving": False,
                     "path": [], "place": None, "scene": "town", "enter": None}
                self.npcs[sid] = n
                teleport_this = True
            else:
                teleport_this = teleport
            if n["place"] != place or teleport_this:
                n["place"] = place
                scene, tile = self.place_target(place, sid, i)
                if teleport_this:
                    n["scene"], n["x"], n["y"] = scene, tile[0] + .5, tile[1] + .5
                    n["path"], n["enter"] = [], None
                else:
                    self.send_npc(n, scene, tile)

    def send_npc(self, n, scene, tile):
        """Walk somebody to a tile in some scene: out of the building they are in and/or in through
        the door of the one they are going to."""
        if n["scene"] != "town" and n["scene"] != scene:
            b = self.world.building(interiors.BUILDING_OF[n["scene"]])
            n["scene"], n["x"], n["y"] = "town", b["approach"][0] + .5, b["approach"][1] + .5
            n["path"], n["enter"] = [], None
        if n["scene"] == scene:
            grid = self.world if scene == "town" else self.ints[scene]
            n["enter"] = None
            n["path"] = grid.path((int(n["x"]), int(n["y"])), tile)
        else:
            b = self.world.building(interiors.BUILDING_OF[scene])
            n["path"] = self.world.path((int(n["x"]), int(n["y"])), b["approach"])
            n["enter"] = (scene, tile)

    def step_into_building(self, n):
        scene, tile = n["enter"]
        it = self.ints[scene]
        n["enter"], n["scene"] = None, scene
        n["x"], n["y"] = it.spawn
        n["path"] = it.path((int(it.spawn[0]), int(it.spawn[1])), tile)

    def scores(self):
        return self.case.scores(self.collected)

    def save_game(self):
        try:
            paths.write_text_atomic(SAVE_FILE, json.dumps({
                "seed": self.case.seed, "day": self.day, "minute": self.minute,
                "collected": sorted(self.collected), "talk": self.talk_count,
                "coffee": self.coffee, "c2": [self.c2_on, self.c2_done]}))
        except Exception:
            pass

    # ---- menus
    def title_menu(self):
        items = [{"label": N_("New Game"), "enter": self.new_game}]
        if SAVE_FILE.exists():
            items.append({"label": N_("Continue"), "enter": self.continue_game})
        items += [{"label": N_("Settings"), "enter": lambda: self.open_settings(self.title_menu)},
                  {"label": N_("Quit"), "enter": self.quit}]
        self.menu, self.mode = Menu("", items), "title"

    def pause_menu(self):
        items = [{"label": N_("Resume"), "enter": self.to_play},
                 {"label": N_("Notebook"), "enter": self.open_notebook},
                 {"label": N_("Settings"), "enter": lambda: self.open_settings(self.pause_menu)},
                 {"label": N_("Save and quit to title"), "enter": self.quit_to_title}]
        self.menu, self.mode = Menu(N_("Paused"), items, self.to_play), "menu"

    def open_settings(self, ret):
        s = self.settings

        def onoff(k):
            return tr("On") if s[k] else tr("Off")

        def toggle(k):
            s[k] = not s[k]
            if k == "fullscreen":
                self.apply_display()
            self.save_settings()

        def cycle(k, n, d):
            s[k] = (s[k] + d) % n
            if k == "window" and not s["fullscreen"]:
                self.apply_display()
            self.save_settings()

        def lang(d):
            codes = i18n.codes()
            i = codes.index(s["lang"]) if s["lang"] in codes else 0
            s["lang"] = codes[(i + d) % len(codes)]
            self.apply_language()
            self.save_settings()
            self.audio.play("ui_select")

        def pack(d):
            names = list_packs()
            i = names.index(s["pack"]) if s["pack"] in names else 0
            self.load_pack(names[(i + d) % len(names)])
            self.save_settings()

        def vol(d):
            s["volume"] = clamp(s["volume"] + d, 0, 10)
            self.save_settings()
            self.audio.refresh_volume()
            self.audio.play("ui_select")

        items = [
            {"label": lambda: tr("Language:  < %s >") % i18n.name(s["lang"]),
             "left": lambda: lang(-1), "right": lambda: lang(1), "enter": lambda: lang(1)},
            {"label": lambda: tr("Texture pack:  < %s >") % s["pack"],
             "left": lambda: pack(-1), "right": lambda: pack(1), "enter": lambda: pack(1)},
            {"label": lambda: tr("Window size:  < %s >") % tr(WINDOW_SIZES[s["window"]][0]),
             "left": lambda: cycle("window", len(WINDOW_SIZES), -1),
             "right": lambda: cycle("window", len(WINDOW_SIZES), 1),
             "enter": lambda: cycle("window", len(WINDOW_SIZES), 1)},
            {"label": lambda: tr("Fullscreen (F11):  %s") % onoff("fullscreen"),
             "enter": lambda: toggle("fullscreen")},
            {"label": lambda: tr("Pixel-perfect scaling:  %s") % onoff("integer"),
             "enter": lambda: toggle("integer")},
            {"label": lambda: tr("Day / night lighting:  %s") % onoff("lighting"),
             "enter": lambda: toggle("lighting")},
            {"label": lambda: tr("Show FPS:  %s") % onoff("fps"), "enter": lambda: toggle("fps")},
            {"label": lambda: tr("Day length:  < %s >") % tr(DAY_SPEEDS[s["speed"]][0]),
             "left": lambda: cycle("speed", len(DAY_SPEEDS), -1),
             "right": lambda: cycle("speed", len(DAY_SPEEDS), 1),
             "enter": lambda: cycle("speed", len(DAY_SPEEDS), 1)},
            {"label": lambda: tr("Hints (auto):  %s") % onoff("hints"), "enter": lambda: toggle("hints")},
            {"label": lambda: tr("Sound:  %s") % onoff("sound"),
             "enter": lambda: (toggle("sound"), self.audio.refresh_volume(), self.audio.play("ui_select"))},
            {"label": lambda: tr("Volume:  < %d / 10 >") % s["volume"],
             "left": lambda: vol(-1), "right": lambda: vol(1), "enter": lambda: vol(1)},
            {"label": N_("Back"), "enter": ret},
        ]
        self.menu = Menu(N_("Settings"), items, ret)

    def leave_building(self):
        self.audio.play("door_close")
        self.to_play()

    def to_play(self):
        self.menu, self.mode = None, "play"

    def quit_to_title(self):
        self.save_game()
        self.title_menu()

    def quit(self):
        self.running = False

    # ---- scenes
    def new_game(self):
        self.reset_state(random.randrange(10 ** 9))
        self.show_card("COLD TIDE", [
            tr("You have been transferred to the Cold Tide police department."),
            tr("%s was found murdered on the beach. Six locals had reason to be there.") % logic.VICTIM,
            tr("You have %d days to find the killer.") % logic.DAYS,
            tr("WASD / arrows: move    E: interact    SPACE: use tool"),
            tr("1 / 2 / 3 or TAB: choose tool    N: notebook    ESC: menu")])

    def continue_game(self):
        try:
            d = json.loads(SAVE_FILE.read_text(encoding="utf-8"))
            self.reset_state(d["seed"])
            self.day, self.minute = d["day"], d["minute"]
            self.collected = set(d["collected"])
            self.talk_count, self.coffee = d.get("talk", {}), d.get("coffee", 0)
            on, done = d.get("c2", [self.day >= case2.CASE2_DAY, False])     # old saves: derive it from the day
            self.c2_on, self.c2_done = bool(on), bool(done)
            self.apply_flags()
            self.refresh_npcs(True)
            self.to_play()
            self.toast(tr("Game loaded. Day %d.") % self.day)
        except Exception:
            self.new_game()

    def show_card(self, title, lines, after=None):
        self.card = {"title": title, "lines": lines, "after": after}
        self.menu, self.mode = None, "card"

    def open_dialog(self, lines, after=None):
        self.dialog = {"lines": lines, "i": 0, "after": after, "shown": 0.0}
        self.mode = "dialog"
        self.audio.say(lines[0])

    def open_notebook(self):
        self.menu, self.mode, self.page = None, "notebook", 0

    def toast(self, text, ttl=3.0):
        self.toasts.append([text, ttl])
        self.toasts = self.toasts[-3:]

    # ---- time
    def advance_time(self, minutes):
        for _ in range(minutes):
            self.minute += 1
            if self.minute >= logic.DAY_END:
                self.end_day(True)
                return
        self.refresh_npcs(False)

    def end_day(self, forced=False):
        self.action = None
        if self.day >= logic.DAYS:
            self.start_bad_ending()
            return
        self.day += 1
        self.audio.play("day")
        self.minute, self.acc = logic.DAY_START, 0.0
        self.scene = "town"
        self.px, self.py = W.HOTEL_SPAWN[0] + .5, W.HOTEL_SPAWN[1] + .5
        self.stalker, self.stalk_cd, self.stalk_warned = None, 6.0, False
        started = self.check_case2()
        self.refresh_npcs(True)
        self.save_game()
        lines = []
        if forced:
            lines.append(tr("22:00. Exhausted, you drag yourself back to the hotel."))
        if started:
            lines += self.case2_intro()
        if self.day == logic.STALK_DAY:
            lines.append(tr("You can't shake the feeling that someone is watching you."))
            lines.append(tr("A hooded figure has been seen following you around town."))
        elif self.day == logic.DAYS:
            lines.append(tr("This is the last day. Tonight he comes for you."))
            lines.append(tr("Make the arrest before 22:00."))
        else:
            lines.append(tr("%d days left.") % (logic.DAYS - self.day + 1))
        if self.settings["hints"] and self.day > 1:
            lines.append(tr("Hint: %s") % self.hint_text())
        self.show_card(tr("DAY %d") % self.day, lines)

    def check_case2(self):
        """The cafe murder is discovered on day 5 (also when days were lost to paperwork)."""
        if self.c2_on or self.day < case2.CASE2_DAY:
            return False
        self.c2_on = True
        self.apply_flags()
        return True

    def case2_intro(self):
        return [tr("%s, who owned Milo's Cafe, was found poisoned in his storeroom this morning.") % case2.VICTIM2,
                tr("A second murder in Cold Tide. The chief has sealed off the storeroom for you.")]

    # ---- interaction
    def dist(self, x, y):
        return math.hypot(self.px - x, self.py - y)

    def active_spots(self):
        return self.spots if self.scene == "town" else self.interior.spots_now

    def find_interact(self):
        best, bd = None, 99
        rad = 1.7 if self.scene == "town" else 2.6
        for n in self.here():
            d = self.dist(n["x"], n["y"])
            if d < rad and d < bd:
                best, bd = ("npc", n, tr("Talk to %s") % self.npc_name(n)), d
        if self.scene == "town":
            for b in self.world.buildings:
                d = self.dist(b["door"][0] + .5, b["approach"][1] + .3)
                if d < 1.5 and d < bd:
                    lab = {"police": tr("Enter the police station"), "hotel": tr("Enter the hotel"),
                           "cafe": tr("Visit the cafe")}.get(b["id"], tr("Check the door"))
                    best, bd = ("door", b, lab), d
            for sp in self.spots:
                if sp["kind"] == "pickup" and sp["id"] not in self.collected:
                    d = self.dist(*sp["pos"])
                    if d < 1.6 and d < bd:
                        best, bd = ("pickup", sp, tr("Take the camera still")), d
        else:
            it = self.interior
            d = self.dist(it.door[0] + .5, it.door[1] + .2)
            if d < 1.4 and d < bd:
                best, bd = ("exit", it, tr("Leave")), d
            for sp in it.spots_now:
                if sp["kind"] == "look":
                    d = self.dist(*sp["pos"])
                    if d < 1.5 and d < bd:
                        best, bd = ("look", sp, tr(sp["label"])), d
        return best

    def interact(self):
        it = self.find_interact()
        if not it:
            return
        kind, obj, _ = it
        if kind == "npc":
            self.talk_to(obj)
        elif kind == "pickup":
            self.begin_action(tr("Taking the still..."), 0.6, 5, lambda: self.collect("cctv"))
        elif kind == "look":
            self.examine(obj)
        elif kind == "exit":
            self.leave()
        elif obj["id"] in interiors.BUILDING_OF:
            self.enter(obj["id"])
        elif obj["id"] == "hotel":
            self.audio.play("door_open")
            self.hotel_menu()
        else:
            self.audio.play("knock")
            self.open_dialog([tr("Locked. Nobody answers."),
                              tr("(Dust the doorknob with the fingerprint kit [1] + SPACE.)")])

    def says(self, who, text):
        """One dialogue line 'Speaker: text' (the speaker name is translated; see audio.say)."""
        return tr(who) + ": " + text

    def talk_to(self, n):
        sid = n["id"]
        c = self.talk_count.get(sid, 0)
        self.talk_count[sid] = c + 1
        if n.get("staff"):
            if sid == "chief":
                self.police_menu()
            else:
                pool = (case2.OFFICER_TIPS if self.c2_on and not self.c2_done else []) + logic.OFFICER_LINES
                self.open_dialog([self.says(N_("Officer Dale"), tr(pool[c % len(pool)]))])
            return
        if n["place"] == "jail":
            self.open_dialog([logic.BY_ID[sid]["name"] + ": " + tr(case2.JAILED)])
            return
        lines = logic.dialogue(self.case, sid, self.day, self.minute, c)
        after = None
        if self.c2_on and not self.c2_done and sid in case2.SUSPECTS2:
            extra, lie = self.case2.talk(sid, self.collected)
            lines = lines + extra
            if lie:
                after = lambda: self.collect(lie)
        self.open_dialog(lines, after)

    def examine(self, sp):
        sid = sp["id"]
        if sid.startswith("c2_"):
            if sid in self.collected:
                self.collect(sid)                      # read it again
            else:
                self.begin_action(tr("Examining..."), 0.7, 5, lambda: self.collect(sid))
        elif sid == "board":
            self.open_notebook()
        elif sid == "coffee":
            self.advance_time(5)
            if self.mode == "play":
                self.open_dialog([tr("Police coffee. It tastes like burnt pennies, but you feel slightly more awake.")])
        elif sid == "cabinets":
            self.open_dialog([tr("Old case files: traffic fines, a stolen bicycle, a lost parrot."),
                              tr("One drawer is labelled 'Orchard'. It is empty. Somebody took the folder.")])
        elif sid == "locker":
            self.open_locker()
        elif sid == "counter":
            self.cafe_counter()
        elif sid == "jukebox":
            self.audio.play("clue")
            self.open_dialog([tr("The jukebox hums something slow. Outside, the tide keeps coming in.")])

    def open_locker(self):
        dale = lambda t: self.says(N_("Officer Dale"), t)
        if not self.c2_done:
            self.open_dialog([tr("A locked evidence cage."),
                              dale(tr("That one is mine, detective. Close the cafe case and I'll open it for you."))])
        elif "lab_report" in self.collected:
            self.open_dialog([dale(tr("Nothing else in there for you. The lab report is in your notebook."))])
        elif "beach_print" not in self.collected:
            self.open_dialog([dale(tr("I'd love to run the beach print for you, but you haven't lifted it yet."))])
        else:
            self.collect("lab_report")

    def cafe_counter(self):
        b = self.npcs["barista"]
        staffed = b["scene"] == "cafe" and b["place"] == "cafe" and not b["path"]
        tip = tr(logic.CAFE_TIPS[self.coffee % len(logic.CAFE_TIPS)])
        self.coffee += 1
        self.advance_time(10)
        if self.mode == "play":
            first = (self.says(N_("Milo's Cafe"), tr("Black coffee. On the house, detective.")) if staffed
                     else tr("Nobody is at the counter. You pour yourself a cup from the pot."))
            self.open_dialog([first, tip])

    def police_menu(self):
        chief = lambda t: self.says(N_("Chief"), t)

        def case_file():
            self.open_dialog([
                chief(tr("Victim is %s, found on the beach.") % logic.VICTIM),
                chief(tr("There is a partial print on his bag. A camera on the beach pole may have caught the killer.")),
                chief(tr("Bodies may be buried in the orchard woods. Bring the shovel.")),
                chief(tr("I need %d evidence points on a suspect before I can arrest anyone.") % logic.ARREST_NEEDED),
                chief(tr("Day %d of %d. Don't waste it.") % (self.day, logic.DAYS))],
                after=self.police_menu)

        def case_file2():
            self.open_dialog([
                chief(tr("Victim is %s, owner of the cafe. Poisoned in his own storeroom.") % case2.VICTIM2),
                chief(tr("The regulars are Edith, Lucia, Nora and Milo. One of them knows more than they say.")),
                chief(tr("Same rule: I need %d evidence points. A wrong arrest costs you two days.") % logic.ARREST_NEEDED)],
                after=self.police_menu)

        two = self.c2_on and not self.c2_done

        def pick_case():
            if two:
                items = [{"label": N_("The beach murder"), "enter": lambda: arrest_menu(1)},
                         {"label": N_("The cafe murder"), "enter": lambda: arrest_menu(2)},
                         {"label": N_("Back"), "enter": self.police_menu}]
                self.menu = Menu(N_("Request an arrest"), items, self.police_menu)
            else:
                arrest_menu(1)

        def arrest_menu(which):
            if which == 1:
                sc, go = self.scores(), self.try_arrest
                people = [(x["id"], x["name"]) for x in logic.SUSPECTS]
            else:
                sc, go = self.scores2(), self.try_arrest2
                people = [(sid, self.case2.name(sid)) for sid in case2.SUSPECTS2]
            items = [{"label": (lambda sid=sid, nm=nm: tr("%s (%s)  -  %d pts") % (nm, logic.job(sid), sc[sid])),
                      "enter": (lambda sid=sid: go(sid))} for sid, nm in people]
            back = pick_case if two else self.police_menu
            items.append({"label": N_("Back"), "enter": back})
            self.menu = Menu(N_("Request an arrest"), items, back)

        items = [{"label": N_("Read the case file"), "enter": case_file}]
        if two:
            items.append({"label": N_("Read the cafe murder file"), "enter": case_file2})
        items += [{"label": N_("Request an arrest"), "enter": pick_case},
                  {"label": N_("Leave"), "enter": self.to_play}]
        self.menu, self.mode = Menu(N_("Cold Tide PD"), items, self.to_play), "menu"

    def try_arrest(self, sid):
        pts = self.scores()[sid]
        name = logic.BY_ID[sid]["name"]
        if pts < logic.ARREST_NEEDED:
            self.not_enough(name, pts)
        elif sid == self.case.killer:
            self.mode, self.end_t = "win", 0.0
            self.menu = None
            self.audio.play("win")
        else:
            self.wrong_arrest(name)

    def try_arrest2(self, sid):
        pts = self.scores2()[sid]
        name = self.case2.name(sid)
        if pts < logic.ARREST_NEEDED:
            self.not_enough(name, pts)
        elif sid == self.case2.culprit:
            self.solve_case2()
        else:
            self.wrong_arrest(name)

    def not_enough(self, name, pts):
        self.open_dialog([self.says(N_("Chief"), tr("%s? I only have %d point(s) on them.") % (name, pts)),
                          self.says(N_("Chief"), tr("Bring me %d. Then we talk.") % logic.ARREST_NEEDED)],
                         after=self.police_menu)

    def wrong_arrest(self, name):
        self.audio.play("wrong")
        self.open_dialog([tr("%s is released. It was the wrong person.") % name,
                          tr("You lose two days to the paperwork.")], after=self.after_paperwork)
        self.day = min(logic.DAYS, self.day + 2)

    def after_paperwork(self):
        self.to_play()
        if self.check_case2():
            self.show_card(tr("DAY %d") % self.day, self.case2_intro())

    def solve_case2(self):
        cu = self.case2.culprit
        self.c2_done = True
        self.apply_flags()
        cell = self.ints["police"].seat("prisoner")
        self.npcs[cu].update(place="jail", scene="police", x=cell[0] + .5, y=cell[1] + .5, path=[], enter=None)
        self.audio.play("found")
        self.save_game()
        self.show_card(tr("CAFE MURDER SOLVED"), self.case2.confession(cu) + [
            tr("Officer Dale will run the beach print for you. Look in the evidence locker.")], after=self.to_play)

    def hotel_menu(self):
        last = self.day >= logic.DAYS
        items = [{"label": lambda: tr("Sleep until morning") + (" " + tr("(he is coming...)") if last else ""),
                  "enter": self.end_day},
                 {"label": N_("Leave"), "enter": self.leave_building}]
        self.menu, self.mode = Menu(N_("Hotel - Room 12"), items, self.leave_building), "menu"

    # ---- hints
    def hint_text(self):
        if self.c2_on and not self.c2_done and self.scene == "cafe":
            return self.case2.next_hint(self.collected)
        return logic.next_hint(self.case, self.collected, self.day, self.minute, self.jailed())

    def show_hint(self, text, secs=9.0):
        self.banner = [text, secs]
        self.hint_cd = 12.0
        self.idle = 0.0
        self.audio.play("hint")

    def ask_hint(self):
        self.audio.play("hint")
        self.open_dialog([tr("Detective's notes: %s") % self.hint_text()])

    def nearby_hint(self):
        """(key, text) when the player stands next to something but holds the wrong tool."""
        c = self.collected
        for sp in self.active_spots():
            if sp["kind"] == "print" and sp["id"] not in c and self.dist(*sp["pos"]) < 2.2 and self.tool != 0:
                if sp["id"] == "beach_print":
                    return sp["id"], tr("Try dusting the marker for prints: kit [1], then SPACE.")
                if sp["id"].startswith("c2_"):
                    return sp["id"], tr("Try dusting this for prints: kit [1], then SPACE.")
                name = logic.BY_ID[sp["id"][5:]]["name"]
                return sp["id"], tr("Try running the prints: dust %s's door with the kit [1], then SPACE.") % name
        if self.scene == "town" and self.tool != 2:
            for i, (sx, sy) in enumerate(W.MOUND_SITES):
                if "dig_%d" % i not in c and self.dist(sx + .5, sy + .6) < 2.5:
                    return "mound", tr("Try digging here: take the shovel [3], then press SPACE.")
        if self.tool != 1 and "cctv" in c:
            for n in self.here():
                if not n.get("staff") and "face_" + n["id"] not in c and self.dist(n["x"], n["y"]) < 4.0:
                    return "scan_" + n["id"], tr("Try the face scanner [2] on %s, then SPACE.") % logic.BY_ID[n["id"]]["name"]
        return None

    def update_hints(self, dt):
        self.hint_cd -= dt
        if not self.settings["hints"] or self.action:
            return
        nh = self.nearby_hint()
        if nh and nh[0] == self.near_key:
            self.near_t += dt
        else:
            self.near_key, self.near_t = (nh[0] if nh else None), 0.0
        if self.hint_cd > 0:
            return
        if nh and self.near_t > 1.2 and self.hint_seen.get(nh[0], 0) < 2:
            self.hint_seen[nh[0]] = self.hint_seen.get(nh[0], 0) + 1
            self.near_t = -20.0
            self.show_hint(nh[1])
            return
        self.idle += dt
        if self.idle > 90.0:
            self.show_hint(tr("Hint: %s") % self.hint_text())

    # ---- evidence
    def clue_case(self, cid):
        return self.case if cid in self.case.clues else self.case2

    def scores2(self):
        return self.case2.scores(self.collected)

    def collect(self, cid):
        case = self.clue_case(cid)
        c = case.clues[cid]
        new = cid not in self.collected
        self.idle = 0.0
        self.banner = None
        self.collected.add(cid)
        lines = [case.title(cid), case.text(cid)]
        if cid.startswith("door_"):
            lines.append(self.case.print_result(cid[5:], self.collected))
        if cid.startswith("c2_print_"):
            lines.append(self.case2.print_result(cid[9:], self.collected))
        if cid.startswith("dig_"):
            if c.get("points"):
                self.audio.play("found")
        elif new:
            self.audio.play("clue")
        sc = self.scores() if case is self.case else self.scores2()
        lines.append(tr("Evidence: %s") % ", ".join(
            "%s %d" % (logic.BY_ID[s]["name"].split()[0], v) for s, v in sc.items() if v))
        self.open_dialog(lines)

    def begin_action(self, label, secs, minutes, done):
        self.action = {"label": label, "t": 0.0, "dur": secs, "min": minutes, "done": done}

    def use_tool(self):
        if self.action:
            return
        if self.tool == 0:
            tgt, bd = None, 1.7
            for sp in self.active_spots():
                if sp["kind"] == "print":
                    d = self.dist(*sp["pos"])
                    if d < bd:
                        tgt, bd = sp, d
            if not tgt:
                self.toast(tr("Nothing to dust here."))
            elif tgt["id"] in self.collected:
                self.toast(tr("Already collected."))
            else:
                self.audio.play("brush")
                self.begin_action(tr("Dusting for prints..."), 0.9, 20, lambda: self.collect(tgt["id"]))
        elif self.tool == 1:
            tgt, bd = None, 99
            for n in self.here():
                d = self.dist(n["x"], n["y"])
                if not n.get("staff") and d < 5.5 and d < bd:
                    tgt, bd = n["id"], d
            if self.scene == "town" and self.stalker and self.dist(self.stalker["x"], self.stalker["y"]) < 6.5:
                tgt = "stalker"
            if not tgt:
                self.toast(tr("Nobody in range of the scanner."))
            else:
                self.audio.play("scan")
                self.begin_action(tr("Scanning face..."), 0.8, 5, lambda: self.scan_done(tgt))
        else:
            if self.scene != "town":
                self.toast(tr("You can't dig up the floor in here."))
                return
            site = None
            for i, (sx, sy) in enumerate(W.MOUND_SITES):
                if "dig_%d" % i not in self.collected and self.dist(sx + .5, sy + .6) < 1.5:
                    site = i
            self.audio.play("dig_short" if site is None else "dig")
            if site is None:
                self.begin_action(tr("Digging..."), 0.6, 10, lambda: self.toast(tr("Nothing buried here.")))
            else:
                self.begin_action(tr("Digging..."), 1.4, 45, lambda: self.collect("dig_%d" % site))

    def scan_done(self, tgt):
        if tgt == "stalker":
            cid, who = "stalk_scan", tr("Hooded stranger")
        else:
            cid, who = "face_" + tgt, logic.BY_ID[tgt]["name"] + " - " + logic.job(tgt)
        if "cctv" not in self.collected:
            self.open_dialog([who, tr("No reference image loaded. Find the beach camera still first.")])
        else:
            self.collect(cid)

    # ---- update
    def update(self, dt):
        self.screen = pygame.display.get_surface()
        self.toasts = [[t, ttl - dt] for t, ttl in self.toasts if ttl - dt > 0]
        if self.banner:
            self.banner[1] -= dt
            if self.banner[1] <= 0:
                self.banner = None
        if self.mode == "win" or self.mode == "bad_end":
            self.end_t += dt
        if self.mode == "dialog" and self.dialog:
            self.dialog["shown"] += dt * 70.0                      # the text appears letter by letter
        beach = clamp((self.py - 30.0) / 4.0, 0.0, 1.0) \
            if self.mode in ("play", "dialog", "menu", "notebook") and self.scene == "town" else 0.0
        self.audio.ambient(beach)
        if self.mode != "play":
            return
        if self.action:
            a = self.action
            a["t"] += dt
            self.moving = False
            if a["t"] >= a["dur"]:
                self.action = None
                self.advance_time(a["min"])
                if self.mode == "play":
                    a["done"]()
        else:
            self.move_player(dt)
        self.acc += dt
        spm = DAY_SPEEDS[self.settings["speed"]][1]
        while self.acc >= spm and self.mode == "play" and not self.action:
            self.acc -= spm
            self.advance_time(1)
        if self.mode != "play":
            return
        for n in self.npcs.values():
            follow(n, dt, 1.6)
            if n.get("enter") and not n["path"]:
                self.step_into_building(n)
        if self.scene == "town":
            self.update_stalker(dt)
        self.update_hints(dt)
        self.panim += dt

    def blocked(self, x, y):
        for cx, cy in ((x - .28, y - .2), (x + .28, y - .2), (x - .28, y), (x + .28, y)):
            if self.grid().is_solid(int(math.floor(cx)), int(math.floor(cy))):
                return True
        return False

    def move_player(self, dt):
        k = pygame.key.get_pressed()
        dx = (k[pygame.K_d] or k[pygame.K_RIGHT]) - (k[pygame.K_a] or k[pygame.K_LEFT] or k[pygame.K_q])
        dy = (k[pygame.K_s] or k[pygame.K_DOWN]) - (k[pygame.K_w] or k[pygame.K_UP] or k[pygame.K_z])
        self.moving = bool(dx or dy)
        if not self.moving:
            self.step_t = 0.0
            return
        self.step_t -= dt
        if self.step_t <= 0:
            self.step_t = 0.3
            if self.scene == "town":
                g = self.world.ground[clamp(int(self.py), 0, W.MAP_H - 1)][clamp(int(self.px), 0, W.MAP_W - 1)]
                self.audio.step("sand" if g == "S" else "grass" if g == "G" else "hard")
            else:
                self.audio.step("hard")
        n = math.hypot(dx, dy)
        sx, sy = dx / n * PLAYER_SPEED * dt, dy / n * PLAYER_SPEED * dt
        if not self.blocked(self.px + sx, self.py):
            self.px += sx
        if not self.blocked(self.px, self.py + sy):
            self.py += sy
        if abs(dx) >= abs(dy) and dx:
            self.facing = "right" if dx > 0 else "left"
        elif dy:
            self.facing = "down" if dy > 0 else "up"
        if self.scene != "town" and (int(self.px), int(self.py)) == self.interior.door:
            self.leave()                                           # walked out through the door

    def update_stalker(self, dt):
        if self.day < logic.STALK_DAY or self.minute < 720:
            self.stalker = None
            return
        keep, speed = logic.stalker_params(self.day)
        s = self.stalker
        if s is None:
            self.stalk_cd -= dt
            if self.stalk_cd <= 0:
                for _ in range(40):
                    a, r = random.uniform(0, 6.283), random.uniform(11, 13)
                    tx, ty = int(self.px + math.cos(a) * r), int(self.py + math.sin(a) * r)
                    if 0 <= tx < W.MAP_W and 0 <= ty < W.MAP_H and not self.world.is_solid(tx, ty):
                        self.stalker = {"x": tx + .5, "y": ty + .5, "dir": "down", "moving": False,
                                        "path": [], "repath": 0.0}
                        if not self.stalk_warned:
                            self.toast(tr("Someone is following you..."), 4)
                            self.stalk_warned = True
                        break
            return
        d = self.dist(s["x"], s["y"])
        if d < 11:
            self.audio.heartbeat(dt, d)
        if d < 2.4 and self.day < logic.DAYS:
            self.stalker, self.stalk_cd = None, 25.0
            self.toast(tr("He slips away between the trees."))
            return
        if d > keep:
            s["repath"] -= dt
            if s["repath"] <= 0:
                s["path"] = self.world.path((int(s["x"]), int(s["y"])), (int(self.px), int(self.py)))
                s["repath"] = 0.5
            follow(s, dt, speed)
        else:
            s["moving"] = False

    # ---- events
    def handle(self, e):
        if e.type == pygame.QUIT:
            self.running = False
        elif e.type == pygame.KEYDOWN:
            if e.key == pygame.K_F11 or (e.key in (pygame.K_RETURN, pygame.K_KP_ENTER) and e.mod & pygame.KMOD_ALT):
                self.toggle_fullscreen()
                return
            getattr(self, "key_" + self.mode, lambda k: None)(e.key)
        elif e.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN) and self.mode in ("title", "menu"):
            self.mouse_menu(e)
        elif e.type == pygame.VIDEORESIZE:
            self.vig = None

    def mouse_menu(self, e):
        """Menus can also be used with the mouse: hover selects, left click chooses, right click goes back."""
        m = self.menu
        if not m:
            return
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 3 and m.back:
            m.back()
            return
        for rect, i in self.mouse_rects:
            if rect.collidepoint(e.pos):
                if m.sel != i:
                    m.sel = i
                    self.audio.play("ui_move")
                if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                    f = m.items[i].get("enter")
                    f and f()
                return

    def key_title(self, k):
        self.key_menu(k)

    def key_menu(self, k):
        m = self.menu
        if not m:
            return
        if k in (pygame.K_UP, pygame.K_w):
            m.sel = (m.sel - 1) % len(m.items)
            self.audio.play("ui_move")
        elif k in (pygame.K_DOWN, pygame.K_s):
            m.sel = (m.sel + 1) % len(m.items)
            self.audio.play("ui_move")
        elif k in (pygame.K_LEFT, pygame.K_a):
            f = m.items[m.sel].get("left")
            f and f()
        elif k in (pygame.K_RIGHT, pygame.K_d):
            f = m.items[m.sel].get("right")
            f and f()
        elif k in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e):
            f = m.items[m.sel].get("enter")
            f and f()
        elif k == pygame.K_ESCAPE and m.back:
            m.back()

    def key_play(self, k):
        if self.action:
            return
        if k == pygame.K_ESCAPE:
            self.pause_menu()
        elif k == pygame.K_e:
            self.interact()
        elif k == pygame.K_SPACE:
            self.use_tool()
        elif k in (pygame.K_1, pygame.K_2, pygame.K_3):
            self.tool = k - pygame.K_1
        elif k == pygame.K_TAB:
            self.tool = (self.tool + 1) % 3
        elif k == pygame.K_n:
            self.open_notebook()
        elif k == pygame.K_h:
            self.ask_hint()

    def parse_line(self, line):
        """(portrait key, speaker, text, worried) for a dialogue line 'Speaker: text'.
        Lines without a speaker that has a portrait (clues, narration) give key None."""
        if ": " in line:
            who, text = line.split(": ", 1)
            key = logic.PORTRAITS.get(i18n.canonical(who.strip()))
            if key and self.portraits.has(key):
                worried = i18n.canonical(text) in WORRIED_LINES
                return key, who.strip(), text, worried
        return None, "", line, False

    def key_dialog(self, k):
        if k in (pygame.K_e, pygame.K_RETURN, pygame.K_SPACE, pygame.K_ESCAPE):
            d = self.dialog
            full = len(self.parse_line(d["lines"][d["i"]])[2])
            if d["shown"] < full:                      # first press: show the whole line
                d["shown"] = full
                return
            d["i"] += 1
            d["shown"] = 0.0
            if d["i"] < len(d["lines"]):
                self.audio.say(d["lines"][d["i"]])
            else:
                self.audio.stop_voice()
            if d["i"] >= len(d["lines"]):
                self.dialog, self.mode = None, "play"
                if d["after"]:
                    d["after"]()

    def key_card(self, k):
        if k in (pygame.K_e, pygame.K_RETURN, pygame.K_SPACE):
            after = self.card["after"]
            self.card, self.mode = None, "play"
            if after:
                after()

    def key_notebook(self, k):
        if k in (pygame.K_ESCAPE, pygame.K_n):
            self.mode = "play"
        elif k in (pygame.K_LEFT, pygame.K_a):
            self.page = (self.page - 1) % self.npages()
        elif k in (pygame.K_TAB, pygame.K_RIGHT, pygame.K_d):
            self.page = (self.page + 1) % self.npages()

    def key_win(self, k):
        if k == pygame.K_RETURN and self.end_t > 2:
            self.title_menu()

    def key_bad_end(self, k):
        if k == pygame.K_RETURN and self.end_t > 17:
            self.title_menu()

    def start_bad_ending(self):
        self.mode, self.end_t = "bad_end", 0.0
        self.audio.play("doom")
        try:
            SAVE_FILE.unlink()
        except Exception:
            pass

    # ---- drawing helpers
    def font(self, size):
        size = max(8, int(size))
        if size not in self.fonts:
            f = None
            if self.font_file:
                try:
                    f = pygame.font.Font(self.font_file, max(8, int(size * FONT_SCALE)))
                except Exception:
                    f = None
            self.fonts[size] = f or pygame.font.Font(None, size)
        return self.fonts[size]

    def text(self, s, size, pos, color=CREAM, anchor="topleft", shadow=True):
        f = self.font(size * self.U)
        key = (s, int(max(8, size * self.U)), tuple(color), shadow, self.settings["lang"])
        hit = self.tcache.get(key)
        if hit is None:
            if len(self.tcache) > 900:
                self.tcache.clear()
            hit = (f.render(s, True, INK) if shadow else None, f.render(s, True, color))
            self.tcache[key] = hit
        sh, img = hit
        r = img.get_rect(**{anchor: pos})
        if sh is not None:
            self.screen.blit(sh, r.move(max(1, self.U), max(1, self.U)))
        self.screen.blit(img, r)
        return r

    def wrap_cjk(self, s, size, maxw):
        """Line breaking for Chinese: any character may start a new line (words are not
        separated by spaces), but closing punctuation never starts one."""
        f = self.font(size * self.U)
        tokens = re.findall(r"[^\s\u2e80-\u9fff\uf900-\ufaff\uff00-\uffef\u3000-\u303f]+|[\u2e80-\u9fff\uf900-\ufaff\uff00-\uffef\u3000-\u303f]|\s+", s)
        lines, cur = [], ""
        for t in tokens:
            if t.isspace() and not cur:
                continue
            if cur and f.size(cur + t)[0] > maxw and t[0] not in NO_LINE_START and not t.isspace():
                lines.append(cur.rstrip())
                cur = t
            else:
                cur += t
        lines.append(cur.rstrip())
        return lines

    def wrap(self, s, size, maxw):
        if CJK.search(s):
            return self.wrap_cjk(s, size, maxw)
        f = self.font(size * self.U)
        words, lines, cur = s.split(), [], ""
        for w in words:
            t = (cur + " " + w).strip()
            if f.size(t)[0] > maxw and cur:
                lines.append(cur)
                cur = w
            else:
                cur = t
        lines.append(cur)
        return lines

    def panel(self, rect, color=(30, 22, 24, 215), border=CREAM):
        w, h = max(1, int(rect[2])), max(1, int(rect[3]))
        key = (w, h, color, border, int(self.U * 10))
        s = self.pcache.get(key)
        if s is None:
            if len(self.pcache) > 200:
                self.pcache.clear()
            s = pygame.Surface((w, h), pygame.SRCALPHA)
            rad = max(2, int(3 * self.U))
            pygame.draw.rect(s, color, (0, 0, w, h), border_radius=rad)
            if border:
                pygame.draw.rect(s, border, (0, 0, w, h), max(1, int(self.U)), border_radius=rad)
                inner = pygame.Rect(int(2 * self.U), int(2 * self.U), w - int(4 * self.U), h - int(4 * self.U))
                if inner.w > 4 and inner.h > 4:
                    pygame.draw.rect(s, tuple(border[:3]) + (70,), inner, 1, border_radius=max(1, rad - 1))
            self.pcache[key] = s
        self.screen.blit(s, (int(rect[0]), int(rect[1])))

    def dim(self, a=150):
        sw, sh = self.screen.get_size()
        key = (sw, sh, a)
        s = self.dim_cache.get(key)
        if s is None:
            if len(self.dim_cache) > 6:
                self.dim_cache.clear()
            s = pygame.Surface((sw, sh), pygame.SRCALPHA)
            s.fill((10, 8, 14, a))
            self.dim_cache[key] = s
        self.screen.blit(s, (0, 0))

    # ---- drawing: world
    SKY = [(480, (226, 232, 255)), (570, (255, 252, 250)), (840, (255, 253, 244)), (1020, (255, 238, 208)),
           (1110, (255, 198, 150)), (1170, (206, 150, 176)), (1260, (110, 124, 188)), (1320, (84, 98, 166))]

    def tint(self, minute=None):
        """Colour of the daylight: cool morning, bright noon, golden afternoon, pink dusk, blue night."""
        m = self.minute if minute is None else minute
        pts = self.SKY
        if m <= pts[0][0]:
            return pts[0][1]
        for (m0, c0), (m1, c1) in zip(pts, pts[1:]):
            if m <= m1:
                return lerp3(c0, c1, (m - m0) / float(m1 - m0))
        return pts[-1][1]

    def night_k(self, minute=None):
        m = self.minute if minute is None else minute
        return clamp((m - 1080) / 150.0, 0.0, 1.0)

    def glow(self, level, pool=False):
        """Warm additive light sprites (lamp halo / light pool on the ground), cached per brightness."""
        key = (level, pool)
        g = self.glows.get(key)
        if g is None:
            if "base" not in self.glows:
                R = 56
                b = pygame.Surface((R * 2, R * 2))
                for yy in range(R * 2):
                    for xx in range(R * 2):
                        d = math.hypot(xx - R + .5, yy - R + .5) / R
                        a = max(0.0, 1 - d) ** 2
                        b.set_at((xx, yy), (int(255 * a), int(190 * a), int(100 * a)))
                self.glows["base"] = b
            g = self.glows["base"]
            if pool:
                g = pygame.transform.smoothscale(g, (120, 40))
            g = g.copy()
            v = int(255 * level / 6.0)
            g.fill((v, v, v), special_flags=pygame.BLEND_RGB_MULT)
            self.glows[key] = g
        return g

    def smoke_puffs(self):
        if self.puffs is None:
            self.puffs = []
            for i in range(8):
                r = 2 + i
                sf = pygame.Surface((r * 2 + 2, r * 2 + 2), pygame.SRCALPHA)
                pygame.draw.circle(sf, (232, 232, 240, int(96 * (1 - i / 8.0))), (r + 1, r + 1), r)
                pygame.draw.circle(sf, (255, 255, 255, int(50 * (1 - i / 8.0))), (r, r), max(1, r - 2))
                self.puffs.append(sf)
        return self.puffs

    def tree_key(self, tx, ty):
        p = self.pack
        if not p.hd:
            return "tree"
        h = (tx * 13 + ty * 7 + tx * ty) % 11
        if tx >= 44:
            return "tree3" if h < 5 else "tree2" if h < 7 else "tree"
        return "tree_apple" if h < 3 else "tree2" if h < 5 else "tree"

    def anchor(self, img, tx, ty, cx=0.5):
        """Top-left pixel of a sprite standing on tile (tx, ty): bottom centre of the tile."""
        T = self.pack.T
        return (tx * T + T * cx - img.get_width() / 2.0, (ty + 1) * T - img.get_height())

    def draw_world(self, focus=None, minute=None, title=False):
        p, T, cv = self.pack, self.pack.T, self.canvas
        CW, CH = cv.get_size()
        fx, fy = focus if focus else (self.px, self.py)
        minute = self.minute if minute is None else minute
        t = self.t
        camx = int(clamp(fx * T - CW / 2, 0, W.MAP_W * T - CW))
        camy = int(clamp(fy * T - CH / 2, 0, W.MAP_H * T - CH))
        cv.blit(self.ground, (0, 0), pygame.Rect(camx, camy, CW, CH))
        tx0, ty0 = camx // T, camy // T
        tx1, ty1 = min(W.MAP_W, tx0 + VIEW_W + 2), min(W.MAP_H, ty0 + VIEW_H + 2)
        if p.hd:
            fr = int(t * 2.2) % 4
            for tx, ty, depth, foam in self.water_cells:
                if tx0 <= tx < tx1 and ty0 <= ty < ty1:
                    pos = (tx * T - camx, ty * T - camy)
                    cv.blit(p.img("water_%s%d" % (depth, fr)), pos)
                    if foam:
                        cv.blit(p.img("foam%d" % fr), pos)
        else:
            wf = p.img("water1" if int(t * 1.6) % 2 == 0 else "water2")
            for tx, ty, depth, foam in self.water_cells:
                if tx0 <= tx < tx1 and ty0 <= ty < ty1:
                    cv.blit(wf, (tx * T - camx, ty * T - camy))
        if not title:
            for dx in (-1, 0, 1):
                for yy in (W.CRIME_SCENE[1] - 1, W.CRIME_SCENE[1] + 1):
                    cv.blit(p.img("tape"), ((W.CRIME_SCENE[0] + dx) * T - camx, yy * T - camy))
            if "beach_print" not in self.collected:
                cv.blit(p.img("marker"), self.anchor_xy(p.img("marker"), W.CRIME_SCENE, camx, camy))
        for i, (sx, sy) in enumerate(W.MOUND_SITES):
            key = "mound_dug" if "dig_%d" % i in self.collected and not title else "mound"
            cv.blit(p.img(key), (sx * T - camx, sy * T - camy))
        ents = []
        for b in self.world.buildings:
            if b["x"] + b["w"] >= tx0 and b["x"] <= tx1 and b["y"] + b["h"] >= ty0 and b["y"] <= ty1:
                ents.append((b["y"] + b["h"], p.img(b["id"]), (b["x"] * T, b["y"] * T)))
        for tx, ty in self.world.trees:
            if tx0 - 1 <= tx <= tx1 and ty0 - 1 <= ty <= ty1:
                img = p.img(self.tree_key(tx, ty))
                ents.append((ty + 1, img, self.anchor(img, tx, ty)))
        for tx, ty in self.world.rocks:
            if tx0 - 1 <= tx <= tx1 and ty0 - 1 <= ty <= ty1:
                img = p.img("rock2" if p.hd and (tx + ty) % 3 == 0 else "rock")
                ents.append((ty + 1, img, self.anchor(img, tx, ty)))
        if p.hd:
            for key, tx, ty, extra in self.world.props:
                if p.has(key) and tx0 - 3 <= tx <= tx1 + 1 and ty0 - 2 <= ty <= ty1 + 3:
                    img = p.img(key)
                    ents.append((ty + 1, img, self.anchor(img, tx, ty, 0.5 + extra / 2.0)))
            for key, tx, ty in self.free_props:
                if p.has(key) and tx0 - 1 <= tx <= tx1 and ty0 - 1 <= ty <= ty1:
                    img = p.img(key)
                    ents.append((ty + 1, img, self.anchor(img, tx, ty)))
        cc = p.img("cctv")
        ents.append((W.CCTV_POS[1] + 1, cc, self.anchor(cc, W.CCTV_POS[0], W.CCTV_POS[1])))
        shadow = p.img("shadow_char") if p.has("shadow_char") else None
        people = [] if title else list(self.here())
        for n in people:
            if shadow:
                ents.append((n["y"] - 0.02, shadow, (n["x"] * T - 16, n["y"] * T - 8)))
            ents.append(char_sprite(p, n["sheet"], n["x"], n["y"], n["dir"], n["moving"], t))
        if not title:
            if shadow:
                ents.append((self.py - 0.02, shadow, (self.px * T - 16, self.py * T - 8)))
            ents.append(char_sprite(p, "player", self.px, self.py, self.facing, self.moving, self.panim))
            if self.stalker:
                s_ = self.stalker
                ents.append(char_sprite(p, logic.BY_ID[self.case.killer]["sheet"], s_["x"], s_["y"],
                                        s_["dir"], s_["moving"], t, sil=True))
        ents.sort(key=lambda e: e[0])
        for _, img, (x, y) in ents:
            cv.blit(img, (int(round(x)) - camx, int(round(y)) - camy))
        if p.hd:
            self.draw_smoke(cv, camx, camy, tx0, tx1, ty0, ty1)
        if self.settings["lighting"]:
            cv.fill(self.tint(minute), special_flags=pygame.BLEND_RGB_MULT)
            nk = self.night_k(minute)
            if p.hd:
                self.draw_night_lights(cv, camx, camy, tx0, tx1, ty0, ty1, nk)
                self.draw_fx(cv, camx, camy, nk, minute)
            cv.blit(self.vignette_light(CW, CH), (0, 0), special_flags=pygame.BLEND_RGB_MULT)

    def anchor_xy(self, img, tile, camx, camy):
        x, y = self.anchor(img, tile[0], tile[1])
        return (int(x) - camx, int(y) - camy)

    def draw_smoke(self, cv, camx, camy, tx0, tx1, ty0, ty1):
        T, puffs = self.pack.T, self.smoke_puffs()
        for b in self.world.buildings:
            m = self.pack.buildings.get(b["id"], {})
            ch = m.get("chimney")
            if not ch or not (tx0 - 2 <= b["x"] <= tx1 and ty0 - 2 <= b["y"] <= ty1):
                continue
            bx, by = b["x"] * T + ch[0] - camx, b["y"] * T + ch[1] - camy
            for k in range(4):
                age = (self.t * 0.16 + k * 0.25 + b["x"] * 0.07) % 1.0
                sf = puffs[min(7, int(age * 8))]
                px_ = bx + math.sin(self.t * 0.8 + k * 1.7 + b["x"]) * 3 + age * 14
                py_ = by - age * 40
                cv.blit(sf, (int(px_) - sf.get_width() // 2, int(py_) - sf.get_height() // 2))

    def draw_night_lights(self, cv, camx, camy, tx0, tx1, ty0, ty1, nk):
        """After dusk: lit windows, streetlamp halos with light pools, door lanterns."""
        if nk <= 0.02:
            return
        T, p = self.pack.T, self.pack
        for b in self.world.buildings:
            if b["x"] + b["w"] >= tx0 and b["x"] <= tx1 and b["y"] + b["h"] >= ty0 and b["y"] <= ty1 \
                    and p.has(b["id"] + "_lit"):
                img = p.img(b["id"] + "_lit")
                img.set_alpha(int(255 * nk))
                cv.blit(img, (b["x"] * T - camx, b["y"] * T - camy))
        for i, (key, tx, ty, extra) in enumerate(self.world.props):
            if key != "prop_lamp" or not (tx0 - 3 <= tx <= tx1 + 3 and ty0 - 3 <= ty <= ty1 + 4):
                continue
            lv = int(round(clamp(nk * (1.0 + 0.035 * math.sin(self.t * 7.0 + i * 2.3)), 0, 1) * 6))
            if lv <= 0:
                continue
            hx, hy = tx * T + T // 2 - camx, (ty + 1) * T - 70 - camy
            cv.blit(self.glow(lv), (hx - 56, hy - 56), special_flags=pygame.BLEND_RGB_ADD)
            cv.blit(self.glow(lv, True), (hx - 60, (ty + 1) * T - 20 - camy), special_flags=pygame.BLEND_RGB_ADD)

    def draw_fx(self, cv, camx, camy, nk, minute):
        """Fireflies at night, butterflies by day (stateless, a handful of pixels)."""
        T, t = self.pack.T, self.t
        CW, CH = cv.get_size()
        if self.scene != "town":
            return
        night = nk > 0.4
        if not night and not 600 <= minute < 1000:
            return
        for i in range(14 if night else 5):
            x = (i * 173.0 + 18 * math.sin(t * 0.5 + i * 1.3) + t * (2 + i % 3)) % CW
            y = (i * 97.0 + 12 * math.cos(t * 0.4 + i * 2.1)) % CH
            tx, ty = int((x + camx) // T), int((y + camy) // T)
            if not (0 <= tx < W.MAP_W and 0 <= ty < W.MAP_H) or self.world.ground[ty][tx] != "G":
                continue
            if night:
                if math.sin(t * 1.7 + i * 3.1) < -0.2:
                    continue
                pygame.draw.rect(cv, (214, 255, 150), (int(x), int(y), 2, 2))
                pygame.draw.rect(cv, (120, 170, 80), (int(x) - 1, int(y) - 1, 4, 4), 1)
            else:
                flap = int(t * 9 + i) % 2
                col = ((250, 190, 90), (240, 140, 180), (150, 190, 250))[i % 3]
                pygame.draw.rect(cv, col, (int(x) - 2, int(y) - flap, 2, 2 + flap))
                pygame.draw.rect(cv, col, (int(x) + 1, int(y) - flap, 2, 2 + flap))
                pygame.draw.rect(cv, (60, 40, 40), (int(x), int(y), 1, 2))

    def vignette_light(self, w, h):
        key = (w, h)
        v = self.vig_light.get(key)
        if v is None:
            sw, sh = 48, 27
            small = pygame.Surface((sw, sh))
            for yy in range(sh):
                for xx in range(sw):
                    dx, dy = (xx + .5) / sw * 2 - 1, (yy + .5) / sh * 2 - 1
                    d = min(1.0, (dx * dx * .85 + dy * dy * 1.0) ** 0.5)
                    k = 255 - int(62 * max(0.0, d - 0.45) ** 1.6 / 0.55 ** 1.6)
                    small.set_at((xx, yy), (k, k, k))
            v = pygame.transform.smoothscale(small, (w, h))
            self.vig_light[key] = v
        return v

    def interior_surface(self):
        """Floor and walls of the room the player is in, drawn once per texture pack."""
        it, p = self.interior, self.pack
        key = (it.id, p.name)
        if key not in self.int_surf:
            T = p.T
            surf = pygame.Surface((it.w * T, it.h * T))
            for y in range(it.h):
                for x in range(it.w):
                    for name in (it.floor[y][x], it.walls[y][x]):
                        if name:
                            surf.blit(p.img(name), (x * T, y * T))
            if p.hd:
                self.bake_interior_shadows(surf, it)
            self.int_surf[key] = surf
        return self.int_surf[key]

    def bake_interior_shadows(self, surf, it):
        T = self.pack.T
        for j in range(10):                                   # the back wall shades the floor
            a = int(90 * (1 - j / 10.0) ** 1.6)
            band = pygame.Surface(((it.w - 2) * T, 1), pygame.SRCALPHA)
            band.fill((20, 14, 36, a))
            surf.blit(band, (T, 2 * T + j))
        for j in range(8):                                    # and the side walls
            a = int(70 * (1 - j / 8.0) ** 1.6)
            col = pygame.Surface((1, (it.h - 3) * T), pygame.SRCALPHA)
            col.fill((20, 14, 36, a))
            surf.blit(col, (T + j, 2 * T))
            surf.blit(col, ((it.w - 1) * T - 1 - j, 2 * T))
        for item in it.items:                                 # furniture shadows (fixed pieces only)
            if item["cond"] or item["flat"]:
                continue
            for rx, ry, rw, rh in item["solid"]:
                sh = pygame.Surface((rw * T + 6, 12), pygame.SRCALPHA)
                pygame.draw.ellipse(sh, (20, 14, 36, 80), sh.get_rect())
                surf.blit(sh, (rx * T - 1, (ry + rh) * T - 6))

    def light_shaft(self, w, bucket):
        key = ("shaft", w, bucket)
        s_ = self.glows.get(key)
        if s_ is None:
            col = {0: (60, 54, 30), 1: (66, 38, 22), 2: (8, 12, 30)}[bucket]
            H = int(self.pack.T * 3.6)
            s_ = pygame.Surface((w + H // 2, H))
            for yy in range(H):
                k = (1 - yy / float(H)) ** 1.5
                x0 = int(yy * 0.5)
                pygame.draw.line(s_, tuple(int(c * k) for c in col), (x0, yy), (x0 + w - 1, yy))
            self.glows[key] = s_
        return s_

    def draw_interior(self):
        p, T, cv, it = self.pack, self.pack.T, self.canvas, self.interior
        CW, CH = cv.get_size()
        ox, oy = (CW - it.w * T) // 2, (CH - it.h * T) // 2
        cv.fill((12, 10, 16))
        cv.blit(self.interior_surface(), (ox, oy))
        ents = []
        for item in it.items_now:
            img, pos = p.img(item["sprite"]), (item["x"] * T + ox, item["y"] * T + oy)
            if item["flat"]:
                cv.blit(img, pos)
            else:
                ents.append((item["y"] + item["h"] + item["z"], img, pos))
        shadow = p.img("shadow_char") if p.has("shadow_char") else None
        sprites = []
        for n in self.here():
            if shadow:
                sprites.append((n["y"] - 0.02, shadow, (n["x"] * T - 16, n["y"] * T - 8)))
            sprites.append(char_sprite(p, n["sheet"], n["x"], n["y"], n["dir"], n["moving"], self.t))
        if shadow:
            sprites.append((self.py - 0.02, shadow, (self.px * T - 16, self.py * T - 8)))
        sprites.append(char_sprite(p, "player", self.px, self.py, self.facing, self.moving, self.panim))
        for y, img, (x, yy) in sprites:
            ents.append((y, img, (x + ox, yy + oy)))
        ents.sort(key=lambda e: e[0])
        for _, img, (x, y) in ents:
            cv.blit(img, (int(round(x)), int(round(y))))
        if p.hd and self.settings["lighting"]:
            m = self.minute
            bucket = 0 if m < 1020 else 1 if m < 1200 else 2
            for item in it.items_now:                     # sunlight (or moonlight) through the windows
                if item["sprite"].startswith("i_window"):
                    wpx = item["w"] * T - 24
                    cv.blit(self.light_shaft(wpx, bucket),
                            (item["x"] * T + ox + 12, (item["y"] + item["h"]) * T + oy - 6),
                            special_flags=pygame.BLEND_RGB_ADD)
            cv.fill(lerp3((255, 247, 232), self.tint(), 0.22), special_flags=pygame.BLEND_RGB_MULT)
            cv.blit(self.vignette_light(CW, CH), (0, 0), special_flags=pygame.BLEND_RGB_MULT)

    def present_canvas(self, cover=False):
        sw, sh = self.screen.get_size()
        cw, ch = self.canvas.get_size()
        sc = max(sw / float(cw), sh / float(ch)) if cover else min(sw / float(cw), sh / float(ch))
        if self.settings["integer"]:
            sc = max(1, int(sc))
        elif not cover and round(sc) >= 1 and abs(sc - round(sc)) < 0.04:
            sc = float(round(sc))              # e.g. 1080p: 1.985 -> exactly 2 (a 2 px sliver is cropped)
        dw, dh = int(cw * sc), int(ch * sc)
        self.screen.fill((0, 0, 0))
        # HD art is smoothed only when the scale is far from a whole number (no shimmering at 1.33x);
        # whole-number scales and the 16 px packs stay perfectly sharp.
        smooth = self.pack.T >= 24 and sc < 3 and abs(sc - round(sc)) > 0.04 and not self.settings["integer"]
        buf = self.scale_buf.get((dw, dh, smooth))
        if buf is None:
            self.scale_buf.clear()
            buf = pygame.Surface((dw, dh), 0, self.canvas)
            self.scale_buf[(dw, dh, smooth)] = buf
        try:
            (pygame.transform.smoothscale if smooth else pygame.transform.scale)(self.canvas, (dw, dh), buf)
        except (ValueError, pygame.error):
            buf = (pygame.transform.smoothscale if smooth else pygame.transform.scale)(self.canvas, (dw, dh))
        self.screen.blit(buf, ((sw - dw) // 2, (sh - dh) // 2))

    def draw_vignette(self):
        if not self.stalker:
            return
        d = self.dist(self.stalker["x"], self.stalker["y"])
        k = clamp((10 - d) / 7.0, 0, 1)
        if k <= 0:
            return
        sw, sh = self.screen.get_size()
        if self.vig is None or self.vig.get_size() != (sw, sh):
            v = pygame.Surface((sw, sh), pygame.SRCALPHA)
            step = max(2, sw // 80)
            for i in range(14):
                pygame.draw.rect(v, (110, 0, 10, int(200 * (14 - i) / 14.0)),
                                 pygame.Rect(i * step, i * step, sw - 2 * i * step, sh - 2 * i * step), step)
            self.vig = v
        self.vig.set_alpha(int(255 * k))
        self.screen.blit(self.vig, (0, 0))

    # ---- drawing: HUD & screens
    def draw_hud(self):
        sw, sh = self.screen.get_size()
        U = self.U
        show2 = self.c2_on and not self.c2_done
        self.panel((10 * U, 10 * U, 210 * U, (62 if show2 else 46) * U))
        self.text(tr("Day %d / %d") % (self.day, logic.DAYS), 24, (20 * U, 16 * U), GOLD)
        self.text(hhmm(self.minute), 24, (190 * U, 16 * U), CREAM, "topright")
        sc = self.scores()
        best = max(sc.values())
        self.text(tr("Best lead: %d / %d pts") % (best, logic.ARREST_NEEDED), 17, (20 * U, 36 * U),
                  (190, 230, 190) if best >= logic.ARREST_NEEDED else CREAM)
        if show2:
            best2 = max(self.scores2().values())
            self.text(tr("Cafe case: %d / %d pts") % (best2, logic.ARREST_NEEDED), 17, (20 * U, 52 * U),
                      (190, 230, 190) if best2 >= logic.ARREST_NEEDED else CREAM)
        slot = 44 * U
        x0 = sw / 2 - slot * 1.6
        for i, (name, icon) in enumerate(TOOLS):
            r = pygame.Rect(int(x0 + i * slot * 1.1), int(sh - slot - 14 * U), int(slot), int(slot))
            self.panel(r, (30, 22, 24, 200), GOLD if i == self.tool else INK)
            ic = pygame.transform.scale(self.pack.img(icon), (int(slot * .7), int(slot * .7)))
            self.screen.blit(ic, (r.x + int(slot * .15), r.y + int(slot * .15)))
            self.text(str(i + 1), 15, (r.x + 3 * U, r.y + 2 * U))
        self.text(tr("%s  (SPACE)") % tr(TOOLS[self.tool][0]), 17, (sw / 2, sh - slot - 20 * U), GOLD, "midbottom")
        it = self.find_interact() if not self.action else None
        if it:
            self.text(tr("E  -  %s") % it[2], 20, (sw / 2, sh - slot - 44 * U), CREAM, "midbottom")
        if self.banner and not self.action:
            bw = min(sw * .62, 640 * U)
            lines = self.wrap(self.banner[0], 21, bw - 28 * U)
            bh = (len(lines) * 23 + 20) * U
            r = pygame.Rect(int(sw / 2 - bw / 2), int(66 * U), int(bw), int(bh))
            self.panel(r, (30, 22, 24, 225), GOLD)
            for i, ln in enumerate(lines):
                self.text(ln, 21, (r.x + 14 * U, r.y + (10 + 23 * i) * U), (255, 235, 170))
        self.text(tr("H hint    N notebook"), 15, (sw - 10 * U, sh - 10 * U), CREAM, "bottomright")
        y = sh - slot - 70 * U
        for t, _ in self.toasts[::-1]:
            self.text(t, 20, (sw / 2, y), (255, 235, 170), "midbottom")
            y -= 24 * U
        if self.action:
            a = self.action
            w = 220 * U
            r = pygame.Rect(int(sw / 2 - w / 2), int(sh / 2 - 70 * U), int(w), int(16 * U))
            self.panel(r, (30, 22, 24, 220))
            pygame.draw.rect(self.screen, GOLD, pygame.Rect(r.x, r.y, int(w * clamp(a["t"] / a["dur"], 0, 1)), r.h))
            self.text(a["label"], 18, (sw / 2, r.y - 4 * U), CREAM, "midbottom")
        if self.settings["fps"]:
            self.text("%d fps" % self.clock.get_fps(), 16, (sw - 10 * U, 10 * U), CREAM, "topright")

    def draw_dialog(self):
        sw, sh = self.screen.get_size()
        U = self.U
        d = self.dialog
        key, who, text, worried = self.parse_line(d["lines"][d["i"]])
        bottom = sh - 20 * U
        x0, total = sw * .08, sw * .84
        pw = 132 * U if key else 0                                  # portrait panel, to the right
        box = (x0, bottom - 130 * U, total - (pw + 10 * U if key else 0), 130 * U)
        self.panel(box, (30, 22, 24, 255))
        lines = self.wrap(text, 24, box[2] - 40 * U)
        left, y = int(d["shown"]), box[1] + 14 * U
        for ln in lines:
            if left <= 0:
                break
            self.text(ln[:left], 24, (box[0] + 20 * U, y))
            left -= len(ln) + 1
            y += 26 * U
        typing = d["shown"] < len(text)
        if not typing:
            self.text(tr("E - continue"), 15, (box[0] + box[2] - 14 * U, box[1] + box[3] - 10 * U), GOLD, "bottomright")
        if key:
            px, py, ph = x0 + total - pw, bottom - 152 * U, 152 * U
            self.panel((px, py, pw, ph), (30, 22, 24, 255), GOLD)
            size = int(108 * U)
            bob = int(math.sin(self.t * 16) * 2 * U) if typing else 0     # the face bobs while talking
            pic = self.portraits.get(key, worried, size)
            self.screen.blit(pic, (int(px + (pw - size) / 2), int(py + 8 * U + bob)))
            self.text(who, 17, (px + pw / 2, py + ph - 6 * U), GOLD, "midbottom")

    def draw_menu(self, title_screen):
        sw, sh = self.screen.get_size()
        U, m = self.U, self.menu
        n = len(m.items)
        long_menu = n > 8                      # the Settings list: use a compact header so it all fits
        self.mouse_rects = []
        if title_screen:
            self.draw_title_backdrop()
            if long_menu:
                self.text("COLD TIDE", 56, (sw / 2, sh * .075), GOLD, "center")
                top = sh * .205
            else:
                self.text("COLD TIDE", 96, (sw / 2, sh * .2), GOLD, "center")
                self.text(tr("21 days. One killer. The tide is coming in."), 24, (sw / 2, sh * .2 + 56 * U),
                          CREAM, "center")
                top = sh * .42
            if m.title:
                self.text(tr(m.title), 32 if long_menu else 40, (sw / 2, top - (26 if long_menu else 40) * U),
                          GOLD, "center")
        else:
            self.dim(170)
            top = sh * (.2 if long_menu else .3)
            self.text(tr(m.title), 44, (sw / 2, top - 50 * U), GOLD, "center")
        step = min(38 * U, (sh - 34 * U - top) / max(1, n))
        for i in range(n):
            sel = i == m.sel
            r = self.text(("> " if sel else "") + m.label(i) + (" <" if sel else ""), 30 if step >= 34 * U else 26,
                          (sw / 2, top + i * step), GOLD if sel else CREAM, "center")
            self.mouse_rects.append((r.inflate(int(60 * U), int(6 * U)), i))
        self.text(tr("Arrows / WASD + ENTER   ESC back   F11 fullscreen"), 16, (sw / 2, sh - 12 * U),
                  CREAM, "midbottom")

    def draw_title_backdrop(self):
        """The title screen shows the town at sunset, drifting slowly past (HD packs only)."""
        if self.pack.hd and self.scene == "town":
            fx = 31.0 + 15.0 * math.sin(self.t * 0.06)
            self.draw_world(focus=(fx, 19.2), minute=1105, title=True)
            self.present_canvas(cover=True)
            self.dim(120)
        else:
            self.screen.fill((20, 26, 38))

    def draw_card(self):
        sw, sh = self.screen.get_size()
        U = self.U
        self.screen.fill((14, 12, 20))
        self.text(self.card["title"], 70, (sw / 2, sh * .22), GOLD, "center")
        y = sh * .38
        for ln in self.card["lines"]:
            for w in self.wrap(ln, 26, sw * .7):
                self.text(w, 26, (sw / 2, y), CREAM, "center")
                y += 30 * U
            y += 8 * U
        self.text(tr("Press ENTER"), 20, (sw / 2, sh - 30 * U), GOLD, "midbottom")

    def npages(self):
        return 3 if self.c2_on else 2

    def clip(self, text, size, maxw):
        f = self.font(size * self.U)
        if f.size(text)[0] <= maxw:
            return text
        while text and f.size(text + "...")[0] > maxw:
            text = text[:-1]
        return text + "..."

    def draw_clue_columns(self, ids, case_of, x0, y0, colw, rows, row_h):
        """Evidence list: gold title, cream detail, in as many columns as needed."""
        U = self.U
        for i, cid in enumerate(ids[:rows * 2]):
            case = case_of(cid)
            txt = case.text(cid)
            if cid.startswith("door_"):
                txt += " " + self.case.print_result(cid[5:], self.collected)
            if cid.startswith("c2_print_"):
                txt += " " + self.case2.print_result(cid[9:], self.collected)
            cx, cy = x0 + (i // rows) * colw, y0 + (i % rows) * row_h * U
            self.text(self.clip(case.title(cid), 17, colw - 20 * U), 17, (cx, cy), GOLD)
            self.text(self.clip(txt, 15, colw - 20 * U), 15, (cx + 12 * U, cy + 18 * U))

    def draw_suspect_row(self, sid, name, pts, x, y, barw):
        U = self.U
        col = (190, 230, 190) if pts >= logic.ARREST_NEEDED else CREAM
        pic = self.portraits.get(sid, False, int(40 * U))
        if pic:
            self.screen.blit(pic, (int(x), int(y - 4 * U)))
        self.text("%s  -  %s" % (name, logic.job(sid)), 22, (x + 50 * U, y), col)
        bar = pygame.Rect(int(x + 50 * U), int(y + 24 * U), int(barw), int(10 * U))
        pygame.draw.rect(self.screen, INK, bar)
        pygame.draw.rect(self.screen, GOLD, pygame.Rect(bar.x, bar.y, int(bar.w * min(pts, 8) / 8.0), bar.h))
        self.text(tr("%d pts") % pts, 17, (bar.right + 10 * U, y + 18 * U), col)

    def draw_notebook(self):
        sw, sh = self.screen.get_size()
        U = self.U
        self.dim(190)
        r = (sw * .1, sh * .08, sw * .8, sh * .84)
        self.panel(r, (40, 30, 28, 245))
        names = [tr("Suspects"), tr("Evidence"), tr("Cafe case")]
        self.text(tr("NOTEBOOK  -  %s") % names[self.page], 36, (r[0] + 24 * U, r[1] + 16 * U), GOLD)
        self.text(tr("TAB switch page    N / ESC close"), 16, (r[0] + r[2] - 20 * U, r[1] + 24 * U), CREAM, "topright")
        y = r[1] + 70 * U
        sc = self.scores()
        if self.page == 0:
            for s in logic.SUSPECTS:
                self.draw_suspect_row(s["id"], s["name"], sc[s["id"]], r[0] + 24 * U, y, 150 * U)
                y += 44 * U
            self.text(tr("A suspect needs %d points before the chief will arrest them.") % logic.ARREST_NEEDED,
                      18, (r[0] + 24 * U, r[1] + r[3] - 36 * U), CREAM)
            self.draw_notebook_hint(r, logic.next_hint(self.case, self.collected, self.day, self.minute, self.jailed()))
        elif self.page == 1:
            shown = [c for c in sorted(self.collected) if c in self.case.clues and not self.case.clues[c].get("hidden")]
            if not shown:
                self.text(tr("No evidence yet. Start at the beach."), 22, (r[0] + 24 * U, y))
            self.draw_clue_columns(shown, lambda c: self.case, r[0] + 24 * U, y, (r[2] - 48 * U) / 2, 9, 40)
        else:
            sc2 = self.scores2()
            for i, sid in enumerate(case2.SUSPECTS2):
                self.draw_suspect_row(sid, self.case2.name(sid), sc2[sid],
                                      r[0] + 24 * U + (i % 2) * r[2] / 2, y + (i // 2) * 46 * U, 110 * U)
            if "c2_log" in self.collected:                       # the order book gets a full-width line
                self.text(self.clip(self.case2.text("c2_log"), 16, r[2] - 48 * U), 16, (r[0] + 24 * U, y + 90 * U), GOLD)
            ids = [c for c in sorted(self.collected) if c in self.case2.clues and c != "c2_log"]
            self.draw_clue_columns(ids, lambda c: self.case2, r[0] + 24 * U, y + 116 * U, (r[2] - 48 * U) / 2, 5, 34)
            self.draw_notebook_hint(r, self.case2.next_hint(self.collected) if not self.c2_done
                                    else tr("Solved: %s is in a cell at the police station.")
                                    % self.case2.name(self.case2.culprit))

    def draw_notebook_hint(self, r, hint):
        U = self.U
        y = r[1] + r[3] - 92 * U
        self.text(tr("Next step:"), 18, (r[0] + 24 * U, y), GOLD)
        for i, ln in enumerate(self.wrap(hint, 18, r[2] - 48 * U)[:2]):
            self.text(ln, 18, (r[0] + 24 * U, y + (20 + 20 * i) * U))

    def draw_win(self):
        sw, sh = self.screen.get_size()
        U = self.U
        self.screen.fill((16, 24, 30))
        k = logic.BY_ID[self.case.killer]
        self.text(tr("CASE CLOSED"), 84, (sw / 2, sh * .25), GOLD, "center")
        for i, s in enumerate([
                tr("%s, the %s, is led away in handcuffs.") % (k["name"], i18n.lower(logic.job(self.case.killer))),
                tr("The beach is quiet again. The buried victims will finally be named."),
                tr("Solved on day %d of %d with %d pieces of evidence.") % (self.day, logic.DAYS, len(self.collected))]
                + ([tr("The cafe murder was solved too: %s is behind bars.") % self.case2.name(self.case2.culprit)]
                   if self.c2_done else [])):
            self.text(s, 26, (sw / 2, sh * .42 + i * 36 * U), CREAM, "center")
        if self.end_t > 2:
            self.text(tr("Press ENTER"), 20, (sw / 2, sh - 30 * U), GOLD, "midbottom")

    def draw_bad_end(self):
        sw, sh = self.screen.get_size()
        U, t = self.U, self.end_t
        self.screen.fill((6, 4, 8))
        rw, rh = sw * .6, sh * .55
        rx, ry = (sw - rw) / 2, sh * .12
        pygame.draw.rect(self.screen, (58, 46, 58), pygame.Rect(int(rx), int(ry), int(rw), int(rh)))
        pygame.draw.rect(self.screen, (40, 30, 36), pygame.Rect(int(rx), int(ry + rh * .7), int(rw), int(rh * .3)))
        pygame.draw.rect(self.screen, (120, 70, 60), pygame.Rect(int(rx + rw * .08), int(ry + rh * .55), int(rw * .3), int(rh * .3)))
        pygame.draw.rect(self.screen, (20, 14, 18), pygame.Rect(int(rx + rw * .82), int(ry + rh * .3), int(rw * .12), int(rh * .6)))
        p = self.pack
        big = int(rh * .45)
        me = pygame.transform.scale(p.frame("player", 0, 0), (big * 2 // 3, big))
        self.screen.blit(me, (int(rx + rw * .45), int(ry + rh * .4)))
        if t > 7.5:
            sil = pygame.transform.scale(p.sil(logic.BY_ID[self.case.killer]["sheet"], 0, 0), (big * 2 // 3, big))
            self.screen.blit(sil, (int(rx + rw * .74), int(ry + rh * .36)))
        if t > 10.5:
            s = pygame.Surface((sw, sh), pygame.SRCALPHA)
            s.fill((0, 0, 0, int(255 * clamp((t - 10.5) / 2.0, 0, 1))))
            self.screen.blit(s, (0, 0))
        lines = [(1.0, tr("23:40  -  Room 12, Cold Tide Hotel.")), (4.0, tr("Floorboards creak in the hall.")),
                 (7.0, tr("The door opens. You never locked it.")), (11.5, tr("The lamp goes out.")),
                 (14.5, tr("You never found him."))]
        y = sh * .75
        for at, s in lines:
            if t >= at:
                self.text(s, 26, (sw / 2, y), CREAM, "center")
                y += 32 * U
        if t > 17:
            k = logic.BY_ID[self.case.killer]
            self.screen.fill((6, 4, 8))
            self.text(tr("YOU DIED"), 80, (sw / 2, sh * .3), (200, 60, 60), "center")
            self.text(tr("The killer was %s, the %s.") % (k["name"], i18n.lower(logic.job(self.case.killer))), 28,
                      (sw / 2, sh * .5), CREAM, "center")
            self.text(tr("Press ENTER"), 20, (sw / 2, sh - 30 * U), GOLD, "midbottom")

    def draw(self):
        self.screen = pygame.display.get_surface()
        self.U = max(0.6, self.screen.get_height() / 540.0)
        m = self.mode
        if m == "title":
            self.draw_menu(True)
        elif m == "card":
            self.draw_card()
        elif m == "win":
            self.draw_win()
        elif m == "bad_end":
            self.draw_bad_end()
        else:
            if self.scene == "town":
                self.draw_world()
            else:
                self.draw_interior()
            self.present_canvas()
            self.draw_vignette()
            self.draw_hud()
            if m == "dialog":
                self.draw_dialog()
            elif m == "menu":
                self.draw_menu(False)
            elif m == "notebook":
                self.draw_notebook()
        pygame.display.flip()

    def run(self):
        while self.running:
            dt = min(self.clock.tick(60) / 1000.0, 0.05)
            self.t += dt
            for e in pygame.event.get():
                self.handle(e)
            self.update(dt)
            self.draw()
        pygame.quit()


VERSION = "1.1 (HD art + Linux support)"


def selftest():
    """`python main.py --selftest`: checks the installation (window, sound, pictures, drawing) and exits.
    Without a display (e.g. over ssh) it uses SDL's invisible dummy video driver."""
    problems = []
    g = Game()
    print("Cold Tide %s" % VERSION)
    print("Python %s | pygame-ce %s | SDL %s" % (sys.version.split()[0], pygame.version.ver,
                                                   ".".join(map(str, pygame.get_sdl_version()))))
    print("video driver: %s | desktop %dx%d | window %dx%d" % ((pygame.display.get_driver(),) + tuple(g.desktop)
                                                              + tuple(g.screen.get_size())))
    print("sound: %s" % ("on (%s)" % (pygame.mixer.get_init(),) if g.audio.ok else "OFF - no usable audio device (the game still runs, silently)"))
    print("settings: %s" % SETTINGS_FILE)
    print("saves:    %s" % SAVE_FILE)
    for name in list_packs():
        try:
            g.load_pack(name)
            g.new_game(); g.mode, g.menu = "play", None
            for scene in ("town", "cafe", "police"):
                if g.scene != "town":
                    g.leave()
                if scene != "town":
                    g.enter(scene)
                g.update(0.016); g.draw()
            print("  texture pack %-8s ok" % name)
        except Exception as e:                      # report everything, not only the first problem
            problems.append("pack %s: %r" % (name, e))
    g.load_pack(g.settings["pack"])
    if problems:
        print("PROBLEMS:\n  " + "\n  ".join(problems))
        return 1
    print("SELFTEST OK")
    return 0


def main():
    if "--version" in sys.argv:
        print("Cold Tide " + VERSION)
        return
    if not (PACKS / "cozy" / "pack.json").exists():
        sys.exit("Textures missing. Run:  python make_assets.py")
    if "--selftest" in sys.argv:
        if sys.platform.startswith("linux") and not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
            os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
            os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
        sys.exit(selftest())
    Game().run()


if __name__ == "__main__":
    main()
