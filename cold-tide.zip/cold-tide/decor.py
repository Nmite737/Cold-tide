"""Town dressing for Cold Tide: streetlamps, benches, fences, signposts, beach props, ground decals.

Pure Python (no pygame) so it can be tested.  Everything here is cosmetic:
* `solid` props block movement, but only where the whole map stays connected
  (World checks every goal after adding them; a prop that would cut a route is dropped);
* `props` are drawn y-sorted with the people; `decals` are baked into the ground picture.
Positions are tile coordinates; sprites are anchored at the bottom centre of their tile.
Sprites come from the texture pack; a pack without them simply shows nothing extra.
"""
import random

import world as _w          # (world imports this module too: only attributes used inside functions)

# (sprite key, tile x, tile y, extra footprint tiles to the right)
SOLID = []
SOLID += [("prop_lamp", x, 19, 0) for x in (7, 15, 22, 31, 39, 46, 53, 60)]
SOLID += [("prop_lamp", x, 23, 0) for x in (4, 10, 21, 30, 37, 47, 58)]
SOLID += [("prop_bench", x, 24, 1) for x in (14, 26, 44)]
SOLID += [("prop_fence", x, 30, 0) for x in list(range(3, 19)) + list(range(41, 61))]
SOLID += [("prop_mailbox", 33, 18, 0), ("prop_mailbox", 40, 18, 0), ("prop_mailbox", 54, 18, 0)]
SOLID += [("prop_bin", 8, 18, 0), ("prop_bin", 21, 18, 0), ("prop_barrel", 30, 18, 0), ("prop_bin", 59, 18, 0)]
SOLID += [("prop_bush", 7, 17, 0), ("prop_bush2", 14, 17, 0), ("prop_bush", 21, 16, 0), ("prop_bush2", 38, 17, 0),
          ("prop_bush", 45, 17, 0), ("prop_bush2", 52, 17, 0), ("prop_bush", 59, 17, 0)]
SOLID += [("prop_signpost", 36, 24, 0), ("prop_signpost", 15, 13, 0)]
SOLID += [("prop_boat", 44, 36, 2), ("prop_parasol", 38, 35, 0), ("prop_parasol2", 52, 35, 0),
          ("prop_crates", 8, 35, 0), ("prop_lifebuoy", 26, 31, 0), ("prop_netpile", 50, 37, 0),
          ("prop_parasol", 15, 36, 0)]
# not blocking: low things you can walk over
PROPS = [("prop_driftwood", 12, 37), ("prop_driftwood", 56, 35), ("prop_flowerpot", 12, 18), ("prop_flowerpot", 14, 18),
         ("prop_flowerpot", 22, 18), ("prop_flowerpot", 31, 18)]
DECALS = [("decal_puddle", 5, 22), ("decal_puddle", 40, 20), ("decal_puddle", 52, 22), ("decal_puddle", 17, 21),
          ("decal_manhole", 26, 22), ("decal_manhole", 46, 20), ("decal_manhole", 8, 21),
          ("decal_pebbles", 12, 19), ("decal_pebbles", 29, 23), ("decal_pebbles", 49, 19), ("decal_pebbles", 5, 23),
          ("decal_stones", 36, 25), ("decal_stones", 20, 26)]


def protected():
    CRIME_SCENE, CCTV_POS, MOUND_SITES = _w.CRIME_SCENE, _w.CCTV_POS, _w.MOUND_SITES
    """Tiles that must stay free: clue spots and their neighbours."""
    keep = set()
    for (x, y) in list(MOUND_SITES) + [CRIME_SCENE, CCTV_POS]:
        for dx in range(-2, 3):
            for dy in range(-2, 3):
                keep.add((x + dx, y + dy))
    return keep


def footprint(item):
    key, x, y, extra = item
    return [(x + i, y) for i in range(extra + 1)]


def solid_candidates(world):
    """Solid props that fit on free, correct-terrain tiles (reachability is checked by World)."""
    MAP_W, MAP_H, shore_y = _w.MAP_W, _w.MAP_H, _w.shore_y
    keep, out = protected(), []
    for item in SOLID:
        key, x, y, extra = item
        tiles = footprint(item)
        if any(not (1 <= tx < MAP_W - 1 and 1 <= ty < MAP_H - 1) for tx, ty in tiles):
            continue
        if any((t in world.solid) or (t in keep) for t in tiles):
            continue
        if any(world.ground[ty][tx] in ("W", "R", "L", "X") for tx, ty in tiles):
            continue
        if key in ("prop_boat", "prop_parasol", "prop_parasol2", "prop_crates", "prop_netpile") and \
                any(world.ground[ty][tx] != "S" for tx, ty in tiles):
            continue
        if any(ty >= shore_y(tx) for tx, ty in tiles) and world.ground[tiles[0][1]][tiles[0][0]] == "S":
            continue
        out.append(item)
    return out


def free_props(world):
    keep = protected()
    return [(k, x, y) for (k, x, y) in PROPS
            if (x, y) not in world.solid and (x, y) not in keep and world.ground[y][x] in ("G", "S", "K")]


def decals(world):
    out = [(k, x, y) for (k, x, y) in DECALS if world.ground[y][x] != "W"]
    r = random.Random(77)                                  # fallen leaves under the woods and orchard
    for _ in range(60):
        x, y = r.randrange(1, 36), r.randrange(1, 13)
        if world.ground[y][x] == "G" and (x, y) not in world.solid:
            out.append(("decal_leaves", x, y))
    return out


def lamp_tiles(items):
    return [(x, y) for (k, x, y, e) in items if k == "prop_lamp"]
