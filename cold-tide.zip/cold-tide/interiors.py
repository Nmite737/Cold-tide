"""The inside of the police station and of Milo's Cafe. Pure Python (no pygame) so it can be tested.

An Interior is a small tile map: floor + walls, furniture ("items"), places the player can look at
("spots") and where people stand ("seats").  Things can depend on the state of the story through
"flags": a cond of "c2" means 'only after the cafe murder has happened', "no_c2" means 'only before'.
Edit the two build_* functions below to move furniture around; tests/interior_test.py checks that
every spot and seat can still be reached.
"""
from collections import deque

from i18n import N_


class Interior:
    def __init__(self, iid, theme, w, h, door_x):
        self.id, self.theme, self.w, self.h = iid, theme, w, h
        self.door = (door_x, h - 1)                    # walking onto this tile leaves the building
        self.spawn = (door_x + .5, h - 1.5)            # where you stand after coming in
        self.floor = [[None] * w for _ in range(h)]    # floor tile name per cell
        self.walls = [[None] * w for _ in range(h)]    # wall tile name per cell (drawn over the floor)
        self.base_solid = set()
        self.items, self.spots, self.seats = [], [], {}
        self.flags = frozenset()
        self.solid, self.items_now, self.spots_now = set(), [], []

    # ---- building the map
    def fill(self, name, x, y, w=1, h=1, wall=False, solid=False):
        for tx in range(x, x + w):
            for ty in range(y, y + h):
                (self.walls if wall else self.floor)[ty][tx] = name
                if solid:
                    self.base_solid.add((tx, ty))

    def add(self, sprite, x, y, w=1, h=1, solid=(), cond=None, flat=False, z=0.0):
        """A sprite w x h tiles with its top-left corner at tile (x, y).  `solid` lists the
        (x, y, w, h) rectangles nobody can walk through.  flat=True draws it on the floor."""
        self.items.append({"sprite": sprite, "x": x, "y": y, "w": w, "h": h, "solid": list(solid),
                           "cond": cond, "flat": flat, "z": z})

    def spot(self, sid, kind, x, y, label=None, cond=None):
        """Stand within a tile or two of (x, y).  kind: 'look' (press E) or 'print' (fingerprint kit)."""
        self.spots.append({"id": sid, "kind": kind, "pos": (x, y), "label": label, "cond": cond})

    # ---- story state
    def set_flags(self, flags):
        self.flags = frozenset(flags)
        ok = lambda cond: cond is None or cond in self.flags
        self.items_now = [i for i in self.items if ok(i["cond"])]
        self.spots_now = [s for s in self.spots if ok(s["cond"])]
        self.solid = set(self.base_solid)
        for it in self.items_now:
            for rx, ry, rw, rh in it["solid"]:
                for tx in range(rx, rx + rw):
                    for ty in range(ry, ry + rh):
                        self.solid.add((tx, ty))

    # ---- movement helpers (same idea as world.World)
    def is_solid(self, tx, ty):
        return (tx, ty) in self.solid or not (0 <= tx < self.w and 0 <= ty < self.h)

    def nearest_walkable(self, tile):
        if not self.is_solid(*tile):
            return tile
        for r in range(1, 5):
            for dx in range(-r, r + 1):
                for dy in range(-r, r + 1):
                    t = (tile[0] + dx, tile[1] + dy)
                    if not self.is_solid(*t):
                        return t
        return tile

    def path(self, start, goal):
        goal = self.nearest_walkable(goal)
        if start == goal:
            return []
        prev, q = {start: None}, deque([start])
        while q:
            cur = q.popleft()
            if cur == goal:
                break
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                n = (cur[0] + dx, cur[1] + dy)
                if n in prev or self.is_solid(*n):
                    continue
                prev[n] = cur
                q.append(n)
        if goal not in prev:
            return []
        out, cur = [], goal
        while cur != start:
            out.append(cur)
            cur = prev[cur]
        return out[::-1]

    def reachable(self, start=None):
        start = start or (int(self.spawn[0]), int(self.spawn[1]))
        seen, q = {start}, deque([start])
        while q:
            x, y = q.popleft()
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                n = (x + dx, y + dy)
                if n not in seen and not self.is_solid(*n):
                    seen.add(n)
                    q.append(n)
        return seen

    def seat(self, key, i=0):
        """Tile where a person stands (key = suspect id or 'prisoner'; unknown people get a free table)."""
        if key in self.seats:
            return self.seats[key]
        free = self.seats.get("free", [(5, 5)])
        return free[i % len(free)]


def _shell(iid, theme, w, h, door_x, floor_a, floor_b):
    """Floor everywhere, a two-row back wall, thick side and front walls and the front door."""
    it = Interior(iid, theme, w, h, door_x)
    for y in range(h):
        for x in range(w):
            it.floor[y][x] = floor_a if (x + y) % 2 == 0 else floor_b
    t = theme
    it.fill("i_fill_" + t, 0, 0, w, h, wall=True, solid=True)            # everything is wall ...
    it.fill("i_wall_" + t, 1, 0, w - 2, 1, wall=True, solid=True)         # ... except the back wall
    it.fill("i_wallb_" + t, 1, 1, w - 2, 1, wall=True, solid=True)
    for y in range(2, h - 1):                                             # ... and the floor area
        for x in range(1, w - 1):
            it.walls[y][x] = None
            it.base_solid.discard((x, y))
    it.walls[h - 1][door_x] = "i_door"                                    # the way out
    it.base_solid.discard(it.door)
    it.add("i_mat", door_x, h - 2, flat=True)
    return it


# ------------------------------------------------------------------ police station
def build_police():
    p = _shell("police", "p", 20, 13, 10, "i_floor_p1", "i_floor_p2")
    p.add("i_window", 6, 0, 2, 2, flat=True)
    p.add("i_board", 8, 0, 3, 2, flat=True)                  # suspect board (look at it: notebook)
    p.add("i_clock", 12, 0, flat=True)
    p.add("i_poster", 5, 1, flat=True)
    p.add("i_poster", 16, 1, flat=True)
    p.add("i_rug", 8, 6, 4, 2, flat=True)

    # jail cell, top left (the bars are drawn in front of whoever is inside)
    p.add("i_cell_back", 1, 2, 4, 3, flat=True)
    p.add("i_cell_bars", 1, 2, 4, 3, solid=[(1, 2, 4, 3)])
    # back wall furniture
    p.add("i_coffeem", 12, 1, 1, 2, solid=[(12, 2, 1, 1)])
    p.add("i_locker", 14, 1, 2, 2, solid=[(14, 2, 2, 1)])
    p.add("i_cabinet", 17, 1, 1, 2, solid=[(17, 2, 1, 1)])
    p.add("i_cabinet", 18, 1, 1, 2, solid=[(18, 2, 1, 1)])
    # chief's desk with a plant on each side so nobody walks round it
    p.add("i_desk3", 14, 5, 3, 1, solid=[(14, 5, 3, 1)])
    p.add("i_plant", 14, 3, 1, 2, solid=[(14, 4, 1, 1)])
    p.add("i_plant", 16, 3, 1, 2, solid=[(16, 4, 1, 1)])
    # front desk and waiting area
    p.add("i_desk2", 4, 8, 2, 1, solid=[(4, 8, 2, 1)])
    p.add("i_bench", 13, 9, 2, 1, solid=[(13, 9, 2, 1)])
    p.add("i_bench", 16, 9, 2, 1, solid=[(16, 9, 2, 1)])
    p.add("i_plant", 1, 9, 1, 2, solid=[(1, 10, 1, 1)])
    p.add("i_plant", 18, 9, 1, 2, solid=[(18, 10, 1, 1)])
    p.add("i_bin", 2, 10, solid=[(2, 10, 1, 1)])

    p.spot("board", "look", 9.5, 2.8, N_("Look at the suspect board"))
    p.spot("coffee", "look", 12.5, 3.4, N_("Pour a coffee"))
    p.spot("locker", "look", 14.3, 3.3, N_("Check the evidence locker"))
    p.spot("cabinets", "look", 17.9, 3.4, N_("Open the old case files"))
    p.seats = {"chief": (15, 4), "officer": (4, 7), "prisoner": (2, 3)}
    return p


# ------------------------------------------------------------------ Milo's cafe
def build_cafe():
    c = _shell("cafe", "c", 18, 12, 6, "i_floor_c1", "i_floor_c2")
    # the storeroom at the back right: its own floor and a divider wall with a doorway at (12, 5)
    c.fill("i_floor_s", 13, 2, 4, 5)
    c.fill("i_floor_s", 12, 5)
    c.fill("i_fill_c", 12, 2, 1, 5, wall=True, solid=True)
    c.walls[5][12] = None
    c.base_solid.discard((12, 5))
    c.fill("i_fill_c", 12, 7, 5, 1, wall=True, solid=True)

    # back wall of the main room
    c.add("i_menu", 5, 1, 2, 1, flat=True)
    c.add("i_window", 7, 0, 2, 2, flat=True)
    c.add("i_shelf_wall", 9, 1, 2, 1, flat=True)
    c.add("i_rug_c", 5, 8, 4, 2, flat=True)

    # kitchen corner
    c.add("i_kitchen_door", 2, 1, 1, 2, solid=[(2, 2, 1, 1)])
    c.add("i_stove", 3, 2, 2, 1, solid=[(3, 2, 2, 1)])
    # counter, with crates closing both ends so nobody walks behind it
    c.add("i_counter_l", 5, 3, solid=[(5, 3, 1, 1)])
    for x in (6, 7, 8, 9):
        c.add("i_counter_m", x, 3, solid=[(x, 3, 1, 1)])
    c.add("i_counter_r", 10, 3, solid=[(10, 3, 1, 1)])
    c.add("i_register", 7, 3, z=0.2)
    c.add("i_mug", 9, 3, z=0.2)
    c.add("i_book", 10, 3, z=0.2)
    c.add("i_crates", 5, 2, solid=[(5, 2, 1, 1)])
    c.add("i_crates", 11, 2, solid=[(11, 2, 1, 1)])
    c.add("i_crates", 11, 3, solid=[(11, 3, 1, 1)])

    # tables (Edith's is by the kitchen, Nora's desk in the corner)
    c.add("i_table", 3, 5, 2, 2, solid=[(3, 5, 2, 2)])
    c.add("i_teacup", 3, 5, z=1.1)
    c.add("i_table", 6, 6, 2, 2, solid=[(6, 6, 2, 2)])
    c.add("i_table", 9, 6, 2, 2, solid=[(9, 6, 2, 2)])
    c.add("i_table", 14, 8, 2, 2, solid=[(14, 8, 2, 2)])
    c.add("i_nora_desk", 1, 8, 2, 1, solid=[(1, 8, 2, 1)])
    c.add("i_jukebox", 11, 8, 1, 2, solid=[(11, 9, 1, 1)])
    c.add("i_plant", 1, 9, 1, 2, solid=[(1, 10, 1, 1)])
    c.add("i_plant", 16, 9, 1, 2, solid=[(16, 10, 1, 1)])

    # the storeroom: locked door before the murder, tape and clues after it
    c.add("i_door_closed", 12, 5, solid=[(12, 5, 1, 1)], cond="no_c2")
    c.add("i_tape_v", 12, 5, cond="c2")
    c.add("i_shelf", 15, 1, 2, 2, solid=[(15, 2, 2, 1)])
    c.add("i_ledger_desk", 13, 2, 2, 1, solid=[(13, 2, 2, 1)])
    c.add("i_clock", 14, 1, flat=True, cond="no_c2")
    c.add("i_clock_broken", 14, 1, flat=True, cond="c2")
    c.add("i_bin", 16, 4, solid=[(16, 4, 1, 1)])
    c.add("i_crates", 16, 6, solid=[(16, 6, 1, 1)])
    c.add("i_chalk", 14, 5, 2, 1, flat=True, cond="c2")
    c.add("i_cup", 13, 5, flat=True, cond="c2")

    c.spot("counter", "look", 7.5, 4.4, N_("Order a coffee"))
    c.spot("jukebox", "look", 11.5, 10.4, N_("Play the jukebox"))
    # clues of the cafe murder (only after it has happened)
    c.spot("c2_body", "look", 15.0, 5.9, N_("Examine the chalk outline"), "c2")
    c.spot("c2_clock", "look", 14.6, 3.4, N_("Examine the smashed clock"), "c2")
    c.spot("c2_ledger", "look", 13.4, 3.4, N_("Read Harold's ledger"), "c2")
    c.spot("c2_note", "look", 15.7, 4.7, N_("Search the wastebasket"), "c2")
    c.spot("c2_cup", "print", 13.5, 5.8, None, "c2")
    c.spot("c2_log", "look", 10.5, 4.4, N_("Read the order book"), "c2")
    c.spot("c2_print_grandma", "print", 3.8, 7.5, None, "c2")
    c.spot("c2_print_chef", "print", 2.5, 3.4, None, "c2")
    c.spot("c2_print_teacher", "print", 2.0, 9.5, None, "c2")
    c.spot("c2_print_barista", "print", 9.4, 4.4, None, "c2")

    c.seats = {"barista": (8, 2), "chef": (3, 3), "grandma": (2, 6), "teacher": (3, 8),
               "free": [(8, 5), (5, 5), (12, 8), (13, 10)]}
    return c


def build_all():
    out = {"police": build_police(), "cafe": build_cafe()}
    for it in out.values():
        it.set_flags({"no_c2", "no_c2_solved"})
    return out


# which building of the town each interior belongs to
BUILDING_OF = {"police": "police", "cafe": "cafe"}
