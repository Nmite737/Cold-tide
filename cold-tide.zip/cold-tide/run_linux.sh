#!/usr/bin/env bash
# Cold Tide - launcher for Linux.  Works from any folder, also through a symlink or a desktop entry:
#   ./run_linux.sh                 play
#   ./run_linux.sh --selftest      check the installation and exit
#   SDL_VIDEODRIVER=x11 ./run_linux.sh     force X11 / XWayland if a Wayland session misbehaves
#   SDL_AUDIODRIVER=alsa ./run_linux.sh    pick the audio driver (pulseaudio, pipewire, alsa)
HERE="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
cd "$HERE" || exit 1
PYBIN="$HERE/.venv/bin/python"

if [ ! -x "$PYBIN" ] || ! "$PYBIN" -c "import pygame" >/dev/null 2>&1; then
  echo "Cold Tide is not installed yet (or its .venv is damaged)."
  if [ -x "$HERE/install_linux.sh" ] || [ -f "$HERE/install_linux.sh" ]; then
    echo "Running the installer first..."
    bash "$HERE/install_linux.sh" || { echo "Installation failed - see the messages above."; exit 1; }
  else
    echo "Run ./install_linux.sh first."; exit 1
  fi
fi

# the venv's python is used directly, which is the same as activating it
export VIRTUAL_ENV="$HERE/.venv"
export PATH="$VIRTUAL_ENV/bin:$PATH"
exec "$PYBIN" "$HERE/main.py" "$@"
