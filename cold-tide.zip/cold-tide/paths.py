"""Where Cold Tide keeps its settings and save game.  Pure Python, no pygame.

Rules (first match wins):
1. $COLD_TIDE_HOME, if set, holds everything (handy for tests and portable installs);
2. an existing ~/.cold_tide folder (older versions, Windows/macOS/Linux) keeps being used, so no
   save game or setting is ever orphaned;
3. new installs on Linux / BSD follow the XDG standard:
       settings  ->  $XDG_CONFIG_HOME/cold-tide  (default ~/.config/cold-tide)
       saves     ->  $XDG_DATA_HOME/cold-tide    (default ~/.local/share/cold-tide)
4. new installs on Windows and macOS use ~/.cold_tide (as before).
If the home folder cannot be found (some containers), a folder in the temp directory is used.
"""
import json
import os
import sys
import tempfile
from pathlib import Path


def _home():
    try:
        return Path.home()
    except Exception:
        return Path(tempfile.gettempdir())


def _env_dir(name):
    v = os.environ.get(name, "")
    return Path(v) if v and os.path.isabs(v) else None


def data_dirs(environ=None, platform=None):
    """(config_dir, data_dir)."""
    env = os.environ if environ is None else environ
    plat = sys.platform if platform is None else platform
    override = env.get("COLD_TIDE_HOME")
    if override:
        p = Path(override)
        return p, p
    home = _home()
    legacy = home / ".cold_tide"
    if legacy.is_dir():
        return legacy, legacy
    if plat.startswith(("linux", "freebsd", "openbsd", "netbsd")):
        cfg = Path(env.get("XDG_CONFIG_HOME") or "") if os.path.isabs(env.get("XDG_CONFIG_HOME", "")) else home / ".config"
        dat = Path(env.get("XDG_DATA_HOME") or "") if os.path.isabs(env.get("XDG_DATA_HOME", "")) else home / ".local" / "share"
        return cfg / "cold-tide", dat / "cold-tide"
    return legacy, legacy


def write_text_atomic(path, text):
    """Write a file so that a crash or power cut never leaves a half-written save."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(tmp, str(path))
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return default
