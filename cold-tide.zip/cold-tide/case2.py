"""Case 2: the murder at Milo's Cafe.  No pygame in here, so it can be unit-tested.

On day 5 the owner of the cafe, Harold Finch, is found poisoned in his storeroom.  He died at 19:40
the evening before.  The four people who spend time in the cafe are the suspects: Edith, Lucia,
Nora and Milo.  One of them is the killer (never the killer of the beach case), one is a decoy who
looks just as guilty on paper.  What separates them:
  * the order book shows who was in the cafe at 19:40 (killer AND decoy),
  * Harold's ledger shows who owed him money (killer AND decoy),
  * a threatening note points at the decoy only (the trap: that makes 3 points),
  * the fingerprint on the poisoned cup matches the killer's own things,
  * the killer lies about when they left, and a second talk after the order book catches them.
Solving it fills the evidence locker at the police station with a lab report on the beach print.
"""
import random

import logic
from i18n import tr, N_, L

CASE2_DAY = 5
VICTIM2 = "Harold Finch"
DEATH = 19 * 60 + 40
SUSPECTS2 = ["grandma", "chef", "teacher", "barista"]


def hhmm(m):
    return "%02d:%02d" % (m // 60, m % 60)


CLAIM = {   # what each regular says; %s is the time they say they left
    "grandma": N_("I only stopped by for tea. I left at %s and Harold was alive and grumbling, as ever."),
    "chef": N_("I was cleaning the kitchen all evening. I went home at %s. Harold was alive when I left."),
    "teacher": N_("I was marking papers in the corner. I left at %s and I saw nothing, detective."),
    "barista": N_("I counted the till and locked up my station at %s. Poor Harold. A hard boss, but still."),
}
MOTIVE = {  # told when the killer is arrested
    "grandma": N_("Harold was about to sell the building. Edith has lived above the cafe for forty years."),
    "chef": N_("Harold meant to close the kitchen and let Lucia go. She had given that cafe her best years."),
    "teacher": N_("Nora had borrowed from Harold to mend the school roof. He wanted it back, loudly, in public."),
    "barista": N_("Milo had been skimming the till for a year. Harold found the books."),
}
JAILED = N_("I have nothing more to say. I am sorry about Harold.")
CONFRONT = N_("The order book has you here at 19:40. You said you left at %s.")
WORRIED = N_("...That book must be wrong. I need some air.")
OFFICER_TIPS = [
    N_("The storeroom at the cafe is sealed with tape, but it is open to you. Start with the cup."),
    N_("Harold died at the time the clock stopped. The order book at the counter shows who was there."),
    N_("Everybody has a favourite spot in the cafe. Fingerprints stick to teacups, mugs and door handles."),
    N_("Talk to the regulars twice. People tell the same lie the same way, until you show them the book."),
    N_("Don't arrest on a hunch, detective. A wrong arrest costs two days of paperwork."),
]


class Case2:
    def __init__(self, seed, exclude=None):
        rng = random.Random(seed * 7919 + 13)
        pool = [s for s in SUSPECTS2 if s != exclude]
        self.culprit = rng.choice(pool)
        self.decoy = rng.choice([s for s in SUSPECTS2 if s != self.culprit])
        nums = rng.sample(range(100, 999), len(SUSPECTS2))
        self.codes = {sid: "%s-%d" % (rng.choice("GHJKMN"), nums[i]) for i, sid in enumerate(SUSPECTS2)}
        self.times = {}                                    # sid -> (came in, left) the evening of the murder
        for sid in SUSPECTS2:
            if sid in (self.culprit, self.decoy):          # both are in the cafe at 19:40
                self.times[sid] = (rng.randrange(17 * 60 + 10, 19 * 60, 5), rng.randrange(19 * 60 + 50, 20 * 60 + 40, 5))
            elif rng.random() < .5:                        # gone long before
                self.times[sid] = (rng.randrange(16 * 60 + 30, 17 * 60 + 40, 5), rng.randrange(18 * 60 + 10, 19 * 60 + 15, 5))
            else:                                          # came after it happened
                self.times[sid] = (rng.randrange(20 * 60 + 5, 20 * 60 + 40, 5), rng.randrange(21 * 60, 21 * 60 + 40, 5))
        self.said = {sid: self.times[sid][1] for sid in SUSPECTS2}
        self.said[self.culprit] = rng.randrange(18 * 60 + 20, 19 * 60 + 20, 5)    # the lie
        self.clues = {}
        self._build()

    def name(self, sid):
        return logic.BY_ID[sid]["name"]

    def _build(self):
        cu, de = self.culprit, self.decoy
        cl = self.clues
        cl["c2_body"] = {"title": L("The victim: %s", VICTIM2),
                         "text": L("%s lay here. The cup beside him smells of bitter herbs: poison.", VICTIM2),
                         "points": {}, "requires": None}
        cl["c2_clock"] = {"title": L("Smashed wall clock"),
                          "text": L("The clock fell and stopped at %s. That is when Harold died.", hhmm(DEATH)),
                          "points": {}, "requires": None}
        cl["c2_cup"] = {"title": L("Print on the poisoned cup"),
                        "text": L("Print pattern %s on the cup. Compare it with the regulars' belongings.", self.codes[cu]),
                        "points": {}, "requires": None}
        entries = "; ".join("%s %s-%s" % (self.name(s).split()[0], hhmm(self.times[s][0]), hhmm(self.times[s][1]))
                            for s in SUSPECTS2)
        cl["c2_log"] = {"title": L("The order book"),
                        "text": L("Who was in the cafe last night (in-out): %s.", entries),
                        "points": {cu: 1, de: 1}, "requires": "c2_clock"}
        cl["c2_ledger"] = {"title": L("Harold's ledger"),
                           "text": L("%s and %s are listed as 'final warning, debts unpaid'.", self.name(cu), self.name(de)),
                           "points": {cu: 1, de: 1}, "requires": None}
        cl["c2_note"] = {"title": L("Crumpled note in the wastebasket"),
                         "text": L("'Pay up by Friday or the whole town hears.' Addressed to %s.", self.name(de)),
                         "points": {de: 1}, "requires": None}
        for sid in SUSPECTS2:
            cl["c2_print_" + sid] = {
                "title": L("Print on %s's things", self.name(sid)),
                "text": L("Pattern %s.", self.codes[sid]),
                "points": {sid: 2} if sid == cu else {}, "requires": "c2_cup"}
        cl["c2_lie"] = {"title": L("Caught in a lie: %s", self.name(cu)),
                        "text": L("%s said they left at %s. The order book says they stayed past 19:40.",
                                  self.name(cu), hhmm(self.said[cu])),
                        "points": {cu: 1}, "requires": "c2_log"}

    # ---- reading clues (same interface as logic.Case)
    def title(self, cid):
        return str(self.clues[cid]["title"])

    def text(self, cid):
        return str(self.clues[cid]["text"])

    def scores(self, collected):
        sc = {s: 0 for s in SUSPECTS2}
        for cid in collected:
            c = self.clues.get(cid)
            if not c or (c["requires"] and c["requires"] not in collected):
                continue
            for sid, p in c["points"].items():
                sc[sid] += p
        return sc

    def print_result(self, sid, collected):
        if "c2_cup" not in collected:
            return tr("Saved. Compare once you have the cup print.")
        return tr("MATCH with the cup print!") if sid == self.culprit else tr("No match with the cup print.")

    # ---- talking to the regulars
    def talk(self, sid, collected):
        """(dialogue lines, clue id to collect afterwards or None) for a talk with a cafe regular."""
        name = self.name(sid)
        lines = [name + ": " + tr(CLAIM[sid]) % hhmm(self.said[sid])]
        lie = None
        if sid == self.culprit and "c2_log" in collected and "c2_clock" in collected and "c2_lie" not in collected:
            lines.append(tr("Detective") + ": " + tr(CONFRONT) % hhmm(self.said[sid]))
            lines.append(name + ": " + tr(WORRIED))
            lie = "c2_lie"
        return lines, lie

    def confession(self, sid):
        """Lines for the card shown when the killer is arrested."""
        return [tr("%s breaks down in the interview room.") % self.name(sid),
                tr(MOTIVE[sid]),
                tr("The poisoned cup was meant to look like an accident. It did not.")]

    # ---- hints
    def next_hint(self, collected):
        sc = self.scores(collected)
        c = collected
        if max(sc.values()) >= logic.ARREST_NEEDED:
            return tr("Someone has enough evidence in the cafe case. Check the notebook [N], then ask the chief "
                      "for an arrest. A wrong arrest costs two days.")
        if "c2_cup" not in c:
            return tr("Try dusting the poisoned cup in the cafe storeroom. Kit [1], stand next to it, press SPACE.")
        if "c2_clock" not in c:
            return tr("Try the smashed clock in the storeroom: it gives the time of death. Press E next to it.")
        if "c2_log" not in c:
            return tr("Try the order book at the end of the cafe counter: who was here at that hour? Press E.")
        if "c2_ledger" not in c:
            return tr("Try the desk in the storeroom: Harold kept a ledger. Press E next to it.")
        todo = [s for s in SUSPECTS2 if "c2_print_" + s not in c]
        if todo:
            things = {"grandma": tr("Edith's teacup"), "chef": tr("Lucia's kitchen door"),
                      "teacher": tr("Nora's corner desk"), "barista": tr("Milo's mug")}
            return tr("Try running the prints: dust %s with the kit [1] and compare it with the cup print.") % things[todo[0]]
        if "c2_lie" not in c:
            return tr("Try talking to the regulars again and compare their stories with the order book.")
        return tr("Try the wastebasket in the storeroom and talk to the regulars once more.")
