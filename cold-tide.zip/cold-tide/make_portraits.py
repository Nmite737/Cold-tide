"""Builds the dialogue portraits in assets/portraits/ (Stardew Valley style faces).

Each portrait is the head and shoulders of the character's sprite, scaled up with hard pixels
and put on a coloured backdrop.  <name>.png is the normal face, <name>_worried.png has a sweat
drop (used when somebody gets nervous).

Run:  python make_portraits.py      (needs Pillow, and the 2x texture pack from make_assets.py)
To use your own drawn portraits just replace the PNGs (any square size, same file names).
"""
from pathlib import Path

from PIL import Image, ImageDraw

BASE = Path(__file__).resolve().parent
SRC = BASE / "assets" / "packs" / "cozy-2x"        # 32 px tiles, frame = 32 x 48
OUT = BASE / "assets" / "portraits"
T, TH = 32, 48
SCALE = 4
SIZE = 112                                         # final picture, in pixels

# portrait key -> (sprite sheet, backdrop colour)
PORTRAITS = {
    "player": ("player", (96, 140, 150)),
    "grandma": ("folk-grandma", (150, 120, 170)),
    "dogwalker": ("folk-dogwalker", (120, 150, 100)),
    "chef": ("work-chef", (190, 120, 100)),
    "teacher": ("school-teacher", (200, 160, 110)),
    "pumpkin": ("season-pumpkin", (224, 170, 90)),
    "barista": ("shop-barista", (150, 110, 90)),
    "chief": ("police-chief", (84, 104, 160)),
    "officer": ("police-officer", (96, 140, 190)),
}


def backdrop(col):
    """Soft vertical gradient with a thin border."""
    im = Image.new("RGBA", (SIZE, SIZE))
    d = ImageDraw.Draw(im)
    for y in range(SIZE):
        k = 0.78 + 0.35 * (1 - y / SIZE)
        d.line([0, y, SIZE, y], fill=tuple(min(255, int(v * k)) for v in col) + (255,))
    d.rectangle([0, 0, SIZE - 1, SIZE - 1], outline=(62, 42, 40, 255))
    d.rectangle([1, 1, SIZE - 2, SIZE - 2], outline=(255, 255, 255, 40))
    return im


def face(sheet):
    im = Image.open(SRC / (sheet + ".png")).convert("RGBA").crop((0, 0, T, TH))   # standing, facing down
    x0, y0, x1, y1 = im.getbbox()
    head = im.crop((x0, y0, x1, min(y1, y0 + 27)))      # head and shoulders
    return head.resize((head.width * SCALE, head.height * SCALE), Image.NEAREST)


def sweat(im):
    d = ImageDraw.Draw(im)
    x, y = SIZE - 24, 16
    d.polygon([(x, y), (x - 5, y + 9), (x + 5, y + 9)], fill=(150, 210, 240, 255), outline=(62, 42, 40, 255))
    d.ellipse([x - 5, y + 5, x + 5, y + 14], fill=(150, 210, 240, 255), outline=(62, 42, 40, 255))
    d.point([(x - 2, y + 9)], fill=(255, 255, 255, 255))
    return im


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for key, (sheet, col) in PORTRAITS.items():
        f = face(sheet)
        for mood in ("", "_worried"):
            bg = backdrop(col)
            bg.alpha_composite(f, ((SIZE - f.width) // 2, SIZE - f.height))
            if mood:
                bg = sweat(bg)
            bg.save(OUT / (key + mood + ".png"))
    print("Portraits written to", OUT)


if __name__ == "__main__":
    main()
