"""Native 32 px buildings for the HD pack (houses, police station, hotel, cafe).
Every building returns (image, lit_overlay, meta).  `meta` has window rectangles, the chimney
position and lamp positions in pixels, used by the game for night lighting and chimney smoke."""
import random

from PIL import Image, ImageDraw, ImageFont

from hd_draw import Cv, OL, T, mix, ramp, shadow_ellipse, noise_fill


def _font(size):
    try:
        return ImageFont.load_default(size)
    except Exception:
        return ImageFont.load_default()


def text(cv, x, y, s, col, size=11, shadow=None):
    """1-bit (no anti-aliasing) text stamped on a canvas."""
    tmp = Image.new("L", (cv.w, cv.h), 0)
    d = ImageDraw.Draw(tmp)
    d.fontmode = "1"
    f = _font(size)
    d.text((x, y), s, font=f, fill=255)
    px = tmp.load()
    for yy in range(cv.h):
        for xx in range(cv.w):
            if px[xx, yy] > 128:
                if shadow:
                    cv.put(xx + 1, yy + 1, shadow)
    for yy in range(cv.h):
        for xx in range(cv.w):
            if px[xx, yy] > 128:
                cv.put(xx, yy, col)
    bb = d.textbbox((x, y), s, font=f)
    return bb


def roof(cv, x0, x1, y0, y1, base, seed):
    rp = ramp(base, 5)
    r = random.Random(seed)
    row_h = 6
    for y in range(y0, y1):
        ry = (y - y0) // row_h
        off = 5 if ry % 2 else 0
        for x in range(x0, x1):
            sx = (x - x0 + off) % 10
            inrow = (y - y0) % row_h
            k = 2
            if inrow == 0:
                k = 3
            elif inrow >= row_h - 2:
                k = 1 if inrow == row_h - 2 else 0
            if sx == 0:
                k = 0
            elif sx == 1 and inrow < row_h - 2:
                k = 3 if k >= 2 else k
            if inrow >= row_h - 2 and 2 < sx < 7:
                k = max(0, k)
            cv.put(x, y, rp[k])
    for ry in range((y1 - y0) // row_h + 1):                  # per-shingle variation
        for sxi in range((x1 - x0) // 10 + 1):
            if r.random() < .22:
                bx = x0 + sxi * 10 + (5 if ry % 2 else 0)
                for yy in range(y0 + ry * row_h + 1, y0 + ry * row_h + row_h - 2):
                    for xx in range(bx + 2, bx + 9):
                        c = cv.get(xx, yy)
                        if c[3] and xx < x1 and yy < y1:
                            cv.put(xx, yy, mix(c, (255, 240, 200) if r.random() < .5 else (30, 20, 60), .12))
    for y in range(y0, y1):                                   # side bevels
        cv.put(x0, y, rp[4])
        cv.put(x0 + 1, y, rp[3])
        cv.put(x1 - 1, y, rp[0])
        cv.put(x1 - 2, y, rp[1])
    # ridge cap
    cv.rect(x0 - 1, y0 - 3, x1, y0 + 1, rp[3])
    cv.hline(x0 - 1, x1, y0 - 3, rp[4])
    cv.hline(x0 - 1, x1, y0 + 1, rp[0])
    for x in range(x0 + 3, x1 - 2, 7):
        cv.put(x, y0 - 1, rp[1])
    return rp


def siding(cv, x0, y0, x1, y1, base, vertical=False):
    wp = ramp(base, 5)
    for y in range(y0, y1):
        for x in range(x0, x1):
            k = 2
            if (y - y0) % 7 == 0:
                k = 3
            elif (y - y0) % 7 == 6:
                k = 1
            if (x * 11 + y * 5) % 23 == 0:
                k = max(0, k - 1)
            cv.put(x, y, wp[k])
    for y in range(y0, y1):                                   # left light / right shade
        cv.put(x0, y, wp[4])
        cv.put(x1 - 1, y, wp[0])
    return wp


def foundation(cv, x0, x1, y0, y1):
    st = ramp((140, 136, 150), 5)
    r = random.Random(5)
    for y in range(y0, y1):
        row = (y - y0) // 4
        for x in range(x0, x1):
            sx = (x - x0 + (6 if row % 2 else 0)) % 12
            k = 2
            if sx == 0 or (y - y0) % 4 == 3:
                k = 0
            elif (y - y0) % 4 == 0:
                k = 3
            elif r.random() < .08:
                k = 1
            cv.put(x, y, st[k])


def window(cv, x, y, w, h, trim, curtain, lit_list, box=None, shutters=None, sill=True, seed=0):
    tr = ramp(trim, 5)
    # shadow below lintel / frame
    cv.rect(x - 2, y - 2, x + w + 1, y + h + 1, tr[2])
    cv.frame(x - 2, y - 2, x + w + 1, y + h + 1, tr[1])
    cv.hline(x - 2, x + w + 1, y - 2, tr[4])
    cv.vline(x - 2, y - 2, y + h + 1, tr[3])
    for yy in range(h):                                       # glass: sky gradient
        c = mix((126, 178, 214), (190, 224, 236), yy / float(h))
        for xx in range(w):
            cv.put(x + xx, y + yy, c)
    # curtains
    cp = ramp(curtain, 5)
    for yy in range(h - 2):
        cw = 4 + (yy < 3) * 1
        for xx in range(cw):
            cv.put(x + xx, y + yy, cp[3 if (xx + yy // 3) % 2 else 2])
            cv.put(x + w - 1 - xx, y + yy, cp[2 if (xx + yy // 3) % 2 else 1])
    cv.hline(x, x + w - 1, y, cp[4])
    # mullion + reflection
    cv.vline(x + w // 2, y, y + h - 1, tr[3])
    cv.hline(x, x + w - 1, y + h // 2, tr[3])
    for i in range(min(w, h) // 2):
        cv.put(x + w - 4 - i, y + 2 + i, (240, 250, 255), 150)
    if shutters:
        sp = ramp(shutters, 5)
        for side in (-1, 1):
            sx = x - 2 - 6 if side < 0 else x + w + 2
            for yy in range(y - 2, y + h + 2):
                for xx in range(6):
                    c = sp[3] if xx == 0 else sp[1] if xx == 5 else sp[2]
                    if (yy - y) % 4 == 2 and 0 < xx < 5:
                        c = sp[0]
                    cv.put(sx + xx, yy, c)
    if sill:
        cv.rect(x - 3, y + h + 2, x + w + 2, y + h + 3, tr[4])
        cv.hline(x - 3, x + w + 2, y + h + 4, (60, 50, 70), 110)
    if box:
        bp = ramp((130, 86, 60), 5)
        cv.rect(x - 2, y + h + 3, x + w + 1, y + h + 8, bp[2])
        cv.hline(x - 2, x + w + 1, y + h + 3, bp[3])
        cv.hline(x - 2, x + w + 1, y + h + 8, bp[0])
        r = random.Random(seed)
        g = ramp((76, 140, 72), 5)
        for xx in range(x - 2, x + w + 2):
            cv.put(xx, y + h + 2 - r.randrange(2), g[r.choice((2, 3, 3, 4))])
            if r.random() < .5:
                cv.put(xx, y + h + 1, g[3])
        for xx in range(x - 1, x + w + 1, 3):
            c = r.choice(box)
            cv.put(xx, y + h, c)
            cv.put(xx + 1, y + h + 1, c)
            cv.put(xx, y + h + 1, mix(c, (255, 250, 220), .3))
    lit_list.append((x, y, w, h))


def door(cv, x, y, w, h, wood, trim, lit_list=None, knob=(240, 200, 80), glass=True):
    wp, tp = ramp(wood, 5), ramp(trim, 5)
    cv.rect(x - 3, y - 3, x + w + 2, y + h, tp[2])
    cv.hline(x - 3, x + w + 2, y - 3, tp[4])
    cv.vline(x - 3, y - 3, y + h, tp[3])
    cv.vline(x + w + 2, y - 3, y + h, tp[0])
    for yy in range(h):
        for xx in range(w):
            cv.put(x + xx, y + yy, wp[3] if xx < 2 else wp[1] if xx > w - 3 else wp[2])
    cv.vline(x + w // 2, y + 12, y + h - 1, wp[0])
    # recessed panels
    for (py, ph) in ((y + 14, 8), (y + h - 14, 10)):
        for xx in (x + 3, x + w // 2 + 2):
            cv.rect(xx, py, xx + w // 2 - 6, py + ph, wp[1])
            cv.hline(xx, xx + w // 2 - 6, py, wp[0])
            cv.vline(xx, py, py + ph, wp[0])
            cv.hline(xx, xx + w // 2 - 6, py + ph, wp[4])
    if glass:                                               # little window in the door
        cv.rect(x + 3, y + 3, x + w - 4, y + 10, (150, 196, 220))
        cv.rect(x + 3, y + 3, x + w - 4, y + 4, (206, 236, 244))
        cv.vline(x + w // 2, y + 3, y + 10, wp[0])
        cv.frame(x + 2, y + 2, x + w - 3, y + 11, wp[0])
        if lit_list is not None:
            lit_list.append((x + 3, y + 3, w - 6, 8))
    cv.put(x + w - 4, y + h // 2 + 2, knob)
    cv.put(x + w - 4, y + h // 2 + 3, mix(knob, (90, 60, 20), .5))
    cv.put(x + 1, y + 8, (60, 50, 60))
    cv.put(x + 1, y + h - 8, (60, 50, 60))


def step_and_mat(cv, cx, bottom, w=34):
    st = ramp((196, 190, 178), 5)
    cv.rect(cx - w // 2, bottom - 3, cx + w // 2, bottom, st[2])
    cv.hline(cx - w // 2, cx + w // 2, bottom - 3, st[4])
    cv.hline(cx - w // 2, cx + w // 2, bottom, st[0])
    cv.rect(cx - 9, bottom - 5, cx + 9, bottom - 4, (150, 60, 60))
    cv.hline(cx - 9, cx + 9, bottom - 5, (190, 90, 84))


def chimney(cv, x, y_top, y_bot):
    br = ramp((170, 96, 82), 5)
    r = random.Random(3)
    for y in range(y_top, y_bot):
        for x2 in range(x, x + 14):
            row = (y - y_top) // 4
            sx = (x2 - x + (3 if row % 2 else 0)) % 7
            k = 2
            if sx == 0 or (y - y_top) % 4 == 3:
                k = 0
            elif (y - y_top) % 4 == 0:
                k = 3
            elif r.random() < .08:
                k = 1
            if x2 > x + 10:
                k = max(0, k - 1)
            cv.put(x2, y, br[k])
    cv.rect(x - 2, y_top - 3, x + 15, y_top, (118, 112, 126))
    cv.hline(x - 2, x + 15, y_top - 3, (170, 164, 176))
    cv.rect(x + 2, y_top - 3, x + 11, y_top - 2, (30, 26, 36))


def lantern(cv, x, y, lit_lamps):
    cv.rect(x - 1, y - 4, x + 1, y - 3, (60, 66, 84))
    cv.rect(x - 2, y - 2, x + 2, y + 3, (60, 66, 84))
    cv.rect(x - 1, y - 1, x + 1, y + 2, (255, 226, 150))
    cv.put(x, y, (255, 250, 214))
    lit_lamps.append((x, y))


def vine(cv, x0, y0, y1, seed, side=1):
    r = random.Random(seed)
    g = ramp((74, 138, 70), 5)
    x = x0
    for y in range(y0, y1):
        if r.random() < .4:
            x += r.choice((-1, 1)) * side if r.random() < .5 else 0
        cv.put(x, y, g[1])
        if r.random() < .55:
            lx = x + r.choice((-2, -1, 1, 2))
            cv.put(lx, y, g[r.choice((2, 3, 3, 4))])
            cv.put(lx, y + 1, g[1])


def lit_image(w, h, rects, lamps):
    """Night overlay: window panes glow warm yellow and bleed light a little onto the wall."""
    cv = Cv(w, h)
    for (x, y, ww, hh) in rects:
        for yy in range(-4, hh + 4):
            for xx in range(-4, ww + 4):
                inside = 0 <= xx < ww and 0 <= yy < hh
                if inside:
                    c = mix((255, 232, 150), (255, 198, 96), yy / float(hh))
                    cv.put(x + xx, y + yy, c, 235)
                else:
                    d = max(-xx, xx - ww + 1, -yy, yy - hh + 1, 0)
                    cv.put(x + xx, y + yy, (255, 214, 120), max(0, 70 - d * 16))
    for (x, y) in lamps:
        for yy in range(-6, 7):
            for xx in range(-6, 7):
                d = (xx * xx + yy * yy) ** .5
                if d <= 6:
                    cv.put(x + xx, y + yy, (255, 224, 140), int(max(0, 120 - d * 20)))
    return cv.img()


# ------------------------------------------------------------------ houses
HOUSE_STYLES = [
    # wall, roof, trim, curtain, shutters, flower box colours, door wood
    dict(wall=(236, 224, 196), roof=(176, 98, 70), trim=(250, 244, 230), curtain=(210, 90, 90), shut=(96, 140, 110),
         box=[(236, 90, 110), (250, 220, 90)], door=(120, 80, 60), extra="vine"),
    dict(wall=(228, 190, 172), roof=(86, 108, 156), trim=(252, 246, 234), curtain=(240, 220, 150), shut=None,
         box=[(250, 250, 240), (170, 150, 240)], door=(90, 110, 150), extra="awning"),
    dict(wall=(188, 210, 230), roof=(150, 64, 58), trim=(250, 244, 230), curtain=(120, 160, 210), shut=(70, 90, 140),
         box=None, door=(150, 66, 60), extra="bike"),
    dict(wall=(210, 200, 170), roof=(78, 112, 84), trim=(240, 234, 216), curtain=(230, 140, 110), shut=(140, 90, 60),
         box=[(244, 150, 170), (250, 244, 230)], door=(96, 120, 90), extra="garden"),
    dict(wall=(240, 220, 150), roof=(112, 110, 128), trim=(252, 246, 234), curtain=(190, 110, 160), shut=None,
         box=[(240, 120, 70), (250, 210, 80)], door=(150, 90, 56), extra="barrel"),
    dict(wall=(200, 170, 200), roof=(98, 62, 52), trim=(240, 232, 218), curtain=(240, 200, 120), shut=(120, 74, 120),
         box=None, door=(110, 70, 54), extra="pumpkin"),
]


def house(idx, w=4, h=4):
    st = HOUSE_STYLES[idx - 1]
    W, H = w * T, h * T
    cv = Cv(W, H)
    wins, lamps = [], []
    eave = int(H * 0.44)
    wall_top = eave
    cx_door = (w // 2) * T + T // 2
    ch_x = W - 46
    chimney(cv, ch_x, 4, eave - 8)
    roof_rp = roof(cv, 3, W - 3, 12, eave, st["roof"], idx * 5)
    # roof attic window on some houses
    if idx in (1, 4, 6):
        ax = W // 2 - 11
        cv.rect(ax - 2, 20, ax + 22, 38, ramp(st["trim"], 5)[2])
        cv.frame(ax - 2, 20, ax + 22, 38, ramp(st["trim"], 5)[1])
        cv.rect(ax, 22, ax + 20, 36, (150, 196, 224))
        cv.vline(ax + 10, 22, 36, ramp(st["trim"], 5)[3])
        wins.append((ax, 22, 20, 14))
    # eave shadow
    cv.rect(3, eave, W - 4, eave + 3, ramp(st["roof"], 5)[0])
    cv.hline(3, W - 4, eave + 1, ramp(st["roof"], 5)[1])
    wp = siding(cv, 4, eave + 4, W - 4, H, st["wall"])
    for i, a in enumerate((120, 84, 52, 28, 12)):             # cast shadow under the eave
        cv.hline(5, W - 6, eave + 4 + i, (40, 30, 70), a)
    foundation(cv, 4, W - 4, H - 8, H)
    # corner boards
    tp = ramp(st["trim"], 5)
    for y in range(eave + 4, H - 8):
        cv.put(4, y, tp[4])
        cv.put(5, y, tp[3])
        cv.put(6, y, tp[2])
        cv.put(W - 5, y, tp[0])
        cv.put(W - 6, y, tp[1])
    dc = w // 2
    cols = [dc - 1, dc + 1] + ([0, w - 1] if w >= 6 else [])
    for ci, col in enumerate(cols):
        if 0 <= col < w:
            x0 = col * T + 6
            window(cv, x0, eave + 16, 20, 26, st["trim"], st["curtain"], wins,
                   box=st["box"], shutters=st["shut"], seed=idx * 10 + ci)
    door(cv, cx_door - 12, H - 8 - 42, 24, 42, st["door"], st["trim"], wins)
    step_and_mat(cv, cx_door, H - 1)
    lantern(cv, cx_door + 22, H - 8 - 30, lamps)
    cv.rect(cx_door - 28, H - 8 - 28, cx_door - 20, H - 8 - 22, (210, 180, 90))   # house number plate
    cv.frame(cx_door - 28, H - 8 - 28, cx_door - 20, H - 8 - 22, (110, 80, 40))
    cv.put(cx_door - 24, H - 8 - 25, (60, 40, 30))
    cv.put(cx_door - 24, H - 8 - 26, (60, 40, 30))
    cv.put(cx_door - 24, H - 8 - 24, (60, 40, 30))
    ex = st["extra"]
    if ex == "vine":
        vine(cv, 9, eave + 6, H - 10, idx)
        vine(cv, 14, eave + 20, H - 10, idx + 4)
    elif ex == "awning":
        aw = ramp((200, 70, 70), 5)
        for y in range(H - 62, H - 50):
            for x in range(cx_door - 22, cx_door + 22):
                k = 3 if ((x - cx_door + 22) // 7) % 2 == 0 else 4
                if y > H - 54:
                    k -= 1
                cv.put(x, y, aw[k] if k != 4 else (250, 244, 230))
        for x in range(cx_door - 22, cx_door + 22):
            cv.put(x, H - 50 + ((x // 3) % 2), aw[0] if ((x - cx_door + 22) // 7) % 2 == 0 else (200, 194, 184))
    elif ex == "bike":
        for (bx, by) in ((12, H - 12), (36, H - 12)):
            for a in range(0, 360, 20):
                import math
                cv.put(bx + 7 * math.cos(math.radians(a)), by + 7 * math.sin(math.radians(a)), (50, 54, 70))
        for i in range(24):
            cv.put(14 + i, H - 12 - (6 if 8 < i < 16 else 0), (190, 60, 60))
        cv.put(36, H - 22, (50, 54, 70))
        cv.put(35, H - 22, (50, 54, 70))
    elif ex == "garden":
        for gx in range(8, 40, 6):
            from hd_draw import blob
            blob(cv, gx, H - 12, 5, 4, ramp((84, 146, 76), 5), seed=gx)
            cv.put(gx, H - 15, (240, 110, 140))
    elif ex == "barrel":
        for bx in (10, 22):
            for y in range(H - 24, H - 8):
                for x in range(bx, bx + 10):
                    cv.put(x, y, (150, 100, 66) if x < bx + 6 else (112, 72, 50))
            cv.hline(bx, bx + 9, H - 20, (90, 96, 116))
            cv.hline(bx, bx + 9, H - 12, (90, 96, 116))
            cv.hline(bx, bx + 9, H - 24, (200, 150, 100))
    elif ex == "pumpkin":
        for px_, py_ in ((10, H - 14), (22, H - 12), (31, H - 15)):
            from hd_draw import blob
            blob(cv, px_, py_, 6, 5, ramp((226, 130, 40), 5), seed=px_)
            cv.put(px_, py_ - 5, (80, 120, 60))
    cv.outline(OL)
    meta = dict(windows=wins, chimney=(ch_x + 7, 2), lamps=lamps)
    return cv.img(), lit_image(W, H, wins, lamps), meta


# ------------------------------------------------------------------ police station
def police():
    w, h = 5, 5
    W, H = w * T, h * T
    cv = Cv(W, H)
    wins, lamps = [], []
    eave = int(H * 0.40)
    navy = (62, 84, 140)
    chimney_x = W - 40
    roof(cv, 3, W - 3, 20, eave, navy, 11)
    # flat parapet + flag
    for y in range(8, 22):
        cv.hline(8, W - 9, y, ramp((176, 188, 212), 5)[3 if y == 8 else 2 if y < 20 else 1])
    cv.hline(8, W - 9, 21, (60, 70, 100))
    for x in range(8, W - 8, 9):
        cv.vline(x, 9, 19, ramp((176, 188, 212), 5)[1])
    for y in range(0, 40):                                    # flag pole + flag
        cv.put(18, y, (210, 210, 220))
    for y in range(3, 14):
        for x in range(19, 36):
            wave = int(1.5 * ((x // 4) % 2))
            cv.put(x, y + wave, (52, 72, 140) if x < 33 else (232, 190, 70))
    for (fx, fy) in ((25, 8), (26, 7), (26, 8), (26, 9), (27, 8)):
        cv.put(fx, fy, (250, 224, 120))
    cv.rect(3, eave, W - 4, eave + 3, ramp(navy, 5)[0])
    wp = siding(cv, 4, eave + 4, W - 4, H, (196, 206, 224))
    for i, a in enumerate((120, 84, 52, 28, 12)):
        cv.hline(5, W - 6, eave + 4 + i, (40, 30, 70), a)
    foundation(cv, 4, W - 4, H - 8, H)
    tp = ramp((250, 244, 230), 5)
    for y in range(eave + 4, H - 8):
        cv.put(4, y, tp[4]); cv.put(5, y, tp[3]); cv.put(W - 5, y, tp[0]); cv.put(W - 6, y, tp[1])
    # sign board
    sw = 98
    sx = (W - sw) // 2
    sy = eave - 2
    cv.rect(sx - 2, sy, sx + sw + 2, sy + 18, (28, 40, 78))
    cv.rect(sx, sy + 2, sx + sw, sy + 16, navy)
    cv.hline(sx, sx + sw, sy + 2, (110, 134, 196))
    cv.frame(sx - 2, sy, sx + sw + 2, sy + 18, (210, 180, 90))
    text(cv, sx + 22, sy + 1, "POLICE", (250, 244, 230), 14, shadow=(20, 30, 60))
    # star badge left of sign
    import math
    for i in range(5):
        a = math.radians(-90 + i * 72)
        for t in range(0, 8):
            cv.put(sx + 8 + t * math.cos(a), sy + 9 + t * math.sin(a), (240, 200, 80))
    cv.rect(sx + 6, sy + 7, sx + 10, sy + 11, (255, 230, 120))
    cx_door = (w // 2) * T + T // 2
    for ci in (1, 3, 0, 4):
        x0 = ci * T + 5
        if ci in (0, 4):
            x0 = ci * T + 6
        window(cv, x0, eave + 24, 21, 28, (250, 244, 230), (110, 140, 200) if ci in (1, 3) else (150, 170, 210), wins,
               box=None, shutters=None, seed=ci)
    door(cv, cx_door - 14, H - 8 - 46, 28, 46, (62, 84, 140), (250, 244, 230), wins)
    # blue lamps either side of door (iconic police lamps)
    for sx2 in (cx_door - 34, cx_door + 34):
        cv.rect(sx2 - 2, H - 8 - 44, sx2 + 2, H - 8 - 38, (40, 90, 220))
        cv.rect(sx2 - 1, H - 8 - 43, sx2 + 1, H - 8 - 40, (120, 180, 255))
        cv.rect(sx2 - 3, H - 8 - 45, sx2 + 3, H - 8 - 45, (60, 66, 84))
        lamps.append((sx2, H - 8 - 41))
    # steps
    st = ramp((196, 190, 178), 5)
    for i, ww in enumerate((46, 38)):
        cv.rect(cx_door - ww // 2, H - 3 - i * 3, cx_door + ww // 2, H - 1 - i * 3, st[3 - i])
        cv.hline(cx_door - ww // 2, cx_door + ww // 2, H - 3 - i * 3, st[4])
    # noticeboard on the wall
    cv.rect(10, H - 8 - 36, 30, H - 8 - 18, (150, 100, 66))
    cv.rect(12, H - 8 - 34, 28, H - 8 - 20, (206, 170, 120))
    for (nx, ny, c) in ((14, 36, (250, 250, 240)), (21, 38, (250, 230, 150)), (16, 27, (240, 190, 190))):
        cv.rect(nx, H - 8 - ny + 2, nx + 5, H - 8 - ny + 8, c)
    cv.outline(OL)
    return cv.img(), lit_image(W, H, wins, lamps), dict(windows=wins, chimney=None, lamps=lamps)


# ------------------------------------------------------------------ hotel
def hotel():
    w, h = 6, 5
    W, H = w * T, h * T
    cv = Cv(W, H)
    wins, lamps = [], []
    eave = int(H * 0.40)
    red = (160, 56, 56)
    chimney(cv, 28, 4, eave - 10)
    chimney(cv, W - 50, 4, eave - 10)
    roof(cv, 3, W - 3, 12, eave, red, 21)
    cv.rect(3, eave, W - 4, eave + 3, ramp(red, 5)[0])
    siding(cv, 4, eave + 4, W - 4, H, (240, 214, 188))
    for i, a in enumerate((120, 84, 52, 28, 12)):
        cv.hline(5, W - 6, eave + 4 + i, (40, 30, 70), a)
    foundation(cv, 4, W - 4, H - 8, H)
    tp = ramp((252, 246, 234), 5)
    for y in range(eave + 4, H - 8):
        cv.put(4, y, tp[4]); cv.put(5, y, tp[3]); cv.put(W - 5, y, tp[0]); cv.put(W - 6, y, tp[1])
    # sign: gold-framed red banner
    sw = 88
    sx = (W - sw) // 2
    sy = eave - 3
    cv.rect(sx - 2, sy, sx + sw + 2, sy + 19, (110, 70, 30))
    cv.rect(sx, sy + 2, sx + sw, sy + 17, (120, 34, 40))
    cv.hline(sx, sx + sw, sy + 2, (190, 80, 84))
    cv.frame(sx - 2, sy, sx + sw + 2, sy + 19, (232, 190, 70))
    text(cv, sx + 22, sy + 1, "HOTEL", (252, 230, 150), 14, shadow=(60, 20, 30))
    cx_door = (w // 2) * T + T // 2
    for ci in (0, 1, 2, 4, 5):
        if ci == 2:
            continue
        window(cv, ci * T + 5, eave + 20, 21, 28, (252, 246, 234), (240, 220, 160) if ci % 2 else (230, 130, 120), wins,
               box=[(240, 100, 120), (250, 230, 120)] if ci in (1, 4) else None, shutters=(150, 56, 56) if ci in (0, 5) else None,
               seed=ci)
    # grand door with striped awning
    door(cv, cx_door - 15, H - 8 - 46, 30, 46, (110, 64, 50), (252, 246, 234), wins, glass=True)
    aw = ramp((200, 70, 70), 5)
    for y in range(H - 8 - 64, H - 8 - 52):
        for x in range(cx_door - 30, cx_door + 30):
            seg = ((x - cx_door + 30) // 8) % 2 == 0
            k = (3 if seg else 4) - (1 if y > H - 8 - 56 else 0)
            cv.put(x, y, aw[k] if seg else ((250, 244, 230) if y <= H - 8 - 56 else (206, 198, 186)))
    for x in range(cx_door - 30, cx_door + 30):
        cv.put(x, H - 8 - 52 + ((x // 4) % 2), aw[0] if ((x - cx_door + 30) // 8) % 2 == 0 else (190, 184, 174))
    lantern(cv, cx_door - 26, H - 8 - 40, lamps)
    lantern(cv, cx_door + 26, H - 8 - 40, lamps)
    st = ramp((196, 190, 178), 5)
    for i, ww in enumerate((62, 52)):
        cv.rect(cx_door - ww // 2, H - 3 - i * 3, cx_door + ww // 2, H - 1 - i * 3, st[3 - i])
        cv.hline(cx_door - ww // 2, cx_door + ww // 2, H - 3 - i * 3, st[4])
    cv.rect(cx_door - 12, H - 6, cx_door + 12, H - 5, (160, 50, 56))
    # window planters beside the door
    for bx in (10, W - 28):
        cv.rect(bx, H - 8 - 14, bx + 18, H - 8 - 6, (130, 86, 60))
        cv.hline(bx, bx + 18, H - 8 - 14, (176, 120, 84))
        g = ramp((76, 140, 72), 5)
        from hd_draw import blob
        blob(cv, bx + 9, H - 8 - 18, 10, 6, g, seed=bx)
        for fx in range(bx + 3, bx + 16, 4):
            cv.put(fx, H - 8 - 19, (244, 120, 150))
    cv.outline(OL)
    return cv.img(), lit_image(W, H, wins, lamps), dict(windows=wins, chimney=(35, 2), lamps=lamps)


# ------------------------------------------------------------------ cafe
def cafe():
    w, h = 5, 5
    W, H = w * T, h * T
    cv = Cv(W, H)
    wins, lamps = [], []
    eave = int(H * 0.36)
    brown = (136, 92, 68)
    chimney(cv, W - 44, 6, eave - 8)
    roof(cv, 3, W - 3, 14, eave, brown, 31)
    cv.rect(3, eave, W - 4, eave + 3, ramp(brown, 5)[0])
    siding(cv, 4, eave + 4, W - 4, H, (246, 226, 190))
    for i, a in enumerate((120, 84, 52, 28, 12)):
        cv.hline(5, W - 6, eave + 4 + i, (40, 30, 70), a)
    foundation(cv, 4, W - 4, H - 8, H)
    tp = ramp((252, 246, 234), 5)
    for y in range(eave + 4, H - 8):
        cv.put(4, y, tp[4]); cv.put(5, y, tp[3]); cv.put(W - 5, y, tp[0]); cv.put(W - 6, y, tp[1])
    # striped awning across the whole front
    aw = ramp((190, 62, 66), 5)
    ay0 = eave + 26
    for y in range(ay0, ay0 + 16):
        for x in range(6, W - 6):
            seg = ((x - 6) // 10) % 2 == 0
            k = 3 if seg else 4
            if y > ay0 + 11:
                k -= 1
            cv.put(x, y, aw[k] if seg else (250, 244, 230) if y <= ay0 + 11 else (210, 200, 190))
    for x in range(6, W - 6):
        sc = ((x - 6) // 10) % 2 == 0
        yy = ay0 + 16 + (1 if (x // 5) % 2 else 0)
        cv.put(x, yy, aw[0] if sc else (186, 178, 170))
        cv.put(x, yy + 1, (36, 30, 60), 70)
    # hanging sign
    sx = (W - 76) // 2
    cv.rect(sx, eave + 5, sx + 76, eave + 21, (96, 62, 44))
    cv.rect(sx + 2, eave + 7, sx + 74, eave + 19, (60, 40, 40))
    cv.frame(sx, eave + 5, sx + 76, eave + 21, (232, 190, 70))
    text(cv, sx + 20, eave + 5, "CAFE", (252, 228, 160), 14, shadow=(20, 12, 20))
    # cup icon
    cv.rect(sx + 7, eave + 10, sx + 15, eave + 16, (250, 244, 230))
    cv.rect(sx + 16, eave + 11, sx + 17, eave + 13, (250, 244, 230))
    cv.put(sx + 9, eave + 8, (200, 200, 210)); cv.put(sx + 12, eave + 7, (200, 200, 210))
    # big shop windows with warm interior
    cx_door = (w // 2) * T + T // 2
    for wx in (12, W - 12 - 38):
        cv.rect(wx - 2, eave + 46, wx + 40, H - 20, (96, 64, 48))
        for yy in range(eave + 48, H - 22):
            c = mix((255, 214, 150), (226, 160, 100), (yy - eave - 48) / 40.0)
            for xx in range(wx, wx + 38):
                cv.put(xx, yy, c)
        for xx in range(wx + 3, wx + 36, 12):             # shelves / cups seen through the glass
            cv.rect(xx, eave + 66, xx + 8, eave + 67, (130, 86, 60))
            cv.rect(xx + 1, eave + 61, xx + 3, eave + 65, (250, 244, 230))
            cv.rect(xx + 5, eave + 62, xx + 7, eave + 65, (214, 90, 80))
        cv.vline(wx + 19, eave + 48, H - 22, (96, 64, 48))
        for i in range(14):
            cv.put(wx + 26 - i // 2, eave + 50 + i, (255, 250, 230), 120)
        cv.rect(wx - 3, H - 20, wx + 41, H - 18, (200, 160, 120))
        wins.append((wx, eave + 48, 38, H - 22 - eave - 48))
    door(cv, cx_door - 13, H - 8 - 44, 26, 44, (120, 70, 50), (252, 246, 234), wins)
    # chalkboard A-frame by the door
    cv.rect(10, H - 8 - 22, 30, H - 10, (60, 44, 40))
    cv.rect(12, H - 8 - 20, 28, H - 12, (40, 50, 48))
    for ly in (-16, -12, -8):
        cv.hline(14, 20 + (ly % 5), H - 8 + ly, (230, 230, 220), 200)
    cv.put(24, H - 20, (250, 220, 100))
    # potted plants
    from hd_draw import blob
    for bx in (W - 24, W - 12):
        cv.rect(bx - 4, H - 8 - 10, bx + 4, H - 9, (190, 100, 70))
        blob(cv, bx, H - 8 - 16, 7, 7, ramp((76, 140, 72), 5), seed=bx)
    lantern(cv, cx_door + 24, H - 8 - 36, lamps)
    st = ramp((196, 190, 178), 5)
    cv.rect(cx_door - 22, H - 3, cx_door + 22, H - 1, st[3])
    cv.hline(cx_door - 22, cx_door + 22, H - 3, st[4])
    cv.outline(OL)
    return cv.img(), lit_image(W, H, wins, lamps), dict(windows=wins, chimney=(W - 37, 4), lamps=lamps)
