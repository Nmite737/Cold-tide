"""Sound for Cold Tide. Every sound is synthesised in code when the game starts,
so there are no audio files to ship and no extra dependencies (only pygame.mixer).

* "Simlish" voices: each character babbles made-up syllables (vowel formants) in their own
  pitch and speed, so every line of dialogue is "spoken" without real words, like in The Sims.
* Footsteps (grass / sand / pavement), digging, doors, bell, knock, tools, clues, UI, ending stings.
* Quiet sea ambience near the beach and a heartbeat when the stalker is close.

If the sound device cannot be opened the game just runs silently.
"""
import array
import math
import random
import zlib

import i18n

SR = 22050
TAU = 2 * math.pi


# --------------------------------------------------------------------------- synthesis helpers
def _clip(samples, gain=1.0):
    out = array.array("h")
    for s in samples:
        v = int(s * gain * 32767)
        out.append(32767 if v > 32767 else -32767 if v < -32767 else v)
    return out


def _normalise(samples, peak):
    m = max((abs(s) for s in samples), default=0.0) or 1.0
    k = peak / m
    return [s * k for s in samples]


def _noise(n, rng):
    return [rng.uniform(-1, 1) for _ in range(n)]


def _lowpass(x, k):
    y, out = 0.0, []
    for s in x:
        y += k * (s - y)
        out.append(y)
    return out


def _highpass(x, k):
    lp = _lowpass(x, k)
    return [a - b for a, b in zip(x, lp)]


def _decay(n, rate, attack=0.002):
    a = max(1, int(SR * attack))
    return [min(1.0, i / a) * math.exp(-rate * i / SR) for i in range(n)]


def _mix(*tracks):
    n = max(len(t) for t in tracks)
    out = [0.0] * n
    for t in tracks:
        for i, s in enumerate(t):
            out[i] += s
    return out


def _offset(track, secs):
    return [0.0] * int(SR * secs) + list(track)


def _tone(freq, dur, rate=6.0, shape=0.0, freq_end=None):
    n = int(SR * dur)
    out, ph = [], 0.0
    for i in range(n):
        f = freq if freq_end is None else freq + (freq_end - freq) * i / n
        ph += TAU * f / SR
        s = math.sin(ph) + shape * math.sin(2 * ph)
        out.append(s * math.exp(-rate * i / SR) * min(1.0, i / 60.0))
    return out


def _resonator(x, freq, bw):
    r = math.exp(-math.pi * bw / SR)
    b1, b2, a = 2 * r * math.cos(TAU * freq / SR), -r * r, 1 - r
    y1 = y2 = 0.0
    out = []
    for s in x:
        y = a * s + b1 * y1 + b2 * y2
        y2, y1 = y1, y
        out.append(y)
    return out


# --------------------------------------------------------------------------- effects
def make_step(surface, variant, rng):
    if surface == "grass":
        n = int(SR * 0.11)
        x = _lowpass(_noise(n, rng), 0.18 + 0.03 * variant)
        env = _decay(n, 38, 0.006)
        return _normalise([a * b for a, b in zip(x, env)], 0.55)
    if surface == "sand":
        n = int(SR * 0.16)
        x = _highpass(_lowpass(_noise(n, rng), 0.5), 0.12)
        env = [e * (0.6 + 0.4 * rng.random()) for e in _decay(n, 22, 0.008)]
        return _normalise([a * b for a, b in zip(x, env)], 0.5)
    # hard ground (street / sidewalk): click plus a short low thump
    n = int(SR * 0.09)
    click = _highpass(_noise(n, rng), 0.35)
    click = [a * b for a, b in zip(click, _decay(n, 70, 0.0008))]
    thump = [t * 0.9 for t in _tone(150 - 12 * variant, 0.09, 45)]
    return _normalise(_mix(click, thump), 0.6)


def make_scoop(rng, thud=True):
    n = int(SR * 0.42)
    scrape = _highpass(_lowpass(_noise(n, rng), 0.35), 0.05)
    env = [math.sin(math.pi * i / n) ** 1.5 * (0.7 + 0.3 * math.sin(i / 90.0)) for i in range(n)]
    scrape = [a * b * 0.7 for a, b in zip(scrape, env)]
    tracks = [scrape]
    if thud:
        tracks.append(_offset([t * 0.9 for t in _tone(95, 0.18, 22, 0.4, 60)], 0.30))
        dn = int(SR * 0.25)
        dirt = _lowpass(_noise(dn, rng), 0.22)
        tracks.append(_offset([a * b * 0.5 for a, b in zip(dirt, _decay(dn, 14, 0.004))], 0.34))
    return _normalise(_mix(*tracks), 0.7)


def make_dig_long(rng):
    parts = []
    for k in range(3):
        parts.append(_offset(make_scoop(rng), 0.44 * k))
    return _normalise(_mix(*parts), 0.7)


def make_door_open(rng):
    # latch click, wooden creak, soft thud
    click = [t for t in _highpass(_noise(int(SR * 0.04), rng), 0.4)]
    click = [a * b for a, b in zip(click, _decay(len(click), 120, 0.0005))]
    n = int(SR * 0.45)
    creak, ph = [], 0.0
    for i in range(n):
        f = 210 + 90 * math.sin(i / SR * 9.0) + 160 * (i / n)
        ph += TAU * f / SR
        s = (math.sin(ph) + 0.6 * math.sin(2.01 * ph) + 0.4 * math.sin(3.02 * ph))
        creak.append(s * math.sin(math.pi * i / n) ** 1.3 * 0.35)
    creak = _lowpass(creak, 0.45)
    thud = [t * 0.8 for t in _tone(80, 0.2, 18, 0.3)]
    return _normalise(_mix(click, _offset(creak, 0.04), _offset(thud, 0.5)), 0.75)


def make_door_close(rng):
    n = int(SR * 0.2)
    wood = [t * 1.0 for t in _tone(95, 0.2, 20, 0.5, 70)]
    click = _highpass(_noise(n, rng), 0.35)
    click = [a * b * 0.6 for a, b in zip(click, _decay(n, 90, 0.0005))]
    return _normalise(_mix(wood, click, _offset(click, 0.07)), 0.7)


def make_knock(rng):
    parts = []
    for k in range(3):
        t = [x * 1.0 for x in _tone(170 - 10 * k, 0.1, 40, 0.8)]
        wood = _lowpass(_noise(len(t), rng), 0.3)
        parts.append(_offset(_mix(t, [w * 0.3 for w in wood]), 0.16 * k))
    return _normalise(_mix(*parts), 0.7)


def make_bell():
    out = _mix(_tone(1318, 0.9, 5.0), _offset(_tone(1760, 0.8, 5.5), 0.0), _tone(2637, 0.6, 9.0))
    out = [s * 0.5 for s in out]
    return _normalise(_mix(out, _offset([s * 0.7 for s in out], 0.18)), 0.6)


def make_brush(rng):
    n = int(SR * 0.7)
    x = _highpass(_lowpass(_noise(n, rng), 0.5), 0.1)
    env = [(0.5 + 0.5 * math.sin(i / SR * 22.0 * math.pi)) * math.sin(math.pi * i / n) for i in range(n)]
    return _normalise([a * b for a, b in zip(x, env)], 0.45)


def make_scan():
    a = _tone(880, 0.09, 12)
    b = _offset(_tone(1175, 0.09, 12), 0.1)
    c = _offset(_tone(1568, 0.16, 8), 0.2)
    return _normalise(_mix(a, b, c), 0.5)


def make_clue():
    return _normalise(_mix(_tone(660, 0.18, 9, 0.3), _offset(_tone(990, 0.35, 5, 0.3), 0.12)), 0.55)


def make_found():
    return _normalise(_mix(_tone(196, 0.5, 5, 0.6), _offset(_tone(185, 0.6, 4, 0.6), 0.2),
                           _tone(392, 0.3, 8)), 0.55)


def make_ui(freq):
    return _normalise(_tone(freq, 0.07, 30, 0.2), 0.4)


def make_hint():
    return _normalise(_mix(_tone(880, 0.12, 14), _offset(_tone(1175, 0.2, 9), 0.09)), 0.35)


def make_day_chime():
    notes = [523, 659, 784, 1047]
    return _normalise(_mix(*[_offset(_tone(f, 0.7, 4.5, 0.2), 0.16 * i) for i, f in enumerate(notes)]), 0.5)


def make_win():
    notes = [523, 659, 784, 659, 784, 1047]
    return _normalise(_mix(*[_offset(_tone(f, 0.5, 4, 0.3), 0.18 * i) for i, f in enumerate(notes)]), 0.55)


def make_wrong():
    return _normalise(_mix(_tone(220, 0.35, 5, 0.5), _offset(_tone(165, 0.6, 4, 0.5), 0.3)), 0.55)


def make_doom():
    return _normalise(_mix(_tone(55, 3.0, 0.9, 0.7), _tone(58, 3.0, 0.9, 0.7),
                           _offset(_tone(41, 3.0, 0.8, 0.9), 0.5)), 0.7)


def make_heartbeat():
    def beat(at):
        return _offset([t * 1.0 for t in _tone(62, 0.16, 20, 0.5, 45)], at)
    return _normalise(_mix(beat(0.0), [s * 0.7 for s in beat(0.2)]), 0.8)


def make_waves(rng):
    """3 second loop of sea noise, swelling twice, loops cleanly."""
    n = int(SR * 3.0)
    x = _lowpass(_noise(n, rng), 0.06)
    x = [a * (0.55 + 0.45 * math.sin(TAU * 2 * i / n - 1.2)) for i, a in enumerate(x)]
    return _normalise(x, 0.5)


# --------------------------------------------------------------------------- Simlish voices
VOWELS = [(730, 1090), (530, 1840), (270, 2290), (570, 840), (300, 870), (660, 1720), (400, 1600)]

# name before the ":" in a dialogue line  ->  voice. f0 in Hz, speed multiplier, breathiness
VOICES = {
    "Edith Marlowe": dict(f0=235, speed=0.85, vib=0.05, shift=1.05),
    "Rafe Dunmore": dict(f0=118, speed=1.15, vib=0.015, shift=0.92),
    "Lucia Bellini": dict(f0=205, speed=1.25, vib=0.03, shift=1.02),
    "Nora Whitlock": dict(f0=250, speed=1.0, vib=0.02, shift=1.1),
    "Gideon Hale": dict(f0=95, speed=0.8, vib=0.01, shift=0.85),
    "Milo Pierce": dict(f0=160, speed=1.1, vib=0.02, shift=0.98),
    "Milo's Cafe": dict(f0=160, speed=1.1, vib=0.02, shift=0.98),
    "Chief": dict(f0=105, speed=0.95, vib=0.012, shift=0.9),
    "Officer Dale": dict(f0=140, speed=1.2, vib=0.02, shift=0.95),
    "Detective": dict(f0=175, speed=1.05, vib=0.02, shift=1.0),
}


def make_voice(text, prof, seed):
    """Babble for one line of dialogue."""
    rng = random.Random(seed)
    words = text.split()
    cjk = any("\u2e80" <= ch <= "\u9fff" for ch in text)
    if cjk:                                      # Chinese has no spaces: babble in 2-character chunks
        flat = "".join(text.split())
        words = [flat[i:i + 2] for i in range(0, len(flat), 2)]
    if not words:
        return []
    question = text.rstrip().endswith(("?", "？"))
    shout = text.rstrip().endswith(("!", "！"))
    plan = []
    for w in words:
        syl = min(3, len(w)) if cjk else max(1, min(3, (len(w) + 2) // 4))   # 1 Chinese character = 1 syllable
        plan.append((syl, w[-1] in ",;:.!?，；：。！？、" and w[-1]))
    while sum(p[0] for p in plan) > 24:     # keep very long lines short
        plan = plan[: int(len(plan) * 0.85)]
    total = sum(p[0] for p in plan)
    out, done = [], 0
    base = prof["f0"] * (1.08 if shout else 1.0)
    for syl, punct in plan:
        for _ in range(syl):
            prog = done / max(1, total)
            contour = 1.0 - 0.18 * prog                       # statements fall...
            if question:
                contour = 0.92 + 0.28 * prog ** 2             # ...questions rise
            f0 = base * contour * rng.uniform(0.86, 1.2)
            f1, f2 = rng.choice(VOWELS)
            f1, f2 = f1 * prof["shift"], f2 * prof["shift"]
            dur = rng.uniform(0.085, 0.15) / prof["speed"]
            n = int(SR * dur)
            src, ph = [], rng.random()
            for i in range(n):
                f = f0 * (1 + prof["vib"] * math.sin(i / SR * TAU * 5.5))
                ph = (ph + f / SR) % 1.0
                src.append(2 * ph - 1)
            if rng.random() < 0.65:                          # consonant burst
                cn = int(SR * 0.02)
                burst = _highpass(_noise(cn, rng), 0.3 if rng.random() < 0.5 else 0.08)
                for i in range(cn):
                    src[i] += burst[i] * 2.2 * (1 - i / cn)
            a = _resonator(src, f1, 90)
            b = _resonator(src, f2, 130)
            att, rel = int(SR * 0.012), int(SR * 0.03)
            syll = []
            for i in range(n):
                env = min(1.0, i / att, (n - i) / rel)
                syll.append((a[i] + 0.55 * b[i]) * max(0.0, env) * (0.8 + 0.2 * math.sin(math.pi * i / n)))
            out.extend(syll)
            done += 1
        gap = 0.16 if punct else rng.uniform(0.035, 0.07) / prof["speed"]
        out.extend([0.0] * int(SR * gap))
    return _normalise(out, 0.6)


# --------------------------------------------------------------------------- the Audio class
# Sounds are synthesised at SR (22050) samples per second but have always been PLAYED at the
# mixer's default 44100 Hz stereo: pygame.init() opens the mixer first, so the later
# mixer.init(22050, ...) call of older versions was ignored.  That is how the game has always
# sounded, so it is kept on purpose (and now pinned, so it is the same on every platform).
# Set PLAYBACK_RATE = SR for the slower, deeper "as synthesised" sound.
PLAYBACK_RATE = 44100
PLAYBACK_CHANNELS = 2


def _open_mixer(pygame):
    """Open the sound device, trying hard before giving up (the game then just runs silent).

    * The format is pinned (allowedchanges=0) so SDL converts for the device itself; otherwise
      PulseAudio / PipeWire may reopen it with other settings and change pitch and speed.
    * Buffer sizes 1024, 512, 2048 are tried in turn: tiny buffers crackle on some Linux servers.
    * On Linux, if the automatic driver fails, the common SDL audio drivers are tried by name
      (unless the player already chose one with the SDL_AUDIODRIVER environment variable).
    """
    import os
    import sys
    mixer = pygame.mixer
    drivers = [None]
    if sys.platform.startswith("linux") and not os.environ.get("SDL_AUDIODRIVER"):
        drivers += ["pulseaudio", "pipewire", "alsa"]
    for drv in drivers:
        if drv:
            os.environ["SDL_AUDIODRIVER"] = drv
        for buf in (1024, 512, 2048):
            for kw in ({"allowedchanges": 0}, {}):
                try:
                    if mixer.get_init():
                        mixer.quit()
                    mixer.init(PLAYBACK_RATE, -16, PLAYBACK_CHANNELS, buf, **kw)
                    if mixer.get_init():
                        return mixer
                except Exception:
                    continue
        if drv:
            os.environ.pop("SDL_AUDIODRIVER", None)
    try:
        if mixer.get_init():
            mixer.quit()
    except Exception:
        pass
    return None


class Audio:
    def __init__(self, settings, pygame):
        self.pg = pygame
        self.settings = settings
        self.ok = False
        self.sounds = {}
        self.base = {}
        self.voice_cache = {}
        self.voice_ch = None
        self.ambient_ch = None
        self.step_i = 0
        self.beat_t = 0.0
        self.channels = 1
        mixer = _open_mixer(pygame)
        if mixer is None:
            self.ok = False
            return
        try:
            mixer.set_num_channels(16)
            init = mixer.get_init()
            self.channels = init[2] if init else 1
            self.mixer = mixer
            self.ok = True
        except Exception:
            self.ok = False
            return
        try:
            self._build()
        except Exception:
            self.ok = False

    # ---- building
    def _sound(self, name, samples, vol=1.0):
        arr = _clip(samples)
        if self.channels == 2:
            st = array.array("h")
            for s in arr:
                st.append(s)
                st.append(s)
            arr = st
        snd = self.mixer.Sound(buffer=arr.tobytes())
        self.sounds[name] = snd
        self.base[name] = vol
        return snd

    def _build(self):
        rng = random.Random(7)
        for surf in ("grass", "sand", "hard"):
            for v in range(3):
                self._sound("step_%s_%d" % (surf, v), make_step(surf, v, rng), 0.5)
        self._sound("dig", make_dig_long(rng), 0.9)
        self._sound("dig_short", make_scoop(rng, thud=False), 0.8)
        self._sound("door_open", make_door_open(rng), 0.9)
        self._sound("door_close", make_door_close(rng), 0.8)
        self._sound("knock", make_knock(rng), 0.9)
        self._sound("bell", make_bell(), 0.7)
        self._sound("brush", make_brush(rng), 0.8)
        self._sound("scan", make_scan(), 0.7)
        self._sound("clue", make_clue(), 0.8)
        self._sound("found", make_found(), 0.9)
        self._sound("ui_move", make_ui(520), 0.6)
        self._sound("ui_select", make_ui(780), 0.7)
        self._sound("day", make_day_chime(), 0.8)
        self._sound("hint", make_hint(), 0.7)
        self._sound("win", make_win(), 0.9)
        self._sound("wrong", make_wrong(), 0.8)
        self._sound("doom", make_doom(), 1.0)
        self._sound("heart", make_heartbeat(), 0.9)
        self._sound("waves", make_waves(rng), 1.0)

    # ---- volume
    def master(self):
        if not self.settings.get("sound", True):
            return 0.0
        return max(0, min(10, int(self.settings.get("volume", 7)))) / 10.0

    def refresh_volume(self):
        """Call after the volume setting changed."""
        if not self.ok:
            return
        if self.master() == 0:
            self.stop_voice()
            if self.ambient_ch:
                self.ambient_ch.stop()
                self.ambient_ch = None

    # ---- playing
    def play(self, name, vol=1.0):
        if not self.ok or name not in self.sounds:
            return None
        m = self.master()
        if m <= 0:
            return None
        snd = self.sounds[name]
        snd.set_volume(min(1.0, self.base[name] * m * vol))
        try:
            return snd.play()
        except Exception:
            return None

    def step(self, surface):
        self.step_i += 1
        self.play("step_%s_%d" % (surface, self.step_i % 3), 0.9 + 0.2 * random.random())

    def say(self, line):
        """Play babble for a dialogue line like 'Edith Marlowe: Oh, a detective!'. Lines without a
        known speaker (narration, clue text) stay silent."""
        self.stop_voice()
        if not self.ok or self.master() <= 0 or ": " not in line:
            return
        who, text = line.split(": ", 1)
        who = who.strip()
        # a translated speaker ("Commissaire", "Polizeichef") speaks with the voice of the English name
        prof = VOICES.get(who) or VOICES.get(i18n.canonical(who))
        if not prof:
            return
        key = (who, text)
        snd = self.voice_cache.get(key)
        if snd is None:
            try:
                samples = make_voice(text, prof, zlib.crc32(("%s|%s" % key).encode()))
                arr = _clip(samples)
                if self.channels == 2:
                    st = array.array("h")
                    for s in arr:
                        st.append(s)
                        st.append(s)
                    arr = st
                snd = self.mixer.Sound(buffer=arr.tobytes())
            except Exception:
                return
            self.voice_cache[key] = snd
        snd.set_volume(min(1.0, 0.75 * self.master()))
        try:
            self.voice_ch = snd.play()
        except Exception:
            self.voice_ch = None

    def stop_voice(self):
        if self.voice_ch:
            try:
                self.voice_ch.stop()
            except Exception:
                pass
            self.voice_ch = None

    def ambient(self, level):
        """Sea noise. level 0..1 (0 = silent)."""
        if not self.ok:
            return
        level = level * self.master() * 0.35
        if level <= 0.001:
            if self.ambient_ch:
                self.ambient_ch.set_volume(0)
            return
        snd = self.sounds["waves"]
        if self.ambient_ch is None or not self.ambient_ch.get_busy():
            snd.set_volume(1.0)
            self.ambient_ch = snd.play(loops=-1)
        if self.ambient_ch:
            self.ambient_ch.set_volume(level)

    def heartbeat(self, dt, dist):
        """Call every frame while the stalker is on screen."""
        self.beat_t -= dt
        if self.beat_t <= 0:
            closeness = max(0.0, min(1.0, (11.0 - dist) / 9.0))
            self.play("heart", 0.3 + 0.7 * closeness)
            self.beat_t = 1.1 - 0.5 * closeness
