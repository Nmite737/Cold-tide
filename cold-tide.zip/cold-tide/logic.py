"""Game rules for Cold Tide: the case, clues, scoring, schedules, dialogue.
No pygame in here, so it can be unit-tested."""
import random

from i18n import tr, N_, L

DAYS = 21
STALK_DAY = 15
DAY_START = 8 * 60
DAY_END = 22 * 60
ARREST_NEEDED = 3

VICTIM = "Daniel Voss"
SUSPECTS = [
    {"id": "grandma", "sheet": "folk-grandma", "name": "Edith Marlowe", "job": N_("Retired seamstress")},
    {"id": "dogwalker", "sheet": "folk-dogwalker", "name": "Rafe Dunmore", "job": N_("Dog walker")},
    {"id": "chef", "sheet": "work-chef", "name": "Lucia Bellini", "job": N_("Chef")},
    {"id": "teacher", "sheet": "school-teacher", "name": "Nora Whitlock", "job": N_("Schoolteacher")},
    {"id": "pumpkin", "sheet": "season-pumpkin", "name": "Gideon Hale", "job": N_("Orchard keeper")},
    {"id": "barista", "sheet": "shop-barista", "name": "Milo Pierce", "job": N_("Barista")},
]
BY_ID = {s["id"]: s for s in SUSPECTS}

# people at the police station who are not suspects
STAFF = {
    "chief": {"id": "chief", "sheet": "police-chief", "name": "Chief"},
    "officer": {"id": "officer", "sheet": "police-officer", "name": "Officer Dale"},
}
# speaker name (English, as written before the colon in a dialogue line) -> portrait file in assets/portraits
PORTRAITS = {s["name"]: s["id"] for s in SUSPECTS}
PORTRAITS.update({"Chief": "chief", "Officer Dale": "officer", "Milo's Cafe": "barista",
                  "Detective": "player", "Detective's notes": "player"})

SCHEDULES = {  # (start minute, place)
    "grandma": [(480, "square"), (660, "beach"), (840, "home"), (1020, "cafe"), (1140, "home")],
    "dogwalker": [(480, "beach"), (660, "orchard"), (840, "square"), (1020, "beach"), (1140, "home")],
    "chef": [(480, "cafe"), (1020, "home"), (1140, "square")],
    "teacher": [(480, "square"), (900, "home"), (1080, "cafe")],
    "pumpkin": [(480, "orchard"), (1020, "square"), (1140, "orchard")],
    "barista": [(480, "cafe"), (1020, "beach"), (1140, "home")],
}


def place_for(sid, minute, killer_id, jailed=()):
    if sid in jailed:
        return "jail"                      # locked up for the cafe murder
    place = SCHEDULES[sid][0][1]
    for start, pl in SCHEDULES[sid]:
        if minute >= start:
            place = pl
    if sid == killer_id and minute >= 1200:
        place = "orchard"  # the killer is never home late at night
    return place


LINES = {
    "grandma": [N_("Oh, a detective! I walk the beach every morning, dear. Poor Daniel..."),
                N_("The tide comes in fast down there. Mind your shoes."),
                N_("I knit while I walk. Keeps the hands honest.")],
    "dogwalker": [N_("Dogs found him, you know. Not me. The dogs."),
                  N_("I cut through the orchard most days. The dogs love the smell of turned earth."),
                  N_("Nobody pays attention to the dog walker. I see everything.")],
    "chef": [N_("Daniel ate at my counter every Friday. Always the fish."),
             N_("Kitchens have sharp things. Doesn't make me a killer, detective."),
             N_("I close up late. I walk home alone. Everyone knows that.")],
    "teacher": [N_("The children are frightened. I'm trying to keep things normal."),
                N_("Daniel tutored for us once. Kind man. Careful with words."),
                N_("I mark papers at the cafe most evenings.")],
    "pumpkin": [N_("The orchard is mine and the woods are no one's. Dig where you like."),
                N_("Wear what you like, I say. Pumpkin costume is comfy."),
                N_("Strange noises at night in the trees. Not mine.")],
    "barista": [N_("Daniel? Black coffee, two sugars. I can't believe it."),
                N_("Everyone talks in here. Ask me anything."),
                N_("I like the beach after closing. Quiet.")],
}
NERVOUS = [N_("You ask a lot of questions, detective."),
           N_("I was alone that night. Is that a crime?"),
           N_("Shouldn't you be looking somewhere else?")]
LATE_NIGHT = N_("I saw someone heading for the orchard late last night. Couldn't tell who.")

CAFE_TIPS = [
    N_("Gossip: there's a camera on a pole by the beach. It might have caught something."),
    N_("Gossip: the beach print is partial. Compare it with prints from front doors. Use the kit [1]."),
    N_("Gossip: someone has been digging in the orchard woods. Look for fresh mounds. Bring a shovel [3]."),
    N_("Gossip: the face scanner [2] needs a reference image. Get the beach camera still first."),
    N_("Gossip: the killer is never home late at night. Watch the orchard after 20:00."),
    N_("Gossip: the chief needs 3 evidence points before anyone gets arrested."),
]

OFFICER_LINES = [
    N_("Welcome to the front desk, detective. The coffee machine is a crime scene in itself."),
    N_("The chief doesn't say much, but he reads every report twice. Bring him evidence, not theories."),
    N_("The suspect board is on the wall by the window. Six faces, one killer."),
    N_("Cells are empty most nights. Cold Tide is a quiet town. Usually."),
]

BODY_NAMES = ["Marta Quill", "Tom Hargreave", "Ines Okafor"]


class Case:
    def __init__(self, seed):
        self.seed = seed
        rng = random.Random(seed)
        ids = [s["id"] for s in SUSPECTS]
        self.killer = rng.choice(ids)
        self.decoy = rng.choice([i for i in ids if i != self.killer])
        self.sim = {}
        codes = rng.sample(range(100, 999), len(ids))
        self.codes = {}
        for i, sid in enumerate(ids):
            if sid == self.killer:
                self.sim[sid] = rng.randint(87, 96)
            elif sid == self.decoy:
                self.sim[sid] = rng.randint(66, 79)
            else:
                self.sim[sid] = rng.randint(18, 48)
            self.codes[sid] = "%s-%d" % (rng.choice("ABCDEF"), codes[i])
        self.body_sites = rng.sample(range(6), 3)
        links = [self.killer, self.killer, self.decoy]
        rng.shuffle(links)
        self.clues = {}
        self._build(links)

    def _build(self, links):
        k = BY_ID[self.killer]
        # titles and texts are L(...) objects: translated when read (see Case.title / Case.text)
        self.clues["beach_print"] = {
            "title": L("Partial print from the victim's bag"),
            "text": L("Print pattern %s lifted at the crime scene. Compare it with door prints.",
                      self.codes[self.killer]),
            "points": {}, "requires": None}
        self.clues["cctv"] = {
            "title": L("Beach camera still"),
            "text": L("A grainy still of a figure leaving the beach. Face scanner now has a reference."),
            "points": {}, "requires": None}
        for s in SUSPECTS:
            sid = s["id"]
            self.clues["door_" + sid] = {
                "title": L("Print on %s's door", s["name"]),
                "text": L("Pattern %s.", self.codes[sid]),
                "points": {sid: 2} if sid == self.killer else {}, "requires": "beach_print"}
            sim = self.sim[sid]
            self.clues["face_" + sid] = {
                "title": L("Face scan: %s", s["name"]),
                "text": L("%d%% similar to the beach still.", sim),
                "points": {sid: 2 if sim >= 85 else 1 if sim >= 60 else 0}, "requires": "cctv"}
        # the reward for solving the cafe murder: Officer Dale runs the beach print (see case2.py)
        self.clues["lab_report"] = {
            "title": L("Lab report: the beach print"),
            "text": L("Officer Dale ran print %s against the town records. Closest match: %s.",
                      self.codes[self.killer], k["name"]),
            "points": {self.killer: 1}, "requires": "beach_print"}
        self.clues["stalk_scan"] = {
            "title": L("Scan of the hooded stalker"),
            "text": L("Partial capture: %d%% similar to the beach still.", 88),
            "points": {self.killer: 2}, "requires": "cctv"}
        body_i = 0
        for site in range(6):
            cid = "dig_%d" % site
            if site in self.body_sites:
                victim = BODY_NAMES[body_i]
                link = links[body_i]
                body_i += 1
                self.clues[cid] = {
                    "title": L("Body: %s", victim),
                    "text": L("Belongings tie %s to %s.", victim, BY_ID[link]["name"]),
                    "points": {link: 1}, "requires": None}
            else:
                self.clues[cid] = {"title": L("Empty hole"), "text": L("Only roots and stones."),
                                   "points": {}, "requires": None, "hidden": True}

    def title(self, cid):
        return str(self.clues[cid]["title"])

    def text(self, cid):
        return str(self.clues[cid]["text"])

    def scores(self, collected):
        sc = {s["id"]: 0 for s in SUSPECTS}
        for cid in collected:
            c = self.clues.get(cid)               # cafe-case clues (c2_...) live in case2.py
            if c is None or (c["requires"] and c["requires"] not in collected):
                continue
            for sid, p in c["points"].items():
                sc[sid] += p
        return sc

    def print_result(self, sid, collected):
        if "beach_print" not in collected:
            return tr("Saved. Compare once you have the beach print.")
        return tr("MATCH with the beach print!") if sid == self.killer else tr("No match with the beach print.")


def dialogue(case, sid, day, minute, count):
    """Return a list of lines for one conversation."""
    name = BY_ID[sid]["name"]
    lines = [tr(LINES[sid][count % len(LINES[sid])])]
    if sid in (case.killer, case.decoy) and count >= 1:
        lines.append(tr(NERVOUS[count % len(NERVOUS)]))
    elif count >= 2 and minute < 1200:
        lines.append(tr(LATE_NIGHT))
    return [name + ": " + l for l in lines]


def stalker_params(day):
    """(keep distance in tiles, speed in tiles/sec) for the stalker."""
    n = max(0, day - STALK_DAY)
    return max(2.6, 8.0 - 1.0 * n), 2.4


PLACE_TEXT = {"jail": N_("in a cell at the police station"), "beach": N_("at the beach"), "square": N_("in the town square"), "cafe": N_("at the cafe"),
              "orchard": N_("in the orchard"), "home": N_("near their house")}


def job(sid):
    """Job title of a suspect in the current language."""
    return tr(BY_ID[sid]["job"])


def next_hint(case, collected, day=1, minute=DAY_START, jailed=()):
    """One short nudge about the most useful thing to do next, based on the evidence so far."""
    sc = case.scores(collected)
    if max(sc.values()) >= ARREST_NEEDED:
        return tr("Someone has enough evidence now. Check the notebook [N] to see who, "
                  "then go to the police station and request an arrest.")
    if "beach_print" not in collected:
        return tr("Try dusting the marker on the beach for prints. Kit [1], stand next to it, press SPACE.")
    if "cctv" not in collected:
        return tr("Try taking the still from the camera pole on the beach. Stand by it and press E.")
    dug = [c for c in collected if c.startswith("dig_")]
    bodies = [c for c in dug if case.clues[c].get("points")]
    undug = [i for i in range(6) if "dig_%d" % i not in collected]
    doors = [s for s in SUSPECTS if "door_" + s["id"] not in collected]
    unscanned = [s for s in SUSPECTS if "face_" + s["id"] not in collected]

    def dig_hint():
        return tr("Try digging in the forest: the orchard woods in the north-west. "
                  "Take the shovel [3] to the dirt mounds and press SPACE.")

    def print_hint():
        s = doors[0]
        return (tr("Try running the prints: dust %s's front door with the kit [1] and compare it "
                   "with the beach print.") % s["name"])

    if not dug and undug:
        return dig_hint()
    if doors:
        return print_hint()
    if len(bodies) < 3 and undug:
        return dig_hint()
    if unscanned:
        s = unscanned[0]
        where = tr(PLACE_TEXT[place_for(s["id"], minute, case.killer, jailed)])
        return (tr("Try the face scanner [2] on %s. Last seen %s. Get within a few tiles and press SPACE.")
                % (s["name"], where))
    if day >= STALK_DAY and "stalk_scan" not in collected:
        return tr("Try scanning the hooded stalker [2] when he gets close. He follows you after noon.")
    return tr("Try talking to people again or have a coffee at the cafe for gossip. "
              "Check the notebook [N] for your best lead.")
