"""Builds the HD texture pack (assets/packs/hd, 32 px tiles) and the HD portraits.

    python make_hd_art.py          (needs Pillow:  pip install pillow)

What is made here, and how:
* terrain, water, shore, trees, rocks, mounds, props, buildings, floors, walls, windows, rugs:
  drawn natively at 32 px by hd_draw.py / hd_buildings.py / hd_interior.py (no scaling at all);
* characters and furniture: the original 16 px art run through hd_enhance.py (Scale2x edge
  smoothing + thinner coloured outlines + form shading).  Same poses, same animations.
Pack `hd-noir` is the same art in black and white.
The 16 px packs (cozy, noir) and the stretched cozy-2x pack are left untouched.
"""
import json
import shutil
import sys
from pathlib import Path

from PIL import Image, ImageDraw

import hd_buildings as HB
import hd_draw as HD
import hd_enhance as HE
import hd_interior as HI

BASE = Path(__file__).resolve().parent
PACKS = BASE / "assets" / "packs"
COZY = PACKS / "cozy"
OUT = PACKS / "hd"
PORTRAITS = BASE / "assets" / "portraits"

SHEETS = ["player", "folk-grandma", "folk-dogwalker", "work-chef", "school-teacher",
          "season-pumpkin", "shop-barista", "police-chief", "police-officer"]
NATIVE_INTERIOR = {"i_floor_p1", "i_floor_p2", "i_floor_c1", "i_floor_c2", "i_floor_s", "i_wall_p", "i_wallb_p",
                   "i_fill_p", "i_wall_c", "i_wallb_c", "i_fill_c", "i_door", "i_mat", "i_window", "i_rug", "i_rug_c"}


def save(name, im):
    im.save(OUT / (name + ".png"))


def build():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    # ---- terrain
    for i in range(1, 4):
        save("grass%d" % i, HD.grass(i, 0 if i == 1 else 1 if i == 2 else 0))
    save("grass_dark", HD.grass(9, 0, dark=True, litter=True))
    save("grass_dark2", HD.grass(10, 0, dark=True))
    for i in range(1, 4):
        save("flowers%d" % i, HD.grass(20 + i, 5 + i))
    save("road", HD.asphalt(1))
    save("road2", HD.asphalt(2))
    save("road_n", HD.asphalt(3, edge="n"))
    save("road_s", HD.asphalt(5, edge="s"))
    save("road_line", HD.asphalt(4, line=True))
    save("crosswalk", HD.asphalt(6, cross=True))
    save("sidewalk", HD.sidewalk(1))
    save("sidewalk_n", HD.sidewalk(2, curb="s"))      # sidewalk north of the road: curb on its south edge
    save("sidewalk_s", HD.sidewalk(3, curb="n"))
    save("sand1", HD.sand(0))
    save("sand2", HD.sand(1))
    save("wet_sand", HD.wet_sand())
    save("grass_fringe", HD.grass_fringe())
    for d in ("shallow", "mid", "deep"):
        for f in range(4):
            save("water_%s%d" % (d, f), HD.water(d, f))
    save("water1", HD.water("mid", 0))
    save("water2", HD.water("mid", 2))
    for f in range(4):
        save("foam%d" % f, HD.foam(f))
    # ---- nature, evidence
    save("tree", HD.tree(0, 1))
    save("tree2", HD.tree(1, 2))
    save("tree3", HD.tree(2, 3))
    save("tree_apple", HD.tree(3, 5))
    save("rock", HD.rock(1))
    save("rock2", HD.rock(4, moss=False))
    save("mound", HD.mound())
    save("mound_dug", HD.mound(True))
    save("marker", HD.marker())
    save("tape", HD.tape())
    save("cctv", HD.cctv())
    for k in ("prints", "scan", "shovel"):
        save("icon_" + k, HD.icon(k))
    # ---- props
    for name, im in (("lamp", HD.lamp()), ("bench", HD.bench()), ("bush", HD.bush(3)), ("bush2", HD.bush(5, True)),
                     ("flowerpot", HD.flowerpot()), ("barrel", HD.barrel()), ("bin", HD.bin_()),
                     ("mailbox", HD.mailbox()), ("fence", HD.fence()), ("signpost", HD.signpost()),
                     ("boat", HD.boat()), ("parasol", HD.parasol()), ("parasol2", HD.parasol((70, 130, 200))),
                     ("crates", HD.crates()), ("driftwood", HD.driftwood()), ("lifebuoy", HD.lifebuoy()),
                     ("netpile", HD.net_pile())):
        save("prop_" + name, im)
    for name, im in HD.ground_decor().items():
        save("decal_" + name, im)
    shadow = Image.new("RGBA", (32, 14), (0, 0, 0, 0))
    cv = HD.Cv(32, 14)
    HD.shadow_ellipse(cv, 16, 7, 11, 4.5, 105)
    save("shadow_char", cv.img())
    # ---- buildings
    meta = {}
    for i in range(1, 7):
        im, lit, m = HB.house(i)
        save("house%d" % i, im)
        save("house%d_lit" % i, lit)
        meta["house%d" % i] = m
    for name, fn in (("police", HB.police), ("hotel", HB.hotel), ("cafe", HB.cafe)):
        im, lit, m = fn()
        save(name, im)
        save(name + "_lit", lit)
        meta[name] = m
    # ---- interiors: native pieces
    save("i_floor_p1", HI.floor_police(0))
    save("i_floor_p2", HI.floor_police(1))
    save("i_floor_c1", HI.floor_wood(0))
    save("i_floor_c2", HI.floor_wood(1))
    save("i_floor_s", HI.floor_store())
    for th in ("p", "c"):
        save("i_wall_" + th, HI.wall_tile(th, "top"))
        save("i_wallb_" + th, HI.wall_tile(th, "base"))
        save("i_fill_" + th, HI.wall_tile(th, "fill"))
        save("i_window" if th == "c" else "i_window_p", HI.window_big(th))
    save("i_door", HI.door_inner())
    save("i_mat", HI.mat())
    save("i_rug_c", HI.rug("c"))
    save("i_rug", HI.rug("p"))
    # ---- everything else: enhanced from the original art
    n_enh = 0
    for f in sorted(COZY.glob("i_*.png")):
        if f.stem in NATIVE_INTERIOR:
            continue
        save(f.stem, HE.enhance(Image.open(f), texture=0.05 if "desk" in f.stem or "table" in f.stem else 0.0))
        n_enh += 1
    for name in SHEETS:
        sheet = Image.open(COZY / (name + ".png")).convert("RGBA")
        save(name, HE.enhance_sheet(sheet, 16, 24))
    (OUT / "pack.json").write_text(json.dumps(
        {"name": "hd", "tile_size": 32, "hd": True, "buildings": meta}, indent=1), encoding="utf-8")
    print("hd pack: %d files (%d enhanced furniture pieces)" % (len(list(OUT.glob("*.png"))), n_enh))


def build_noir():
    dst = PACKS / "hd-noir"
    if dst.exists():
        shutil.rmtree(dst)
    dst.mkdir(parents=True)
    meta = json.loads((OUT / "pack.json").read_text(encoding="utf-8"))
    meta["name"] = "hd-noir"
    (dst / "pack.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")
    for f in OUT.glob("*.png"):
        im = Image.open(f).convert("RGBA")
        px = im.load()
        lit = f.stem.endswith("_lit")
        for y in range(im.height):
            for x in range(im.width):
                r, g, b, a = px[x, y]
                if a:
                    L = 0.3 * r + 0.59 * g + 0.11 * b
                    L = max(0, min(255, (L - 110) * 1.15 + 105)) if not lit else L
                    px[x, y] = (int(L), int(L * 0.97), int(L * 0.9), a)
        im.save(dst / f.name)


# ------------------------------------------------------------------ portraits
PORTRAIT_SPECS = {
    "player": ("player", (96, 140, 150)), "grandma": ("folk-grandma", (150, 120, 170)),
    "dogwalker": ("folk-dogwalker", (120, 150, 100)), "chef": ("work-chef", (190, 120, 100)),
    "teacher": ("school-teacher", (200, 160, 110)), "pumpkin": ("season-pumpkin", (224, 170, 90)),
    "barista": ("shop-barista", (150, 110, 90)), "chief": ("police-chief", (84, 104, 160)),
    "officer": ("police-officer", (96, 140, 190)),
}
PS = 128


def backdrop(col):
    im = Image.new("RGBA", (PS, PS))
    d = ImageDraw.Draw(im)
    for y in range(PS):
        k = 0.74 + 0.38 * (1 - y / PS)
        d.line([0, y, PS, y], fill=tuple(min(255, int(v * k)) for v in col) + (255,))
    for i in range(0, PS, 8):                      # subtle wallpaper diamonds
        for j in range(0, PS, 8):
            if (i // 8 + j // 8) % 2 == 0:
                d.point([(i + 3, j + 3)], fill=tuple(min(255, v + 14) for v in col) + (255,))
    d.rectangle([0, 0, PS - 1, PS - 1], outline=(62, 42, 40, 255))
    d.rectangle([1, 1, PS - 2, PS - 2], outline=(255, 255, 255, 46))
    return im


def sweat(im):
    d = ImageDraw.Draw(im)
    x, y = PS - 26, 14
    d.polygon([(x, y), (x - 6, y + 11), (x + 6, y + 11)], fill=(150, 210, 240, 255), outline=(62, 42, 40, 255))
    d.ellipse([x - 6, y + 6, x + 6, y + 17], fill=(150, 210, 240, 255), outline=(62, 42, 40, 255))
    d.point([(x - 2, y + 11), (x - 2, y + 12)], fill=(255, 255, 255, 255))
    return im


def build_portraits():
    PORTRAITS.mkdir(parents=True, exist_ok=True)
    for key, (sheet, col) in PORTRAIT_SPECS.items():
        fr = Image.open(OUT / (sheet + ".png")).convert("RGBA").crop((0, 0, 32, 48))
        x0, y0, x1, y1 = fr.getbbox()
        head = fr.crop((x0, y0, x1, min(y1, y0 + 27)))
        head = head.resize((head.width * 4, head.height * 4), Image.NEAREST)   # 4 px per art pixel (was 8)
        bg = backdrop(col)
        bg.alpha_composite(head, ((PS - head.width) // 2, 14))
        bg.save(PORTRAITS / (key + ".png"))
        sweat(bg.copy()).save(PORTRAITS / (key + "_worried.png"))


def main():
    if not COZY.exists():
        sys.exit("assets/packs/cozy is missing")
    build()
    build_noir()
    classic = BASE / "assets" / "portraits_classic"
    if not classic.exists():
        shutil.copytree(PORTRAITS, classic)
    build_portraits()
    print("done")


if __name__ == "__main__":
    main()
