"""Pixel-art detail enhancer (build-time only, needs Pillow).

Turns a 16 px-grid sprite into a 32 px-grid sprite WITHOUT blur and WITHOUT plain stretching:

1. Scale2x (AdvMAME2x) rounds the stair-steps of curves and diagonals using only colours that
   already exist in the sprite, so edges stay perfectly sharp.
2. The heavy 2 px outline that doubling creates is thinned back to 1 px; the inner half becomes a
   dark, hue-shifted version of the colour it touches ("selective outlining").
3. Each flat colour region gets form shading: a light top-left rim and a dark bottom-right rim,
   so shapes look modelled instead of cut out of paper.
4. Optional fabric / wood texture on big flat areas.

Used for the characters, portraits and the interior furniture.  Hand-drawn pieces (terrain,
buildings, trees, props) are made by make_hd_art.py directly at 32 px.
"""
from PIL import Image

OUTLINE = (62, 42, 40)


def _scale2x(px, w, h):
    out = [[(0, 0, 0, 0)] * (w * 2) for _ in range(h * 2)]
    for y in range(h):
        for x in range(w):
            p = px[x, y]
            a = px[x, y - 1] if y > 0 else p
            b = px[x + 1, y] if x < w - 1 else p
            c = px[x - 1, y] if x > 0 else p
            d = px[x, y + 1] if y < h - 1 else p
            e0 = a if (c == a and c != d and a != b) else p
            e1 = b if (a == b and a != c and b != d) else p
            e2 = c if (d == c and d != b and c != a) else p
            e3 = d if (b == d and b != a and d != c) else p
            out[2 * y][2 * x], out[2 * y][2 * x + 1] = e0, e1
            out[2 * y + 1][2 * x], out[2 * y + 1][2 * x + 1] = e2, e3
    return out


def _shade(rgb, k, warm=0.0):
    """Darken (k<1) toward blue/purple or lighten (k>1) toward warm yellow: hue-shifted ramps."""
    r, g, b = rgb[:3]
    if k < 1:
        t = 1 - k
        r, g, b = r * k - 6 * t * 10 * 0.2 + 4 * t * 4, g * k, b * k + 22 * t
    else:
        t = k - 1
        r, g, b = r * k + 18 * t, g * k + 12 * t, b * k - 6 * t
    return tuple(max(0, min(255, int(v))) for v in (r, g, b))


def enhance(img, outline=OUTLINE, rim=True, texture=0.0, seed=0):
    """img: PIL RGBA on a 16 px grid -> PIL RGBA at exactly double size."""
    img = img.convert("RGBA")
    w, h = img.size
    px = img.load()
    g = _scale2x(px, w, h)
    W, H = w * 2, h * 2

    def at(x, y):
        return g[y][x] if 0 <= x < W and 0 <= y < H else (0, 0, 0, 0)

    def clear(p):
        return p[3] < 128

    def is_ol(p):
        return p[3] >= 128 and p[:3] == outline

    out = [row[:] for row in g]
    # ---- 2. thin the outline: keep the pixel row/col touching the outside, tint the rest
    for y in range(H):
        for x in range(W):
            p = g[y][x]
            if not is_ol(p):
                continue
            nb = [at(x, y - 1), at(x, y + 1), at(x - 1, y), at(x + 1, y)]
            if any(clear(n) for n in nb):
                continue                                    # outer edge: stays dark
            fills = [n for n in nb if n[3] >= 128 and not is_ol(n)]
            ol_n = [n for n in nb if is_ol(n)]
            if fills and ol_n:
                # interior line two pixels thick: darkest fill neighbour gives the tint
                f = min(fills, key=lambda c: sum(c[:3]))
                out[y][x] = _shade(f, 0.52) + (255,)
    # ---- 3. rim light / shadow per region
    if rim:
        res = [row[:] for row in out]
        for y in range(H):
            for x in range(W):
                p = out[y][x]
                if p[3] < 128 or is_ol(p) or p[:3] == (0, 0, 0):
                    continue
                up, dn = at(x, y - 1), at(x, y + 1)
                lf, rt = at(x - 1, y), at(x + 1, y)
                diff = lambda n: clear(n) or is_ol(n) or n[:3] != p[:3]
                lum = 0.3 * p[0] + 0.59 * p[1] + 0.11 * p[2]
                if (diff(dn) or diff(rt)) and not (diff(up) and diff(lf)):
                    res[y][x] = _shade(p, 0.80) + (255,)
                elif (diff(up) or diff(lf)) and not (diff(dn) and diff(rt)) and lum < 235:
                    res[y][x] = _shade(p, 1.10) + (255,)
        out = res
    # ---- 4. texture
    if texture:
        for y in range(H):
            for x in range(W):
                p = out[y][x]
                if p[3] >= 128 and not is_ol(p) and (x * 7 + y * 13 + seed) % 5 == 0 and (x + y) % 2 == 0:
                    out[y][x] = _shade(p, 1 - texture) + (255,)
    im = Image.new("RGBA", (W, H))
    flat = [c for row in out for c in row]
    im.putdata(flat)
    return im


def enhance_sheet(sheet, fw, fh, **kw):
    """Enhance every frame of a sprite sheet separately (so rim light never leaks between frames)."""
    cols, rows = sheet.width // fw, sheet.height // fh
    out = Image.new("RGBA", (cols * fw * 2, rows * fh * 2), (0, 0, 0, 0))
    for r in range(rows):
        for c in range(cols):
            fr = sheet.crop((c * fw, r * fh, (c + 1) * fw, (r + 1) * fh))
            if fr.getbbox():
                out.paste(enhance(fr, **kw), (c * fw * 2, r * fh * 2))
    return out
