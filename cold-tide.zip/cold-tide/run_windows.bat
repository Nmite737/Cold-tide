@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Cold Tide

rem ---------------------------------------------------------------------------
rem  Cold Tide launcher for Windows 10 / 11.  Needs Python 3.9 or newer.
rem  First run: makes a private ".venv" folder and installs pygame-ce into it.
rem  Later runs start the game straight away.
rem ---------------------------------------------------------------------------

set "PY="
call :try "py -3"
if not defined PY if not defined PY call :try "python"
if not defined PY call :try "python3"
if not defined PY goto :nopython

rem a ".venv" made earlier with an older Python is thrown away and rebuilt
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
    if errorlevel 1 rmdir /s /q ".venv"
)

if not exist ".venv\Scripts\python.exe" (
    echo Setting up Cold Tide for the first time, please wait...
    %PY% -m venv .venv
    if errorlevel 1 goto :fail
)

set "VPY=.venv\Scripts\python.exe"

"%VPY%" -c "import pygame" >nul 2>&1
if errorlevel 1 (
    echo Installing pygame-ce ^(needs an internet connection, first run only^)...
    "%VPY%" -m pip install --disable-pip-version-check -r requirements.txt
    if errorlevel 1 goto :fail
)

"%VPY%" main.py
if errorlevel 1 goto :fail
exit /b 0

:try
if defined PY exit /b 0
%~1 -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
if not errorlevel 1 set "PY=%~1"
exit /b 0

:nopython
echo.
echo  Cold Tide needs Python 3.9 or newer, and it was not found on this PC.
echo.
echo  1. Download Python (3.12 or newer is a good choice) from  https://www.python.org/downloads/windows/
echo  2. In the installer tick "Add python.exe to PATH" and keep "py launcher" ticked.
echo     ^(or open a terminal and run:  winget install Python.Python.3.12^)
echo  3. Double-click run_windows.bat again.
echo.
pause
exit /b 1

:fail
echo.
echo  Something went wrong ^(see the messages above^).
echo  If the install step failed, check your internet connection and run this file again.
echo.
pause
exit /b 1
