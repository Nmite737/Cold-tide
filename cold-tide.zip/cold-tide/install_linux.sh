#!/usr/bin/env bash
# Cold Tide - installer for Linux (Ubuntu, Linux Mint, Debian, Fedora, Arch, ...).
#   ./install_linux.sh            install (or repair) into ./.venv
#   ./install_linux.sh --yes      do not ask before running `sudo apt install ...`
#   ./install_linux.sh --recreate throw the old .venv away and start clean
#   ./install_linux.sh --desktop  also add a "Cold Tide" entry to the application menu
# Safe to run again at any time.
set -u

HERE="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
cd "$HERE" || exit 1
VENV="$HERE/.venv"
MIN_MAJOR=3; MIN_MINOR=9
ASSUME_YES=0; RECREATE=0; DESKTOP=0
for a in "$@"; do
  case "$a" in
    -y|--yes) ASSUME_YES=1 ;;
    --recreate) RECREATE=1 ;;
    --desktop) DESKTOP=1 ;;
    -h|--help) sed -n '2,7p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Unknown option: $a (try --help)"; exit 2 ;;
  esac
done

if [ -t 1 ]; then B=$'\e[1m'; G=$'\e[32m'; Y=$'\e[33m'; R=$'\e[31m'; N=$'\e[0m'; else B=""; G=""; Y=""; R=""; N=""; fi
say()  { printf '%s\n' "${B}==>${N} $*"; }
ok()   { printf '%s\n' "${G} ok${N}  $*"; }
warn() { printf '%s\n' "${Y}warn${N} $*"; }
die()  { printf '%s\n' "${R}ERROR${N} $*" >&2; exit 1; }
trap 'die "The installer stopped unexpectedly (line $LINENO). Nothing outside this folder was changed. See README_LINUX.md > Troubleshooting."' ERR
set -E

[ "$(id -u)" -eq 0 ] && warn "You are running as root. A normal user account is recommended: the game and its .venv would belong to root."
[ "$(uname -s)" = "Linux" ] || warn "This script is meant for Linux (found $(uname -s)). On macOS use run_mac.command."

# ---------------------------------------------------------------- 1. Python
say "Looking for Python $MIN_MAJOR.$MIN_MINOR or newer"
PY=""
for c in python3.14 python3.13 python3.12 python3.11 python3.10 python3.9 python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c "import sys; sys.exit(0 if sys.version_info >= ($MIN_MAJOR, $MIN_MINOR) else 1)" 2>/dev/null; then PY="$(command -v "$c")"; break; fi
done
PKG=""
if   command -v apt-get >/dev/null 2>&1; then PKG=apt
elif command -v dnf     >/dev/null 2>&1; then PKG=dnf
elif command -v pacman  >/dev/null 2>&1; then PKG=pacman
elif command -v zypper  >/dev/null 2>&1; then PKG=zypper; fi

pkg_install() {   # pkg_install <apt names...>  (only apt is automated; others print the command)
  if [ "$PKG" = apt ]; then
    local sudo=""; [ "$(id -u)" -ne 0 ] && sudo="sudo"
    if [ "$ASSUME_YES" -eq 0 ]; then
      printf '%s' "Run '$sudo apt install $*' now? [Y/n] "; read -r ans || ans=n
      case "$ans" in n|N|no|NO) return 1 ;; esac
    fi
    $sudo apt-get update && $sudo apt-get install -y "$@"
  else
    return 1
  fi
}

if [ -z "$PY" ]; then
  warn "No Python $MIN_MAJOR.$MIN_MINOR+ found."
  case "$PKG" in
    apt)    pkg_install python3 python3-venv python3-pip || die "Please install it yourself:  sudo apt install python3 python3-venv python3-pip   then run this script again." ;;
    dnf)    die "Please run:  sudo dnf install python3 python3-pip   then run this script again." ;;
    pacman) die "Please run:  sudo pacman -S python python-pip   then run this script again." ;;
    zypper) die "Please run:  sudo zypper install python3 python3-pip   then run this script again." ;;
    *)      die "Install Python $MIN_MAJOR.$MIN_MINOR or newer (https://www.python.org/downloads/), then run this script again." ;;
  esac
  PY="$(command -v python3 || true)"
  [ -n "$PY" ] || die "Python still not found."
fi
ok "Python: $PY ($("$PY" -c 'import sys; print("%d.%d.%d" % sys.version_info[:3])'))"

# ---------------------------------------------------------------- 2. venv + pip support
say "Checking that Python can create virtual environments"
VTEST="$(mktemp -d)"
if ! "$PY" -m venv "$VTEST/t" >/dev/null 2>&1; then
  rm -rf "$VTEST"
  warn "The 'venv' module (or ensurepip) is missing - on Ubuntu / Linux Mint it is a separate package."
  case "$PKG" in
    apt) pkg_install python3-venv python3-pip || die "Please run:  sudo apt install python3-venv python3-pip   then run this script again." ;;
    dnf) die "Please run:  sudo dnf install python3-pip   then run this script again." ;;
    *)   die "Your Python cannot create virtual environments. Install its 'venv' / 'ensurepip' package, then run this script again." ;;
  esac
  VTEST="$(mktemp -d)"
  "$PY" -m venv "$VTEST/t" >/dev/null 2>&1 || { rm -rf "$VTEST"; die "Python still cannot create a virtual environment."; }
fi
rm -rf "$VTEST"
ok "venv works"

# ---------------------------------------------------------------- 3. the virtual environment
if [ "$RECREATE" -eq 1 ] && [ -d "$VENV" ]; then say "Removing the old .venv"; rm -rf "$VENV"; fi
if [ -x "$VENV/bin/python" ] && ! "$VENV/bin/python" -c "import sys; sys.exit(0 if sys.version_info >= ($MIN_MAJOR, $MIN_MINOR) else 1)" 2>/dev/null; then
  warn "The existing .venv is broken or too old; rebuilding it."; rm -rf "$VENV"
fi
if [ ! -x "$VENV/bin/python" ]; then
  say "Creating the virtual environment in $VENV"
  "$PY" -m venv "$VENV" || die "Could not create the virtual environment."
fi
ok "virtual environment ready"

say "Installing the game's Python packages (pygame-ce) - needs an internet connection"
"$VENV/bin/python" -m pip install --disable-pip-version-check --quiet --upgrade pip || warn "Could not upgrade pip (continuing)."
if ! "$VENV/bin/python" -m pip install --disable-pip-version-check --only-binary=:all: -r requirements.txt; then
  warn "No ready-made pygame-ce package for this system; retrying (this may compile it)."
  if ! "$VENV/bin/python" -m pip install --disable-pip-version-check -r requirements.txt; then
    printf '%s\n' "" "Could not install pygame-ce. Common causes:" \
      "  - no internet connection or a proxy: set HTTPS_PROXY and try again" \
      "  - a very new or unusual Python / CPU: install a Python between 3.9 and 3.14" \
      "  - pip had to compile pygame-ce:  sudo apt install build-essential python3-dev libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev libfreetype-dev libportmidi-dev" >&2
    die "pygame-ce installation failed."
  fi
fi
if ! "$VENV/bin/python" -c "import pygame" >/dev/null 2>&1; then
  warn "pygame-ce is listed as installed but cannot be imported (damaged files?); reinstalling it."
  "$VENV/bin/python" -m pip install --disable-pip-version-check --force-reinstall --no-cache-dir -r requirements.txt \
    || die "pygame-ce could not be repaired. Try:  ./install_linux.sh --recreate"
  "$VENV/bin/python" -c "import pygame" >/dev/null 2>&1 || die "pygame-ce still cannot be imported. Try:  ./install_linux.sh --recreate"
fi
ok "pygame-ce installed"

# ---------------------------------------------------------------- 4. verify
say "Testing the installation (opens no window if there is no display)"
if "$VENV/bin/python" main.py --selftest; then ok "Cold Tide works on this computer"; else
  die "The self-test failed - the messages above say why. See README_LINUX.md > Troubleshooting."
fi
if ! command -v pactl >/dev/null 2>&1 && ! command -v pipewire >/dev/null 2>&1 && [ ! -e /proc/asound/cards ]; then
  warn "No sound system detected. The game works but will be silent. On Ubuntu / Mint:  sudo apt install pulseaudio  (or pipewire-pulse)"
fi

# ---------------------------------------------------------------- 5. launchers
chmod +x "$HERE/run_linux.sh" "$HERE/install_linux.sh" 2>/dev/null || true
if [ "$DESKTOP" -eq 1 ]; then
  APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
  mkdir -p "$APPS"
  cat > "$APPS/cold-tide.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Cold Tide
Comment=A 2D pixel-art detective game
Exec="$HERE/run_linux.sh"
Path=$HERE
Icon=$HERE/assets/portraits/player.png
Terminal=false
Categories=Game;AdventureGame;
EOF
  ok "Added 'Cold Tide' to the application menu ($APPS/cold-tide.desktop)"
fi
printf '\n%s\n' "${G}${B}Done.${N} Start the game with:   ${B}./run_linux.sh${N}"
