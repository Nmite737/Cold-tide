"""Native 32 px floors, walls, window, rugs and door for the HD interiors."""
import random

from hd_draw import Cv, OL, T, mix, ramp, noise_fill


def floor_police(dark):
    cv = Cv(T, T, wrap=True)
    a, b = ramp((226, 224, 214), 5), ramp((196, 200, 206), 5)
    if dark:
        a, b = b, a
    r = random.Random(3 + dark)
    for qy in range(2):
        for qx in range(2):
            p = a if (qx + qy) % 2 == 0 else b
            for y in range(16):
                for x in range(16):
                    k = 2
                    if x == 0 or y == 0:
                        k = 3
                    elif x == 15 or y == 15:
                        k = 1
                    elif r.random() < .06:
                        k = 1 if r.random() < .5 else 3
                    cv.put(qx * 16 + x, qy * 16 + y, p[k])
    for i in range(10):                                        # glossy sheen
        cv.put(6 + i, 22 - i, (255, 255, 255), 90)
        cv.put(7 + i, 22 - i, (255, 255, 255), 50)
    return cv.img()


def floor_wood(alt):
    cv = Cv(T, T, wrap=True)
    wp = ramp((196, 146, 100) if not alt else (186, 136, 94), 5)
    r = random.Random(8 + alt)
    for row in range(4):
        y0 = row * 8
        off = (row * 13 + alt * 9) % 32
        base = r.choice((wp[2], wp[2], wp[2], wp[3]))
        for y in range(8):
            for x in range(T):
                k = base
                if y == 0:
                    k = wp[3]
                elif y == 7:
                    k = wp[1]
                elif (x * 7 + y * 3 + row * 5) % 17 == 0:
                    k = wp[1]
                cv.put(x, y0 + y, k)
        for x in (off, (off + 16) % 32):                       # plank end joints
            for y in range(8):
                cv.put(x, y0 + y, wp[1])
            cv.put(x + 1, y0 + 1, wp[3])
        cv.put((off + 5) % 32, y0 + 3, wp[0])                  # nail
        cv.put((off + 11) % 32, y0 + 4, wp[1])
    return cv.img()


def floor_store():
    cv = Cv(T, T, wrap=True)
    wp = ramp((140, 118, 100), 5)
    r = random.Random(22)
    for col in range(4):
        x0 = col * 8
        base = r.choice((wp[2], wp[1], wp[2]))
        for x in range(8):
            for y in range(T):
                k = base
                if x == 0:
                    k = wp[0]
                elif x == 1:
                    k = wp[3]
                elif (x + y * 5 + col) % 11 == 0:
                    k = wp[1]
                cv.put(x0 + x, y, k)
    for _ in range(4):
        cv.put(r.randrange(T), r.randrange(T), wp[0])
    return cv.img()


def wall_tile(theme, part):
    """part: 'top' (wall), 'base' (wallb), 'fill' (thick side/front walls)."""
    cv = Cv(T, T, wrap=True)
    if theme == "c":
        paper = ramp((240, 228, 196), 5)
        wood = ramp((150, 100, 64), 5)
        if part == "fill":
            for y in range(T):
                for x in range(T):
                    k = 2 if (y // 8) % 2 == 0 else 1
                    if y % 8 == 0:
                        k = 3
                    elif y % 8 == 7:
                        k = 0
                    cv.put(x, y, wood[k])
            cv.put(5, 4, wood[0]); cv.put(22, 21, wood[0])
            return cv.img()
        for y in range(T):
            for x in range(T):
                k = 2 if (x // 4) % 2 == 0 else 3
                if x % 4 == 0:
                    k = 1
                cv.put(x, y, paper[k])
        for (x, y) in ((6, 8), (22, 18), (14, 26), (28, 4)):   # tiny flowers on the paper
            cv.put(x, y, (214, 160, 150)); cv.put(x + 1, y, (214, 160, 150)); cv.put(x, y + 1, (170, 130, 110))
        if part == "top":
            cv.hline(0, T - 1, 0, wood[3]); cv.hline(0, T - 1, 1, wood[1]); cv.hline(0, T - 1, 2, (150, 130, 110), 90)
        else:
            for y in range(14, T):                              # wainscot
                for x in range(T):
                    k = 2
                    if y == 14:
                        k = 4
                    elif y == 15:
                        k = 1
                    elif x % 16 in (0, 15) or y == 22:
                        k = 0 if x % 16 == 15 or y == 22 else 3
                    cv.put(x, y, wood[k])
            cv.hline(0, T - 1, T - 1, wood[0])
            cv.hline(0, T - 1, T - 2, wood[1])
    else:
        plaster = ramp((204, 210, 224), 5)
        navy = ramp((62, 78, 120), 5)
        if part == "fill":
            for y in range(T):
                for x in range(T):
                    row = y // 8
                    sx = (x + (8 if row % 2 else 0)) % 16
                    k = 2
                    if y % 8 == 0:
                        k = 3
                    elif y % 8 == 7 or sx == 0:
                        k = 0
                    cv.put(x, y, navy[k])
            return cv.img()
        for y in range(T):
            for x in range(T):
                k = 2 if y % 9 else 1
                if (x * 3 + y * 7) % 31 == 0:
                    k = 3
                cv.put(x, y, plaster[k])
        if part == "top":
            cv.hline(0, T - 1, 0, navy[3]); cv.hline(0, T - 1, 1, navy[1]); cv.hline(0, T - 1, 2, (60, 60, 90), 80)
        else:
            for y in range(12, T):
                for x in range(T):
                    k = navy[2]
                    if y == 12:
                        k = (150, 176, 220)
                    elif y == 13:
                        k = navy[0]
                    elif y % 9 == 0 or x % 16 == 0:
                        k = navy[1]
                    cv.put(x, y, k)
            cv.hline(0, T - 1, T - 1, navy[0])
    return cv.img()


def door_inner():
    cv = Cv(T, T)
    wp = ramp((146, 96, 60), 5)
    cv.rect(4, 0, 27, T - 1, wp[1])
    cv.rect(6, 2, 25, T - 1, wp[2])
    cv.rect(9, 6, 22, 16, (150, 200, 226))
    cv.rect(9, 6, 22, 8, (206, 236, 244))
    cv.vline(15, 6, 16, wp[0]); cv.frame(8, 5, 23, 17, wp[0])
    cv.rect(9, 20, 22, 29, wp[3])
    cv.hline(9, 22, 20, wp[4]); cv.hline(9, 22, 29, wp[0])
    cv.put(22, 20, (240, 200, 80))
    cv.outline(OL)
    return cv.img()


def mat():
    cv = Cv(T, T)
    for y in range(8, 26):
        for x in range(4, 28):
            k = (x + y) % 2
            c = (146, 60, 60) if k else (172, 76, 70)
            if x in (4, 27) or y in (8, 25):
                c = (226, 200, 160)
            cv.put(x, y, c)
    for x in range(4, 28, 2):
        cv.put(x, 7, (226, 200, 160)); cv.put(x, 26, (226, 200, 160))
    return cv.img()


def window_big(theme):
    """64 x 64 window with curtains, sky and a sill."""
    cv = Cv(64, 64)
    fr = ramp((240, 232, 214) if theme == "c" else (236, 240, 248), 5)
    cv.rect(6, 4, 57, 52, fr[2])
    cv.frame(6, 4, 57, 52, fr[1])
    cv.hline(6, 57, 4, fr[4])
    for y in range(9, 49):
        c = mix((120, 176, 220), (214, 236, 242), (y - 9) / 40.0)
        for x in range(11, 53):
            cv.put(x, y, c)
    for (cx, cy, w) in ((20, 18, 8), (40, 28, 10)):            # clouds
        for dx in range(-w, w):
            for dy in (-1, 0, 1):
                if abs(dx) + abs(dy) * 4 < w:
                    cv.put(cx + dx, cy + dy, (250, 252, 255))
    cv.vline(31, 9, 48, fr[2]); cv.vline(32, 9, 48, fr[3]); cv.hline(11, 52, 28, fr[2])
    cur = ramp((196, 84, 84) if theme == "c" else (92, 120, 176), 5)
    for y in range(6, 50):
        for x in range(8, 17):
            cv.put(x, y, cur[3 if (x + y // 8) % 3 else 2] if x < 14 or y < 12 else cur[2 if x % 2 else 1])
        for x in range(47, 56):
            cv.put(x, y, cur[2 if (x + y // 8) % 3 else 1] if x > 49 or y < 12 else cur[1])
    cv.hline(7, 56, 6, cur[4])
    cv.rect(3, 52, 60, 56, fr[4])
    cv.hline(3, 60, 56, fr[0])
    cv.hline(5, 58, 57, (40, 30, 60), 80)
    for i in range(14):                                         # light on the sill
        cv.put(24 + i, 51, (255, 250, 200), 130)
    cv.outline(OL)
    return cv.img()


def rug(theme, w=128, h=64):
    cv = Cv(w, h)
    base = ramp((72, 120, 112) if theme == "c" else (120, 56, 64), 5)
    ac = ramp((226, 196, 120), 5)
    for y in range(h):
        for x in range(w):
            c = base[2]
            if x < 3 or y < 3 or x >= w - 3 or y >= h - 3:
                c = ac[3]
            elif x < 6 or y < 6 or x >= w - 6 or y >= h - 6:
                c = base[0]
            elif x < 8 or y < 8 or x >= w - 8 or y >= h - 8:
                c = ac[2]
            else:
                dx, dy = abs(x - w / 2.0), abs(y - h / 2.0)
                if abs(dx / 3.0 - dy) % 8 < 1.5 or (x + y) % 16 == 0:
                    c = base[3]
                if dx + dy * 2 < 18 and (int(dx) + int(dy)) % 6 < 2:
                    c = ac[2]
            cv.put(x, y, c)
    for x in range(0, w, 3):                                    # fringe
        cv.put(x, 0, ac[4]); cv.put(x, h - 1, ac[4])
    cv.outline(mix(base[0], OL, .6))
    return cv.img()
