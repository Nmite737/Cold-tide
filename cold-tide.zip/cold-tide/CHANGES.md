# Cold Tide - what changed (HD art + Linux support)

Game design, story, cases, dialogue, characters, inventory, investigation mechanics, sound, languages and save
format are **unchanged**. The old texture packs are still included and selectable.

## 1. Graphics (new default pack: `hd`, 32 px tiles)

Important finding: the old `cozy-2x` pack (and the 2x / 4x character sheets that ship in `source/`) are
byte-for-byte nearest-neighbour stretches of the 16 px art - 0 % of the pixels differ. They contain no extra detail.
So the HD art is genuinely redrawn or synthesised, never stretched or AI-upscaled:

* **Drawn natively at 32 px** (`hd_draw.py`, `hd_buildings.py`, `hd_interior.py`, assembled by `make_hd_art.py`):
  * ground: 3 grass variants, 3 flower meadows, darker woodland grass with leaf litter, asphalt with cracks and
    gutter shading, road line and crosswalk with wear, paving slabs with kerbs, sand with ripples/pebbles/shells,
    wet sand at the shore, a ragged grass-to-sand fringe;
  * water: 3 depths x 4 animation frames, sparkles and an animated breaking-wave foam line;
  * 4 tree kinds (oak, dark oak, pine, apple tree) with shaded crowns and soft ground shadows, mossy rocks,
    mounds, evidence marker, police tape, CCTV pole, tool icons;
  * every building: shingled roofs, siding, stone foundations, corner boards, curtained windows with glass
    reflections, shutters, flower boxes, panelled doors, lanterns, house numbers, climbing vines, awnings, bikes,
    barrels, pumpkins, a flag on the police station, gold-framed hotel sign, cafe with striped awning, shop windows
    and chalkboard. 6 houses, each different;
  * new environmental detail (`decor.py`): 15 streetlamps, benches, picket fences along the beach, mailboxes, bins,
    barrels, hedges and flower pots, signposts, a rowing boat, parasols, crates, lifebuoy, driftwood, puddles,
    manholes, pebbles, fallen leaves;
  * interiors: polished tile / wood plank / storeroom floors, wallpaper and panelled walls, brick shell, big
    curtained windows, rugs with patterns.
* **Enhanced from the original art** (`hd_enhance.py`) - characters, furniture, portraits: Scale2x edge smoothing
  (only existing colours, so edges stay razor sharp), thin hue-shifted selective outlines, form shading.
  Same poses, same 4 directions, same idle/walk frames, same identities. Portraits now use 4 px per art pixel
  instead of 8.
  *Honest limit:* characters and furniture keep their original designs - they are refined and consistent, not
  repainted from scratch.
* **Light and atmosphere**: five distinct times of day (cool morning, bright noon, golden afternoon, pink dusk,
  deep blue night); at night windows light up, streetlamps glow with light pools on the ground, fireflies appear;
  by day butterflies; chimney smoke; soft shadows under characters, buildings, furniture; vignette; sunlight
  (or moonlight) shafts through interior windows; the title screen shows the town at sunset.
* Packs: `hd` and `hd-noir` (black and white) added. `cozy`, `noir`, `cozy-2x` untouched.
  Settings from older versions are moved to `hd` once; after that your own choice sticks.

## 2. Linux / cross-platform

* **Python requirement lowered from 3.14 to 3.9** - tested, not assumed: the whole suite passes on 3.9, 3.10,
  3.11, 3.12, 3.13 and 3.14 (this covers Ubuntu 22.04 / 24.04 and Mint 21 / 22 defaults).
* `paths.py`: settings and saves. An existing `~/.cold_tide` is always kept; new Linux installs follow XDG
  (`~/.config/cold-tide`, `~/.local/share/cold-tide`); `COLD_TIDE_HOME` override; works without a home folder.
  Saves and settings are now written atomically (no half-written file after a crash).
* Audio: mixer opened with a pinned format, buffer-size fallbacks and Linux driver fallbacks
  (pulseaudio / pipewire / alsa); silent mode if nothing works.
  *Note:* the game has always played its 22050 Hz sounds at 44100 Hz (pygame.init() opens the mixer first, so the
  old `mixer.init(22050)` call was ignored). That is how it has always sounded, so it is preserved on purpose
  and pinned (`PLAYBACK_RATE` in `audio.py`).
* Display: desktop size from `get_desktop_sizes()` with fallbacks, windowed fallback if fullscreen fails, window
  clamped to the desktop, resizable window, F11 and Alt+Enter, window icon.
* Input: ZQSD (AZERTY) movement added; menus work with the mouse.
* Fonts: more Linux CJK font locations (the game also ships its own).
* Scaling: HD art is smoothed only at awkward scales (no shimmering at 1.33x); near-whole-number scales snap to
  exactly 2x / 3x / 4x (checked on a real 1080p fullscreen).
* `install_linux.sh`, `run_linux.sh`, `README_LINUX.md`; `python main.py --selftest`; launchers for Windows and macOS
  updated to Python 3.9+.

## 3. Performance
* Text, panel and dim overlays are cached (they were re-created every frame); the screen is scaled into a reused
  buffer; ground, shadows and decals are baked once; lighting uses cached sprites.
* HD pack: ~2.8 ms per frame (headless, software), ~67 MB RAM peak, starts in under a second. Pack `cozy` is lighter
  still, and *Day / night lighting* can be switched off.

## 4. Tests (all run headless; `python tests/run_all.py`)
`smoke` (full scripted playthrough of both cases, now with REAL pygame instead of a fake module), `render_test`
(all packs x scenes x times of day x window sizes, resize, fullscreen, mouse, languages, timing), `assets_test`
(every picture exists with exact case, sheet sizes), `paths_test` (locations, migration, save/load round trip),
`audio_test`, `i18n_test`.

## 5. Not changed / limits
See README_LINUX.md > Known limitations. Not tested: physical Mint/Ubuntu machines, real speakers, Wayland, ARM.
