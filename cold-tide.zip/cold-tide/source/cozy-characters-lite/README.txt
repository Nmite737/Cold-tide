COZY CHARACTERS — LITE
=======================

6 of the 40 characters, one per group plus one more Town Folk, with every animation. Get the other 34 in Cozy Characters Complete: https://aquumgifts.itch.io/cozy-characters

40 new 16x24 pixel people, top-down 3/4 view, for the Cozy Town / Cozy Farm world.
Same palette, same 1 px brown outline, light from the top left.

Files
-----
characters/1x, 2x, 4x/
  <name>.png                 one sheet per character (96 x 480 px at 1x)
  catalog.png                 all 40 standing front, one row per group (preview)
characters/characters.json   layout as data (groups, rows, frames, fps, loop)
godot/characters/*.tres      Godot 4 SpriteFrames for every sheet (AnimatedSprite2D),
                              animations named <animation>_<direction>, e.g. walk_left

Frame
-----
Every frame is 16 x 24 px. Feet rest on pixel row 21 (counting from 0 at the top),
so a 16x16 tile grid lines up when the frame is drawn 21 px above the feet position.
Left is the mirror of right, with the shading redrawn so light still comes from the left.

Row order (every sheet)
------------------------
Each animation takes 4 rows, always in this order: down, left, right, up.
Frames run left to right; unused cells are transparent.

  row  0- 3  idle   4 frames   4 fps  loop   (breathing; blinks on frame 2)
  row  4- 7  walk   6 frames  10 fps  loop
  row  8-11  carry  6 frames  10 fps  loop   (walking with a cardboard box in the arms)
  row 12-15  sit    4 frames   4 fps  loop   (seated, breathing and blinking)
  row 16-19  wave   6 frames   8 fps  once   (raise, wave x4, lower)

Pixel position of a frame: x = column * 16, y = row * 24 (at 1x).

Groups
------
  town-folk:
    folk-grandma       grandma out for a walk
    folk-grandpa       grandpa with his newspaper
    folk-girl          little girl
    folk-boy           little boy
    folk-teen          teenager with a backpack
    folk-partner-a     half of a couple, long coat
    folk-dogwalker     dog walker
    folk-cyclist       cyclist with a cap
  workers:
    work-chef          chef
    work-mail          mail carrier
    work-police        police officer
    work-firefighter   firefighter
    work-doctor        doctor
    work-nurse         nurse
    work-builder       construction worker
    work-courier       delivery courier
  shop-cafe:
    shop-barista       barista
    shop-baker         baker
    shop-florist       florist
    shop-cashier       cashier
    shop-librarian     bookshop clerk
    shop-icecream      ice cream vendor
    shop-waitress      waitress
    shop-mechanic      mechanic
  school-office:
    school-teacher     teacher
    school-student     student
    school-office      office worker
    school-janitor     janitor
    school-scientist   scientist
    school-artist      artist
    school-musician    musician
    school-athlete     athlete
  seasonal:
    season-winter      winter coat and scarf
    season-rain        raincoat and umbrella-ready
    season-summer      summer outfit
    season-pumpkin     pumpkin costume
    season-ghost       ghost costume
    season-santa       santa costume
    season-garden      garden outfit
    season-sport       sport outfit

License
-------
See LICENSE.txt in the pack.
