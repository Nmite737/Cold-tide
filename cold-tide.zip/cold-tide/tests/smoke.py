"""Full scripted playthrough with REAL pygame, using SDL's headless drivers (no window, no sound card).
Runs on Windows, Linux and macOS:  python tests/smoke.py"""
import os, sys, tempfile
os.environ.setdefault('SDL_VIDEODRIVER', 'dummy')
os.environ.setdefault('SDL_AUDIODRIVER', 'dummy')
os.environ['COLD_TIDE_HOME'] = tempfile.mkdtemp(prefix='coldtide-test-')
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pygame, main, logic, world as W

class Keys:
    """Stand-in for pygame.key.get_pressed(): anything not listed is 'not pressed'."""
    def __init__(self, down=()): self.down = set(down)
    def __getitem__(self, k): return k in self.down
_held = Keys()
pygame.key.get_pressed = lambda: _held
pygame.Ev = lambda t, k: pygame.event.Event(t, key=k, mod=0)

g=main.Game()
def key(k): g.handle(pygame.Ev(pygame.KEYDOWN,k))
def frames(n=5,dt=0.016):
    for _ in range(n): g.update(dt); g.draw()
frames()
# title -> new game
g.menu.sel=0; key(pygame.K_RETURN); assert g.mode=='card'; frames(); key(pygame.K_RETURN); assert g.mode=='play'
frames(30)
# walk
_held=Keys([pygame.K_d]); frames(60); _held=Keys()
# settings through pause menu: switch packs/window/fullscreen
key(pygame.K_ESCAPE); assert g.mode=='menu'; g.menu.sel=2; key(pygame.K_RETURN); frames()
# item 0 = Language: cycle through every language and back to English, with every screen drawn
import i18n
langs=i18n.codes(); assert langs[0]=='en' and set(langs)>={'en','fr','de','zh'}, langs
for _ in range(len(langs)):
    g.menu.sel=0; key(pygame.K_RIGHT); frames(3)
    print('language', g.settings['lang'], g.font_file)
    assert i18n.current()==g.settings['lang']
assert g.settings['lang']=='en'
key(pygame.K_LEFT) if False else None
for _ in range(3):
    g.menu.sel=1; key(pygame.K_RIGHT); frames(3)
    print('pack', g.settings['pack'], g.pack.T, g.canvas.get_size())
for i in range(2,8): g.menu.sel=i; key(pygame.K_RETURN); frames(2)
g.menu.sel=len(g.menu.items)-1; key(pygame.K_RETURN); assert g.menu.title=='Paused'; key(pygame.K_ESCAPE); assert g.mode=='play'
# cheat-play the case
c=g.case; print('killer',c.killer,'decoy',c.decoy)
def tp(x,y): g.px,g.py=x,y
def use(tool): g.tool=tool; key(pygame.K_SPACE); frames(200)
def finish():
    while g.mode=='dialog': key(pygame.K_e)
def town():
    if g.scene!='town': g.leave()
def goto(n):                      # walk next to somebody, wherever they are (town, cafe or police station)
    if n['scene']!=g.scene:
        town()
        if n['scene']!='town': g.enter(n['scene'])
    tp(n['x'],n['y']+0.5)
def chief():
    pb=g.world.building('police'); town(); tp(pb['door'][0]+.5,pb['approach'][1]+.3); key(pygame.K_e); assert g.scene=='police'
    tp(15.5,6.5); frames(2); key(pygame.K_e); assert g.mode=='menu', g.mode; frames()
# beach print
tp(30.5,35.5); use(0); assert 'beach_print' in g.collected; finish()
# scan before cctv
npc=g.npcs[c.killer]; goto(npc); use(1); finish(); assert 'face_'+c.killer not in g.collected
# cctv
town(); tp(22.5,33.2); key(pygame.K_e); frames(100); finish(); assert 'cctv' in g.collected
goto(npc); use(1); finish(); assert 'face_'+c.killer in g.collected
# door
town(); b=g.world.building({'grandma':'house1','dogwalker':'house2','chef':'house3','teacher':'house4','pumpkin':'house6','barista':'house5'}[c.killer])
tp(b['door'][0]+.5,b['approach'][1]+.5); use(0); finish(); print('scores',g.scores())
# dig
for i,(sx,sy) in enumerate(W.MOUND_SITES):
    tp(sx+.5,sy+1.2); use(2); finish()
print('collected',sorted(g.collected)); print(g.scores())
# notebook
key(pygame.K_n); frames(); key(pygame.K_TAB); frames(); key(pygame.K_n)
# police (the chief is inside the station)
chief()
g.menu.sel=0; key(pygame.K_RETURN); frames(); finish()
g.menu.sel=1; key(pygame.K_RETURN); frames(); 
# arrest decoy first
idx=[s['id'] for s in logic.SUSPECTS].index(c.decoy); g.menu.sel=idx; key(pygame.K_RETURN); frames(); finish(); 
g.menu.sel=1; key(pygame.K_RETURN)
k=[s['id'] for s in logic.SUSPECTS].index(c.killer); g.menu.sel=k; key(pygame.K_RETURN); assert g.mode=='win', g.mode; frames(200)
# stalking & ending: fresh game, skip days
g.title_menu(); g.new_game(); key(pygame.K_RETURN)
for d in range(20):
    g.menu=None; g.mode='play'; g.end_day(True); 
    if g.mode=='card': key(pygame.K_RETURN)
    if g.day>=15:
        g.minute=1000; frames(400)
        if d==15: print('stalker', g.stalker)
assert g.day==21, g.day
# scan the stalker
for _ in range(2000):
    g.update(0.05)
    if g.stalker and g.dist(g.stalker['x'],g.stalker['y'])<6: break
print('stalker', g.stalker and (g.stalker['x'],g.stalker['y']), g.px,g.py)
g.minute=1300; frames(10)
g.advance_time(30); assert g.mode=='bad_end', g.mode
for i in range(30): frames(60,0.05)
key(pygame.K_RETURN); assert g.mode=='title'
# continue after save
g.new_game(); key(pygame.K_RETURN); g.end_day(); key(pygame.K_RETURN); g.quit_to_title(); 
g.menu.sel=1; assert g.menu.items[1]['label']=='Continue'; key(pygame.K_RETURN); assert g.mode=='play' and g.day==2
# hints: H key, nearby nudge, idle nudge, notebook line
g.title_menu(); g.new_game(); key(pygame.K_RETURN); frames(5)
key(pygame.K_h); assert g.mode=='dialog' and 'marker' in g.dialog['lines'][0], g.dialog; finish()
g.tool=2; g.hint_cd=0; tp(30.5,35.5); frames(100); assert g.banner and 'marker' in g.banner[0], g.banner   # wrong tool next to the marker
g.banner=None; g.hint_cd=0; g.idle=95; g.tool=0; tp(14,25); frames(3); assert g.banner and g.banner[0].startswith('Hint:'), g.banner
use(0) if False else None
g.settings['hints']=False; g.banner=None; g.idle=999; g.hint_cd=0; frames(5); assert g.banner is None   # auto hints off
g.settings['hints']=True
key(pygame.K_n); frames(); key(pygame.K_n)
print('HINTS OK')


# every language: play screens must draw without errors and the saved setting must survive a restart
for code in i18n.codes():
    g.settings['lang']=code; g.apply_language(); g.save_settings()
    g.title_menu(); frames(2); g.new_game(); frames(2); key(pygame.K_RETURN); frames(5)
    key(pygame.K_h); frames(2); finish(); key(pygame.K_n); frames(2); key(pygame.K_TAB); frames(2); key(pygame.K_n)
    chief(); g.menu.sel=1; key(pygame.K_RETURN); frames(2); g.to_play(); town()
    g.mode='win'; g.end_t=5; frames(2); g.mode='bad_end'
    for t in (1,5,8,12,18): g.end_t=t; frames(1)
    g.title_menu()
g2=main.Game.load_settings(g); assert g2['lang']==g.settings['lang']
g.settings['lang']='en'; g.apply_language()
print('LANGUAGES OK')

# ---- the interiors, portraits and the cafe murder (real clues, real dialogue)
g.title_menu(); g.new_game(); key(pygame.K_RETURN); frames(5)
cb=g.world.building('cafe'); tp(cb['door'][0]+.5,cb['approach'][1]+.3); key(pygame.K_e); assert g.scene=='cafe'; frames(3)
tp(14.5,4.4); frames(2); assert g.interior.is_solid(12,5)          # storeroom is locked before the murder
tp(6.5,11.5); key(pygame.K_e) if False else None; g.leave(); assert g.scene=='town'
for _ in range(4): g.end_day(True); frames(1)
key(pygame.K_RETURN); assert g.c2_on and g.mode=='play'
c2=g.case2; assert c2.culprit!=g.case.killer
g.enter('cafe'); assert not g.interior.is_solid(12,5)
tp(13.5,5.8); use(0); finish(); assert 'c2_cup' in g.collected
for x,y in ((14.6,3.4),(10.5,4.4),(13.4,3.4),(15.7,4.7),(15.0,5.9)):
    tp(x,y); frames(2); key(pygame.K_e); frames(100); finish()
for sid,pos in (('grandma',(3.8,7.5)),('chef',(2.5,3.4)),('teacher',(2.0,9.5)),('barista',(9.4,4.4))):
    tp(*pos); use(0); finish(); assert 'c2_print_'+sid in g.collected, sid
sc=g.scores2(); assert sc[c2.culprit]>=4 and sc[c2.decoy]>=3, sc
g.npcs[c2.culprit].update(scene='cafe',x=8.5,y=5.5,place='cafe',path=[],enter=None)
g.talk_to(g.npcs[c2.culprit]); finish(); assert 'c2_lie' in g.collected
key(pygame.K_n); g.page=2; frames(3); g.page=0; frames(2); key(pygame.K_n)
chief(); g.menu.sel=2; key(pygame.K_RETURN); frames(); g.menu.sel=1; key(pygame.K_RETURN)      # arrest -> cafe case
g.menu.sel=list(__import__('case2').SUSPECTS2).index(c2.decoy); key(pygame.K_RETURN); finish()  # the decoy: wrong
assert g.mode=='play' and g.day==7, (g.mode,g.day)
chief(); g.menu.sel=2; key(pygame.K_RETURN); g.menu.sel=1; key(pygame.K_RETURN)
g.menu.sel=list(__import__('case2').SUSPECTS2).index(c2.culprit); key(pygame.K_RETURN); assert g.mode=='card'; frames(2); key(pygame.K_RETURN)
assert g.c2_done and g.npcs[c2.culprit]['scene']=='police'
tp(14.3,3.4); g.collected.add('beach_print'); frames(2); key(pygame.K_e); finish(); assert 'lab_report' in g.collected
g.save_game(); g.quit_to_title(); g.menu.sel=1; key(pygame.K_RETURN); assert g.c2_done                # survives save/load
print('INTERIORS + CAFE CASE OK')
print('ALL OK')
