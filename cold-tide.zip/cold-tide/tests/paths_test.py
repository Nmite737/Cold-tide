"""Settings / save locations and file safety.   python tests/paths_test.py"""
import json, os, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import paths

tmp = Path(tempfile.mkdtemp(prefix="ct-paths-"))
home = tmp / "home"; home.mkdir()
env = {"HOME": str(home), "USERPROFILE": str(home)}

# Path.home() honours HOME on Linux/macOS: use that for realistic checks
old = os.environ.get("HOME"); os.environ["HOME"] = str(home); os.environ.pop("USERPROFILE", None)
os.environ.pop("COLD_TIDE_HOME", None)
try:
    # 1) fresh Linux install: XDG locations
    cfg, dat = paths.data_dirs({}, "linux")
    assert cfg == home / ".config" / "cold-tide" and dat == home / ".local" / "share" / "cold-tide", (cfg, dat)
    cfg, dat = paths.data_dirs({"XDG_CONFIG_HOME": str(tmp / "c"), "XDG_DATA_HOME": str(tmp / "d")}, "linux")
    assert cfg == tmp / "c" / "cold-tide" and dat == tmp / "d" / "cold-tide"
    # a relative XDG path is invalid per the spec and must be ignored
    cfg, _ = paths.data_dirs({"XDG_CONFIG_HOME": "relative/dir"}, "linux")
    assert cfg == home / ".config" / "cold-tide"
    # 2) fresh Windows / macOS: the old location
    for plat in ("win32", "darwin"):
        assert paths.data_dirs({}, plat) == (home / ".cold_tide", home / ".cold_tide")
    # 3) an existing ~/.cold_tide always wins (no save is orphaned), on every platform
    (home / ".cold_tide").mkdir()
    for plat in ("linux", "win32", "darwin"):
        assert paths.data_dirs({}, plat) == (home / ".cold_tide", home / ".cold_tide"), plat
    # 4) explicit override
    assert paths.data_dirs({"COLD_TIDE_HOME": str(tmp / "x")}, "linux") == (tmp / "x", tmp / "x")
finally:
    if old is not None: os.environ["HOME"] = old

# atomic write: replaces the file, leaves no temp files, survives odd characters
f = tmp / "sub" / "dir" / "save.json"
paths.write_text_atomic(f, json.dumps({"a": "é中😀"}))
paths.write_text_atomic(f, json.dumps({"a": 2}))
assert json.loads(f.read_text(encoding="utf-8")) == {"a": 2}
assert [p.name for p in f.parent.iterdir()] == ["save.json"], list(f.parent.iterdir())
assert paths.read_json(tmp / "missing.json", "dflt") == "dflt"
(tmp / "bad.json").write_text("{not json", encoding="utf-8")
assert paths.read_json(tmp / "bad.json", {}) == {}

# game level: save -> load round trip, corrupt settings, one-time art migration
os.environ.update(SDL_VIDEODRIVER="dummy", SDL_AUDIODRIVER="dummy", COLD_TIDE_HOME=str(tmp / "game"))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import main, pygame
(tmp / "game").mkdir()
main.SETTINGS_FILE.write_text("{ definitely not json", encoding="utf-8")
g = main.Game()
assert g.settings["pack"] == "hd" and g.settings["art_rev"] == main.ART_REVISION      # corrupt file -> defaults
main.SETTINGS_FILE.write_text(json.dumps({"pack": "cozy", "volume": 3, "lang": "fr"}), encoding="utf-8")
g2 = main.Game()
assert g2.settings["pack"] == "hd" and g2.settings["volume"] == 3 and g2.settings["lang"] == "fr"   # migrated once, rest kept
g2.settings["pack"] = "cozy"; g2.save_settings()
g3 = main.Game(); assert g3.settings["pack"] == "cozy", "an explicit later choice must stick"
g3.new_game(); pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN, mod=0)); g3.handle(pygame.event.get()[0])
g3.day, g3.minute = 5, 777; g3.collected.add("beach_print"); g3.save_game()
assert main.SAVE_FILE.exists()
data = json.loads(main.SAVE_FILE.read_text(encoding="utf-8"))
assert data["day"] == 5 and data["minute"] == 777 and "beach_print" in data["collected"]
g4 = main.Game(); g4.title_menu()
assert g4.menu.items[1]["label"] == "Continue"
g4.menu.sel = 1; g4.menu.items[1]["enter"]()
assert (g4.day, g4.minute) == (5, 777) and "beach_print" in g4.collected
print("PATHS + SAVES OK")
