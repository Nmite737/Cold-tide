"""Audio test: needs real pygame. Runs headless (dummy audio/video drivers)."""
import os, sys, time, wave
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import pygame
import audio, logic

t = time.time()
a = audio.Audio({"sound": True, "volume": 7}, pygame)
assert a.ok, "mixer failed to start"
print("built %d sounds in %.2fs" % (len(a.sounds), time.time() - t))

# every suspect + chief speak without error, timing each
for who in list(audio.VOICES):
    t = time.time()
    a.say("%s: Oh, a detective! I walk the beach every morning, dear. Poor Daniel..." % who)
    dt = time.time() - t
    assert dt < 1.5, (who, dt)
    print("voice %-14s %.2fs" % (who, dt))
a.say("Locked. Nobody answers.")          # narration: silent, must not crash
a.say("Chief: Is that so?")                # question contour
for n in a.sounds:
    a.play(n)
for s in ("grass", "sand", "hard"):
    a.step(s)
a.ambient(1.0); a.ambient(0.0); a.heartbeat(0.5, 4)
off = audio.Audio({"sound": False, "volume": 7}, pygame)
off.say("Chief: hello"); off.play("dig")   # muted: no crash
print("AUDIO OK")

if len(sys.argv) > 1:                      # dump wavs:  python tests/audio_test.py outdir
    out = sys.argv[1]; os.makedirs(out, exist_ok=True)
    import random
    def dump(name, samples):
        with wave.open(os.path.join(out, name + ".wav"), "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(audio.SR)
            w.writeframes(audio._clip(samples).tobytes())
    rng = random.Random(1)
    dump("dig", audio.make_dig_long(rng)); dump("door_open", audio.make_door_open(rng))
    dump("step_grass", audio.make_step("grass", 0, rng)); dump("step_hard", audio.make_step("hard", 0, rng))
    dump("voice_grandma", audio.make_voice("Oh, a detective! I walk the beach every morning, dear.", audio.VOICES["Edith Marlowe"], 1))
    dump("voice_gideon", audio.make_voice("The orchard is mine and the woods are no one's.", audio.VOICES["Gideon Hale"], 2))
