"""Language test: no pygame needed.  python tests/i18n_test.py
Checks that every text used by the game exists in every language file, that %s / %d placeholders
match, that the Chinese font covers every character, and that speaker names map to voices."""
import ast, json, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import i18n, logic, audio

# ---- every tr("...") / N_("...") / L("...") text in the code
used = []
for f in ("main.py", "logic.py", "case2.py", "interiors.py"):
    tree = ast.parse(open(os.path.join(ROOT, f), encoding="utf-8").read())
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ("tr", "N_", "L") and n.args:
            a = n.args[0]
            if isinstance(a, ast.Constant) and isinstance(a.value, str) and a.value not in used:
                used.append(a.value)
print("%d texts in the code" % len(used))

SPEC = re.compile(r"%[-#0 +]*\d*(?:\.\d+)?[sd]|%%")
problems = 0
for code in i18n.codes():
    if code == "en":
        continue
    data = json.load(open(os.path.join(ROOT, "lang", code + ".json"), encoding="utf-8"))
    st = data["strings"]
    miss = [k for k in used if k not in st]
    stale = [k for k in st if k not in used]
    bad = [k for k in st if k in used and sorted(SPEC.findall(k)) != sorted(SPEC.findall(st[k]))]
    empty = [k for k in st if not st[k].strip()]
    print("%-3s %-9s missing=%d unused=%d bad_placeholders=%d empty=%d" % (code, i18n.name(code), len(miss), len(stale), len(bad), len(empty)))
    for k in miss[:5] + bad[:5]:
        print("    ", repr(k))
    problems += len(miss) + len(bad) + len(empty)
    # colon-space is how audio.say finds the speaker, never put it in a speaker name
    for who in ("Chief", "Milo's Cafe"):
        assert ": " not in st[who], who

# ---- Chinese font covers every character (bundled font)
font_meta = [c for c in i18n.codes() if i18n.meta("font", c)]
fonts = [f for f in os.listdir(os.path.join(ROOT, "assets", "fonts")) if f.lower().endswith((".otf", ".ttf"))]
if font_meta and fonts:
    try:
        from fontTools.ttLib import TTFont
        cmap = TTFont(os.path.join(ROOT, "assets", "fonts", fonts[0])).getBestCmap()
        for code in font_meta:
            data = json.load(open(os.path.join(ROOT, "lang", code + ".json"), encoding="utf-8"))
            lost = sorted({ch for v in data["strings"].values() for ch in v if ord(ch) not in cmap})
            print("font covers %s:" % code, "yes" if not lost else "MISSING " + "".join(lost))
            problems += len(lost)
    except ImportError:
        print("(fonttools not installed: font coverage not checked)")

# ---- the game logic produces text in every language, and clues switch language at once
c = logic.Case(7)
en_title = c.title("beach_print")
for code in i18n.codes():
    i18n.set_language(code)
    t = c.title("beach_print")
    assert (t != en_title) == (code != "en"), (code, t)
    for sid in logic.BY_ID:
        for n in range(3):
            assert all(l.startswith(logic.BY_ID[sid]["name"] + ": ") for l in logic.dialogue(c, sid, 3, 700, n))
    assert logic.next_hint(c, set()) and logic.next_hint(c, {"beach_print", "cctv"}, 5, 800)
    assert logic.job("chef")
    # speaker names still find their voice
    for key in ("Chief", "Milo's Cafe"):
        who = i18n.tr(key)
        assert audio.VOICES.get(who) or audio.VOICES.get(i18n.canonical(who)), (code, who)
i18n.set_language("en")
assert i18n.tr("No such text, falls back") == "No such text, falls back"
assert i18n.lower("Chef") == "chef"
i18n.set_language("de"); assert i18n.lower("Köchin") == "Köchin"; i18n.set_language("en")

# ---- Chinese babble: a line with no spaces still produces sound
assert len(audio.make_voice("哎呀，是侦探啊！孩子，我每天早上都在海滩上散步。", audio.VOICES["Chief"], 1)) > 4000

sys.exit("LANGUAGE TEST FAILED (%d problems)" % problems) if problems else print("LANGUAGES OK")
