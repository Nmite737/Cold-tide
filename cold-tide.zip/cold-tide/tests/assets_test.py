"""Asset checks: every picture the code asks for exists in every texture pack, with EXACTLY the right
upper/lower case (Linux file systems are case-sensitive, Windows/macOS usually are not), and every
file has the size the game expects.   python tests/assets_test.py"""
import json, os, re, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault('SDL_VIDEODRIVER', 'dummy'); os.environ.setdefault('SDL_AUDIODRIVER', 'dummy')
from PIL import Image

PACKS = ROOT / "assets" / "packs"
src = {p.name: p.read_text(encoding="utf-8") for p in ROOT.glob("*.py")}
keys = set()
for name in ("main.py", "interiors.py", "world.py", "decor.py"):
    t = src[name]
    keys |= set(re.findall(r'img\("([a-z0-9_]+)"\)', t))
    keys |= set(re.findall(r'"(i_[a-z0-9_]+)"', t))
    keys |= set(re.findall(r'"(prop_[a-z0-9_]+)"', t))
    keys |= set(re.findall(r'"(decal_[a-z0-9_]+)"', t))
for fixed in ("tree", "rock", "mound", "mound_dug", "marker", "tape", "cctv", "road", "road2", "road_line",
              "crosswalk", "sidewalk", "sand1", "sand2", "water1", "water2", "grass1", "grass2", "grass3",
              "flowers1", "flowers2", "flowers3"):
    keys.add(fixed)
sheets = {"player", "folk-grandma", "folk-dogwalker", "work-chef", "school-teacher", "season-pumpkin",
          "shop-barista", "police-chief", "police-officer"}
b_ids = {"house%d" % i for i in range(1, 7)} | {"police", "hotel", "cafe"}
keys |= b_ids
keys = {k for k in keys if k and not k.endswith("_")}      # "i_wall_" + theme letter: built at run time
fail = []

def on_disk(pack, key):
    """Case-exact existence check (listing the directory instead of trusting the OS)."""
    return key + ".png" in {p.name for p in (PACKS / pack).iterdir()}

base = {p.stem for p in (PACKS / "cozy").glob("*.png")}
for pack_dir in sorted(p for p in PACKS.iterdir() if p.is_dir()):
    pack = pack_dir.name
    meta = json.loads((pack_dir / "pack.json").read_text(encoding="utf-8"))
    T = int(meta["tile_size"])
    have = {p.stem for p in pack_dir.glob("*.png")}
    need = (keys | sheets) if meta.get("hd") else set()
    for k in sorted(need):
        if k.startswith(("prop_", "decal_")) or k in ("tree2", "tree3", "tree_apple", "rock2"):
            continue
        if k not in have:
            fail.append("%s: missing %s.png" % (pack, k))
    for k in sorted(have):
        if not on_disk(pack, k):
            fail.append("%s: case mismatch %s" % (pack, k))
    # frame geometry of the character sheets: 6 columns of T x 1.5T
    for sname in sheets:
        if sname in have:
            w, h = Image.open(pack_dir / (sname + ".png")).size
            if w != 6 * T or h % (T * 3 // 2):
                fail.append("%s: sheet %s is %dx%d, expected width %d" % (pack, sname, w, h, 6 * T))
    if meta.get("hd"):
        for bid, m in meta.get("buildings", {}).items():
            if bid + "_lit" not in have:
                fail.append("%s: no night overlay for %s" % (pack, bid))
    print("%-8s T=%-2d %3d pictures  ok" % (pack, T, len(have)))
# decor props must exist in the hd pack (they are optional elsewhere)
import decor
need_props = {k for (k, *_r) in decor.SOLID} | {k for (k, *_r) in decor.PROPS} | {k for (k, *_r) in decor.DECALS}
for pack in ("hd", "hd-noir"):
    have = {p.stem for p in (PACKS / pack).glob("*.png")}
    for k in sorted(need_props):
        if k not in have:
            fail.append("%s: missing decor sprite %s" % (pack, k))
    for k in ("tree2", "tree3", "tree_apple", "rock2", "shadow_char", "grass_fringe", "wet_sand", "road_n", "road_s",
              "sidewalk_n", "sidewalk_s", "grass_dark", "grass_dark2"):
        if k not in have:
            fail.append("%s: missing %s" % (pack, k))
for key in ("player", "grandma", "dogwalker", "chef", "teacher", "pumpkin", "barista", "chief", "officer"):
    for suf in ("", "_worried"):
        f = ROOT / "assets" / "portraits" / (key + suf + ".png")
        if not f.exists():
            fail.append("missing portrait %s" % f.name)
for f in fail:
    print("FAIL", f)
print("ASSETS OK" if not fail else "ASSETS FAILED (%d)" % len(fail))
sys.exit(1 if fail else 0)
