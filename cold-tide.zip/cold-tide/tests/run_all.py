"""Run every test with the current Python:   python tests/run_all.py
(headless: no window or sound card needed; Pillow is only needed for assets_test)"""
import os, subprocess, sys
from pathlib import Path
here = Path(__file__).resolve().parent
env = dict(os.environ, SDL_VIDEODRIVER=os.environ.get("SDL_VIDEODRIVER", "dummy"),
           SDL_AUDIODRIVER=os.environ.get("SDL_AUDIODRIVER", "dummy"))
bad = []
for t in ("paths_test", "i18n_test", "audio_test", "assets_test", "render_test", "smoke"):
    if t == "assets_test":
        try:
            import PIL  # noqa: F401
        except ImportError:
            print("== assets_test skipped (pip install pillow to enable)"); continue
    print("== %s" % t, flush=True)
    r = subprocess.run([sys.executable, str(here / (t + ".py"))], env=env, capture_output=True, text=True)
    tail = (r.stdout.strip().splitlines() or [""])[-1]
    print("   ", tail if r.returncode == 0 else (r.stdout + r.stderr)[-1500:])
    if r.returncode:
        bad.append(t)
print("ALL TESTS PASSED" if not bad else "FAILED: " + ", ".join(bad))
sys.exit(1 if bad else 0)
