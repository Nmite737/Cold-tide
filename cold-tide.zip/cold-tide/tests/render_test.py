"""Rendering, window and performance checks with real pygame (headless).
Draws every scene with every texture pack at several times of day and window sizes, toggles
fullscreen, resizes the window, and times the frames.     python tests/render_test.py
Set COLD_TIDE_SHOTS=/some/dir to also save screenshots."""
import os, sys, tempfile, time
from pathlib import Path
os.environ.setdefault("SDL_VIDEODRIVER", "dummy"); os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ["COLD_TIDE_HOME"] = tempfile.mkdtemp(prefix="ct-render-")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import pygame, main

g = main.Game()
shots = os.environ.get("COLD_TIDE_SHOTS")
if shots: Path(shots).mkdir(parents=True, exist_ok=True)
g.new_game(); g.mode = "play"; g.menu = None

def frames(n=2):
    for _ in range(n):
        g.update(0.016); g.t += 0.016; g.draw()

def varied(surf):
    """A real picture has many different colours; a failed render is one flat colour."""
    w, h = surf.get_size()
    seen = {tuple(surf.get_at((x, y))[:3]) for x in range(0, w, max(1, w // 40)) for y in range(0, h, max(1, h // 24))}
    return len(seen)

timings = {}
for pack in main.list_packs():
    g.load_pack(pack)
    for size_i in range(len(main.WINDOW_SIZES)):
        g.settings["window"] = size_i; g.settings["fullscreen"] = False; g.apply_display()
        for label, scene, minute, pos in (("day", "town", 600, (30.5, 19.5)), ("dusk", "town", 1110, (12.5, 19.5)),
                                          ("night", "town", 1290, (30.5, 19.5)), ("beach", "town", 600, (30.5, 33.5)),
                                          ("woods", "town", 600, (12.5, 8.5)), ("cafe", "cafe", 700, None),
                                          ("police", "police", 1250, None)):
            if g.scene != "town": g.leave()
            g.minute = minute
            if scene != "town": g.enter(scene)
            else: g.px, g.py = pos
            frames(1); t0 = time.perf_counter(); frames(4); dt = (time.perf_counter() - t0) / 4
            timings.setdefault(pack, []).append(dt)
            assert varied(g.screen) > 12, "%s %s %s looks blank" % (pack, label, size_i)
            if shots and size_i == 1:
                pygame.image.save(g.screen, "%s/%s_%s.png" % (shots, pack, label))
    if g.scene != "town": g.leave()

# lighting off, integer scaling, resize events, fullscreen toggle (dummy driver accepts all of these)
g.load_pack("hd"); g.settings["lighting"] = False; frames(2); g.settings["lighting"] = True
g.settings["integer"] = True; frames(2); g.settings["integer"] = False
for w, h in ((800, 450), (1366, 768), (1920, 1080), (640, 360), (1000, 1000)):
    g.screen = pygame.display.set_mode((w, h), pygame.RESIZABLE)
    pygame.event.post(pygame.event.Event(pygame.VIDEORESIZE, size=(w, h), w=w, h=h)); [g.handle(e) for e in pygame.event.get()]
    frames(2); assert g.screen.get_size() == (w, h) and varied(g.screen) > 12
for _ in range(3):
    g.toggle_fullscreen(); frames(2)
assert g.settings["fullscreen"] in (True, False)
g.settings["fullscreen"] = False; g.apply_display()
# Alt+Enter and F11 both toggle
before = g.settings["fullscreen"]
g.handle(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_F11, mod=0)); assert g.settings["fullscreen"] != before
g.handle(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN, mod=pygame.KMOD_ALT)); assert g.settings["fullscreen"] == before

# mouse in menus: hover selects, click chooses
g.title_menu(); frames(2)
assert g.mouse_rects, "menu items must publish mouse rectangles"
rect, idx = g.mouse_rects[-1]
g.handle(pygame.event.Event(pygame.MOUSEMOTION, pos=rect.center, rel=(0, 0), buttons=(0, 0, 0)))
assert g.menu.sel == idx
# title backdrop + every language on the HD pack
import i18n
for code in i18n.codes():
    g.settings["lang"] = code; g.apply_language(); g.title_menu(); frames(2)
g.settings["lang"] = "en"; g.apply_language()

print("frame times (ms, mean over scenes and window sizes):")
for pack, v in timings.items():
    print("  %-8s %6.1f ms   worst %6.1f ms" % (pack, 1000 * sum(v) / len(v), 1000 * max(v)))
print("RENDER OK")
